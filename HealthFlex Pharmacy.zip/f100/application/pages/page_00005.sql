prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_imp.id(6900146603923203)
,p_name=>'User Menu'
,p_alias=>'USER-MENU'
,p_step_title=>'User Menu'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#styles#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'WASEAM'
,p_last_upd_yyyymmddhh24miss=>'20240108132624'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7310739278037575)
,p_name=>'User Menu'
,p_template=>wwv_flow_imp.id(6802440761922783)
,p_display_sequence=>20
,p_region_css_classes=>'des'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent6:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where  user_id <> 126 and (',
'  upper(NAME) like upper (''%''||:P5_SEARCH||''%'')  ',
'  or ',
'        upper(USERNAME) like upper(''%''||:P5_SEARCH ||''%'')',
'   ) '))
,p_required_role=>wwv_flow_imp.id(22101237470508314)
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P5_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(6840373677922897)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7311136261037588)
,p_query_column_id=>1
,p_column_alias=>'USER_ID'
,p_column_display_sequence=>30
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.:EDIT:&DEBUG.:RP,:P6_USER_ID:\#USER_ID#\'
,p_column_linktext=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_column_link_attr=>' title="Edit" class="t-Button t-Button--noLabel t-Button--icon t-Button--hot t-Button--success t-Button--simple"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7311492191037596)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>40
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_css_class=>'searchFormat'
,p_column_hit_highlight=>'&P5_SEARCH.'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7311876185037596)
,p_query_column_id=>3
,p_column_alias=>'PHONE'
,p_column_display_sequence=>60
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7312236378037597)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>70
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8501662445065214)
,p_query_column_id=>5
,p_column_alias=>'ACTIVE'
,p_column_display_sequence=>100
,p_column_heading=>'Active'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:yes;1,no;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7312717834037599)
,p_query_column_id=>6
,p_column_alias=>'ROLE'
,p_column_display_sequence=>80
,p_column_heading=>'Role'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(7317951618072814)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6914567509930299)
,p_query_column_id=>7
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>10
,p_column_heading=>'Delete'
,p_use_as_row_header=>'N'
,p_column_link=>'#'
,p_column_linktext=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_column_link_attr=>'title="#USER_ID#" class=" delete t-Button t-Button--noLabel t-Button--icon t-Button--hot t-Button--danger t-Button--simple" delete '
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7313074015037599)
,p_query_column_id=>7
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>90
,p_column_heading=>'Username'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20103361986048629)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>50
,p_column_heading=>'User Activity'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::P32_USER_NAME:#USERNAME#'
,p_column_linktext=>'#DERIVED$02#Activity'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(30611711086648126)
,p_name=>'Your Information'
,p_template=>wwv_flow_imp.id(6802440761922783)
,p_display_sequence=>30
,p_region_css_classes=>'des'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent6:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where upper(USERNAME) = :APP_USER'))
,p_required_role=>wwv_flow_imp.id(22900277267522539)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(6840373677922897)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23301280045610637)
,p_query_column_id=>1
,p_column_alias=>'USER_ID'
,p_column_display_sequence=>20
,p_column_heading=>'Edit'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.:EDIT:&DEBUG.:RP,:P6_USER_ID:\#USER_ID#\'
,p_column_linktext=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_column_link_attr=>' title="Edit" class="t-Button t-Button--noLabel t-Button--icon t-Button--hot t-Button--success t-Button--simple"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23301528287610648)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_css_class=>'searchFormat'
,p_column_hit_highlight=>'&P5_SEARCH.'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23301923667610648)
,p_query_column_id=>3
,p_column_alias=>'PHONE'
,p_column_display_sequence=>40
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23302391082610648)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>50
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23303981639610653)
,p_query_column_id=>5
,p_column_alias=>'ACTIVE'
,p_column_display_sequence=>80
,p_column_heading=>'Active'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:yes;1,no;0'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23302704149610650)
,p_query_column_id=>6
,p_column_alias=>'ROLE'
,p_column_display_sequence=>60
,p_column_heading=>'Role'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(7317951618072814)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23303125771610650)
,p_query_column_id=>7
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>70
,p_column_heading=>'Username'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7313962775037600)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7310739278037575)
,p_button_name=>'ADD_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(6875527579923021)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.:CREATE:&DEBUG.:6::'
,p_button_css_classes=>'addbtn'
,p_icon_css_classes=>'fa-plus-square'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6915339498930307)
,p_name=>'P5_USER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7310739278037575)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6918295606930336)
,p_name=>'P5_SEARCH'
,p_item_sequence=>10
,p_prompt=>'Search'
,p_placeholder=>'search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_css_classes=>'search'
,p_field_template=>wwv_flow_imp.id(6872578399923000)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_security_scheme=>wwv_flow_imp.id(22101237470508314)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7314253971037600)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(7310739278037575)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7314786812037603)
,p_event_id=>wwv_flow_imp.id(7314253971037600)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7310739278037575)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6914917237930302)
,p_name=>'deleteUser'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.delete'
,p_bind_type=>'live'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6914990014930303)
,p_event_id=>wwv_flow_imp.id(6914917237930302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'<h3>are you sure you want to delete this user? <h3>'
,p_attribute_03=>'danger'
,p_attribute_04=>'fa-exclamation'
,p_attribute_05=>'popupMessages'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6915268009930306)
,p_event_id=>wwv_flow_imp.id(6914917237930302)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_USER_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.title'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6915162025930305)
,p_event_id=>wwv_flow_imp.id(6914917237930302)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from "ph_user_activity" where upper("user_name") = (select upper(USERNAME) from "ph_users" ',
'    where USER_ID =  :P5_USER_ID);',
'',
'delete from "ph_users" where "USER_ID" = :P5_USER_ID ;'))
,p_attribute_02=>'P5_USER_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6915110516930304)
,p_event_id=>wwv_flow_imp.id(6914917237930302)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7310739278037575)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6918377939930337)
,p_name=>'search'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_SEARCH'
,p_bind_type=>'bind'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6918440014930338)
,p_event_id=>wwv_flow_imp.id(6918377939930337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7310739278037575)
);
wwv_flow_imp.component_end;
end;
/
