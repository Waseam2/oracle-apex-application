prompt --application/deployment/install/install_ph_tables
begin
--   Manifest
--     INSTALL: INSTALL-ph_tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(34800316786067398)
,p_install_id=>wwv_flow_imp.id(11900935215769450)
,p_name=>'ph_tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "ph_unit" ',
'   (	"unit_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"unit_name" VARCHAR2(50) NOT NULL ENABLE, ',
'	 CONSTRAINT "unit_pk" PRIMARY KEY ("unit_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_medcine" ',
'   (	"medcine_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"barcode_id" VARCHAR2(100) NOT NULL ENABLE, ',
'	"medcine_name" VARCHAR2(250) NOT NULL ENABLE, ',
'	"unit_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"buy_price" NUMBER(20,0), ',
'	"sell_price" NUMBER(20,0), ',
'	"expired_date" DATE, ',
'	"NOTES" VARCHAR2(500), ',
'	"QUANTITY" NUMBER(10,0), ',
'	"PROVIDER_ID" NUMBER(10,0), ',
'	 CONSTRAINT "bigZero1" CHECK ("buy_price" > 0) ENABLE, ',
'	 CONSTRAINT "bigZero2" CHECK ("sell_price" > 0) ENABLE, ',
'	 CONSTRAINT "medcine_pk" PRIMARY KEY ("medcine_id")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "PH_MEDCINE_CON" UNIQUE ("barcode_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "DEPT" ',
'   (	"DEPTNO" NUMBER(2,0), ',
'	"DNAME" VARCHAR2(14), ',
'	"LOC" VARCHAR2(13), ',
'	 PRIMARY KEY ("DEPTNO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EMP" ',
'   (	"EMPNO" NUMBER(4,0) NOT NULL ENABLE, ',
'	"ENAME" VARCHAR2(10), ',
'	"JOB" VARCHAR2(9), ',
'	"MGR" NUMBER(4,0), ',
'	"HIREDATE" DATE, ',
'	"SAL" NUMBER(7,2), ',
'	"COMM" NUMBER(7,2), ',
'	"DEPTNO" NUMBER(2,0), ',
'	 PRIMARY KEY ("EMPNO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_providers" ',
'   (	"provider_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"provider_name" VARCHAR2(250) NOT NULL ENABLE, ',
'	"phone" NUMBER(11,0) NOT NULL ENABLE, ',
'	"Email" VARCHAR2(250), ',
'	"balance" NUMBER(20,0), ',
'	"TYPE" VARCHAR2(1) NOT NULL ENABLE, ',
'	 CONSTRAINT "balance" CHECK ("balance" >0) ENABLE, ',
'	 CONSTRAINT "ph_providers_pk" PRIMARY KEY ("provider_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_users" ',
'   (	"USER_ID" NUMBER(6,0), ',
'	"NAME" VARCHAR2(200) NOT NULL ENABLE, ',
'	"PHONE" NUMBER(11,0), ',
'	"EMAIL" VARCHAR2(200), ',
'	"ROLE" VARCHAR2(10) NOT NULL ENABLE, ',
'	"USERNAME" VARCHAR2(40) NOT NULL ENABLE, ',
'	"PASSWORD" VARCHAR2(128) NOT NULL ENABLE, ',
'	"ACTIVE" NUMBER(1,0), ',
'	 CONSTRAINT "PH_USERS_PK" PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "users_username_unique" UNIQUE ("USERNAME")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_orders" ',
'   (	"order_id" NUMBER(10,0), ',
'	"type" VARCHAR2(1), ',
'	 CONSTRAINT "orders_pk" PRIMARY KEY ("order_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_invoice" ',
'   (	"invoice_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"invoice_date" DATE NOT NULL ENABLE, ',
'	"user_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"order_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"type" VARCHAR2(1) NOT NULL ENABLE, ',
'	"provider_id" NUMBER(10,0), ',
'	"total_price" NUMBER(20,0) NOT NULL ENABLE, ',
'	"client_name" VARCHAR2(100), ',
'	 CONSTRAINT "invoice_pk" PRIMARY KEY ("invoice_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_orders_medcine" ',
'   (	"order_medcine_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"order_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"medcine_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"quantitiy" NUMBER(20,0) NOT NULL ENABLE, ',
'	"provider_id" NUMBER, ',
'	"expired_date" DATE, ',
'	"buy_price" NUMBER, ',
'	 CONSTRAINT "orders_medcine_pk" PRIMARY KEY ("order_medcine_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_shortcomings" ',
'   (	"shortcoming_id" NUMBER(10,0), ',
'	"medcine_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"quantity" NUMBER(10,0), ',
'	 CONSTRAINT "ph_shortcomings_pk" PRIMARY KEY ("shortcoming_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_expired_medcine" ',
'   (	"expMedcine_id" NUMBER(10,0), ',
'	"medcine_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"expired_date" DATE NOT NULL ENABLE, ',
'	 CONSTRAINT "expired_medcine_pk" PRIMARY KEY ("expMedcine_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_expenses" ',
'   (	"expenses_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"money" NUMBER(10,0) NOT NULL ENABLE, ',
'	"EXPENSES_DATE" DATE NOT NULL ENABLE, ',
'	 CONSTRAINT "expenses_pk" PRIMARY KEY ("expenses_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "PH_NOTIFICATION" ',
'   (	"NOT_ID" NUMBER(10,0), ',
'	"MEDCINE_NAME" VARCHAR2(200), ',
'	"BARCODE" VARCHAR2(20), ',
'	"MEDCINE_ID" NUMBER, ',
'	"STATUS" VARCHAR2(10) NOT NULL ENABLE, ',
'	"INFORMATION" VARCHAR2(100) NOT NULL ENABLE, ',
'	 CONSTRAINT "PH_NOTIFICATION_PK" PRIMARY KEY ("NOT_ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "PH_NOTIFICATION_CON" UNIQUE ("MEDCINE_ID") DISABLE',
'   ) ;',
'',
'CREATE TABLE "ph_setting" ',
'   (	"setID" NUMBER(10,0) NOT NULL ENABLE, ',
'	"setting" VARCHAR2(100) NOT NULL ENABLE, ',
'	"setvalue" VARCHAR2(100) NOT NULL ENABLE, ',
'	 CONSTRAINT "ph_setting_pk" PRIMARY KEY ("setID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_user_activity" ',
'   (	"activity_id" NUMBER, ',
'	"user_name" VARCHAR2(100), ',
'	"login_date" TIMESTAMP (6), ',
'	"logout_date" TIMESTAMP (6), ',
'	"session_id" VARCHAR2(50), ',
'	 CONSTRAINT "PH_USER_ACTIVITY_PK" PRIMARY KEY ("activity_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_income" ',
'   (	"income_id" NUMBER(10,0) NOT NULL ENABLE, ',
'	"money" NUMBER(10,0), ',
'	"income_date" DATE, ',
'	 CONSTRAINT "income_pk" PRIMARY KEY ("income_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "PH_COMPLAIN" ',
'   (	"COMPLAIN_ID" NUMBER, ',
'	"USER_NAME" VARCHAR2(100), ',
'	"CUSTOMER_NAME" VARCHAR2(100) NOT NULL ENABLE, ',
'	"CUSTOMER_PHONE" VARCHAR2(11), ',
'	"COMPLAIN_TEXT" VARCHAR2(500) NOT NULL ENABLE, ',
'	 CONSTRAINT "COMPLAINS_PK" PRIMARY KEY ("COMPLAIN_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_return" ',
'   (	"return_id" NUMBER(10,0), ',
'	"return_date" DATE, ',
'	"money" NUMBER(20,0), ',
'	 CONSTRAINT "PH_RETURN_PK" PRIMARY KEY ("return_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "ph_return_medcine" ',
'   (	"return_id" NUMBER, ',
'	"return_date" DATE, ',
'	"money" NUMBER, ',
'	"sell_order_no" NUMBER, ',
'	"quantity" NUMBER, ',
'	"medcine_id" NUMBER, ',
'	"return_order_id" NUMBER, ',
'	"sell_date" DATE, ',
'	 CONSTRAINT "PH_RETURN_MEDCINE_PK" PRIMARY KEY ("return_id")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "ph_medcine" ADD CONSTRAINT "medcine_unit_fk" FOREIGN KEY ("unit_id")',
'	  REFERENCES "ph_unit" ("unit_id") ON DELETE SET NULL ENABLE;',
'',
'ALTER TABLE "ph_orders_medcine" ADD CONSTRAINT "ph_orders_medcine_orders_fk" FOREIGN KEY ("order_id")',
'	  REFERENCES "ph_orders" ("order_id") ON DELETE SET NULL ENABLE;',
'',
'ALTER TABLE "ph_orders_medcine" ADD CONSTRAINT "ph_orders_medcine_medcine_fk" FOREIGN KEY ("medcine_id")',
'	  REFERENCES "ph_medcine" ("medcine_id") ON DELETE SET NULL ENABLE;',
'',
'ALTER TABLE "ph_shortcomings" ADD CONSTRAINT "shortcoming_medcine_fk" FOREIGN KEY ("medcine_id")',
'	  REFERENCES "ph_medcine" ("medcine_id") ENABLE;',
'',
'ALTER TABLE "ph_expired_medcine" ADD CONSTRAINT "expired_medcine_fk" FOREIGN KEY ("medcine_id")',
'	  REFERENCES "ph_medcine" ("medcine_id") ENABLE;',
'',
'ALTER TABLE "ph_invoice" ADD CONSTRAINT "invoice_user_fk" FOREIGN KEY ("user_id")',
'	  REFERENCES "ph_users" ("USER_ID") DISABLE;',
'',
'ALTER TABLE "ph_invoice" ADD CONSTRAINT "invoice_order_fk" FOREIGN KEY ("order_id")',
'	  REFERENCES "ph_orders" ("order_id") ENABLE;',
'',
'ALTER TABLE "ph_invoice" ADD CONSTRAINT "invoice_providers_fk" FOREIGN KEY ("provider_id")',
'	  REFERENCES "ph_providers" ("provider_id") ENABLE;',
'',
'ALTER TABLE "EMP" ADD FOREIGN KEY ("MGR")',
'	  REFERENCES "EMP" ("EMPNO") ENABLE;',
'',
'ALTER TABLE "EMP" ADD FOREIGN KEY ("DEPTNO")',
'	  REFERENCES "DEPT" ("DEPTNO") ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "AUTHETICATE" (p_username varchar2 , p_password varchar2)',
'return boolean ',
'is ',
'v_authent number(2);',
'begin ',
'    select count(username) into v_authent from "ph_users"',
'         where upper(username) = upper(p_username) and password = GET_ENPWD(p_password) and ACTIVE = 1 ;',
'    if v_authent > 0  then',
'        return true ;',
'    else ',
'        return false;',
'    end if;',
'end;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "CHECKMEDCINE" (orderID number, medicineID number)',
'return boolean ',
'is',
'testMedicine number(6) := 0 ;',
'begin ',
'    select "medcine_id" into testMedicine from "ph_orders_medcine" where "order_id" = orderId and "medcine_id" = medicineID;',
'    if testMedicine = 0 then ',
'        return false ;',
'    else ',
'        return true ;',
'    end if ;',
'    exception ',
'      when no_data_found then ',
'            return false ; ',
'end;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "EXDATE" (currentDate date)',
'return boolean',
'is ',
'found boolean ; ',
'begin ',
'    if sysdate > currentDate then ',
'        return true ;',
'    else ',
'        return false;',
'    end if ; ',
'end;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "EXPIREDATE" (currentDate date)',
'return boolean',
'is ',
'found boolean ; ',
'begin ',
'    if sysdate > currentDate then ',
'        return true ;',
'    else ',
'        return false;',
'    end if ; ',
'end;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ENPWD" (pwd varchar2)',
'return varchar2',
'is ',
'pwd_en varchar2(128) ;',
'begin ',
'   pwd_en := (dbms_crypto.hash (utl_i18n.string_to_raw(pwd, ''AL32UTF8''), dbms_crypto.HASH_SH512));',
'    return pwd_en;',
'end;',
'/',
'',
'CREATE UNIQUE INDEX "COMPLAINS_PK" ON "PH_COMPLAIN" ("COMPLAIN_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_MEDCINE_CON" ON "ph_medcine" ("barcode_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_NOTIFICATION_PK" ON "PH_NOTIFICATION" ("NOT_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_RETURN_MEDCINE_PK" ON "ph_return_medcine" ("return_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_RETURN_PK" ON "ph_return" ("return_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_USERS_PK" ON "ph_users" ("USER_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "PH_USER_ACTIVITY_PK" ON "ph_user_activity" ("activity_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "expenses_pk" ON "ph_expenses" ("expenses_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "expired_medcine_pk" ON "ph_expired_medcine" ("expMedcine_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "income_pk" ON "ph_income" ("income_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "invoice_pk" ON "ph_invoice" ("invoice_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "medcine_pk" ON "ph_medcine" ("medcine_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "orders_medcine_pk" ON "ph_orders_medcine" ("order_medcine_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "orders_pk" ON "ph_orders" ("order_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "ph_providers_pk" ON "ph_providers" ("provider_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "ph_setting_pk" ON "ph_setting" ("setID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "ph_shortcomings_pk" ON "ph_shortcomings" ("shortcoming_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "unit_pk" ON "ph_unit" ("unit_id") ',
'  ;',
'',
'CREATE UNIQUE INDEX "users_username_unique" ON "ph_users" ("USERNAME") ',
'  ;',
'',
'CREATE OR REPLACE EDITIONABLE PROCEDURE "USER_ACTIVITY_LOGOUT" is ',
'begin',
'update "ph_user_activity"  set "logout_date" = sysdate where to_number("session_id") = apex_custom_auth.get_session_id;',
'end;',
'/',
'',
' CREATE SEQUENCE  "PH_USERS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "expenses_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "provider_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "unit_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "income_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "medcine_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "order_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "orders_medcine_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "invoice_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "shortcomings_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "expired_medcine_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "ph_setting_seq"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "PH_NOTIFICATION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "PH_RETURN_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 1 NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "PH_RETURN_MEDCINE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "USER_ACTIVITY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
' CREATE SEQUENCE  "COMPLAINS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "BI_COMPLAINS" ',
'  before insert on "PH_COMPLAIN"               ',
'  for each row  ',
'begin   ',
'  if :NEW."COMPLAIN_ID" is null then ',
'    select "COMPLAINS_SEQ".nextval into :NEW."COMPLAIN_ID" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'',
'',
'ALTER TRIGGER "BI_COMPLAINS" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "BI_PH_NOTIFICATION" ',
'  before insert on "PH_NOTIFICATION"               ',
'  for each row  ',
'begin   ',
'  if :NEW."NOT_ID" is null then ',
'    select "PH_NOTIFICATION_SEQ".nextval into :NEW."NOT_ID" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'',
'',
'ALTER TRIGGER "BI_PH_NOTIFICATION" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "BI_PH_USERS" ',
'  before insert on "ph_users"               ',
'  for each row  ',
'begin   ',
'  if :NEW."USER_ID" is null then ',
'    select "PH_USERS_SEQ".nextval into :NEW."USER_ID" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'',
'',
'ALTER TRIGGER "BI_PH_USERS" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "BI_ph_return_medcine" ',
'  before insert on "ph_return_medcine"               ',
'  for each row  ',
'begin   ',
'  if :NEW."return_id" is null then ',
'    select "PH_RETURN_MEDCINE_SEQ".nextval into :NEW."return_id" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'',
'',
'ALTER TRIGGER "BI_ph_return_medcine" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "BI_ph_user_activity" ',
'  before insert on "ph_user_activity"               ',
'  for each row  ',
'begin   ',
'  if :NEW."activity_id" is null then ',
'    select "USER_ACTIVITY_SEQ".nextval into :NEW."activity_id" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'',
'',
'ALTER TRIGGER "BI_ph_user_activity" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "DEPT_TRG1" ',
'              before insert on dept',
'              for each row',
'              begin',
'                  if :new.deptno is null then',
'                      select dept_seq.nextval into :new.deptno from sys.dual;',
'                 end if;',
'              end;',
'/',
'',
'',
'ALTER TRIGGER "DEPT_TRG1" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "EMP_TRG1" ',
'              before insert on emp',
'              for each row',
'              begin',
'                  if :new.empno is null then',
'                      select emp_seq.nextval into :new.empno from sys.dual;',
'                 end if;',
'              end;',
'/',
'',
'',
'ALTER TRIGGER "EMP_TRG1" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "ph_setting_tri" ',
'    before insert on "ph_setting"',
'    for each row ',
'    begin ',
'    if :new."setID" is null then ',
'        select "ph_setting_seq".nextval into :new."setID" from sys.dual ;',
'    end if ;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "ph_setting_tri" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_expeneses" ',
'before insert on "ph_expenses"',
'for each row ',
'    begin ',
'        if :NEW."expenses_id" is null then',
'        select "expenses_seq".nextval into :NEW."expenses_id" from sys.dual;',
'        end if;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_expeneses" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_expired_medcine" ',
'before insert on "ph_expired_medcine"',
'for each row ',
'    begin ',
'        if :NEW."expMedcine_id" is null then ',
'            select "expired_medcine_seq".nextval into :NEW."expMedcine_id" from sys.dual;',
'        end if ; ',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_expired_medcine" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_hash_pwd" ',
'before insert on "ph_users"',
'for each row ',
'    begin',
'        :NEW."PASSWORD" := GET_ENPWD(:NEW."PASSWORD");',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_hash_pwd" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_income" ',
'before insert on "ph_income"',
'for each row ',
'    begin',
'        if :NEW."income_id" is null then',
'            select "income_seq".nextval into :NEW."income_id" from sys.dual ;',
'        end if;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_income" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_invoice" ',
'before insert on "ph_invoice"',
'for each row ',
'    begin ',
'        if :NEW."invoice_id" is null then ',
'            select "invoice_seq".nextval into :NEW."invoice_id" from sys.dual;',
'        end if;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_invoice" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_medcine" ',
'before insert on "ph_medcine"',
'for each row ',
'    begin ',
'        if :NEW."medcine_id" is null then',
'            select "medcine_seq".nextval into :NEW."medcine_id" from sys.dual;',
'        end if ; ',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_medcine" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_orders" ',
'before insert on "ph_orders"',
'for each row ',
' begin ',
'    if :NEW."order_id" is null then ',
'        select "order_seq".nextval into :NEW."order_id" from sys.dual;',
'    end if ;',
' end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_orders" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_orders_medccine" ',
' before insert on "ph_orders_medcine"',
' for each row ',
'    begin ',
'        if :NEW."order_medcine_id" is null then ',
'            select "orders_medcine_seq".nextval into :NEW."order_medcine_id" from sys.dual;',
'        end if ;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_orders_medccine" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_provider" ',
'before insert on "ph_providers"',
'for each row',
'begin',
'    if :new."provider_id" is null then ',
'        select "provider_seq".nextval into : new."provider_id" from sys.dual;',
'    end if ;',
'end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_provider" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_shortcoming" ',
'before insert on "ph_shortcomings"',
'for each row ',
'    begin ',
'        if :NEW."shortcoming_id" is null then',
'            select "shortcomings_seq".nextval into :NEW."shortcoming_id" from sys.dual;',
'        end if ;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_shortcoming" ENABLE;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "tri_unit" ',
'before insert on "ph_unit"',
'for each row ',
'    begin ',
'        if :NEW."unit_id" is null then ',
'            select "unit_seq".nextval into :NEW."unit_id" from sys.dual;',
'        end if ;',
'    end;',
'',
'/',
'',
'',
'ALTER TRIGGER "tri_unit" ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34800415903067443)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'AUTHETICATE'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34800626351067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CHECKMEDCINE'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34800868702067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'EXDATE'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34801076799067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'EXPIREDATE'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34801259857067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'GET_ENPWD'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34801417022067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'COMPLAINS_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34801695114067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_MEDCINE_CON'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34801826785067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_NOTIFICATION_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34802068311067457)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_RETURN_MEDCINE_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34802277183067459)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_RETURN_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34802403268067459)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_USERS_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34802676901067459)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'PH_USER_ACTIVITY_PK'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34802819582067459)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'expenses_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34803038933067459)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'expired_medcine_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34803271780067460)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'income_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34803400472067460)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'invoice_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34803651146067460)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'medcine_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34803888332067460)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'orders_medcine_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34804030048067460)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'orders_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34804230595067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ph_providers_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34804434904067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ph_setting_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34804640414067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ph_shortcomings_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34804835728067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'unit_pk'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34805030501067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'users_username_unique'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34805285501067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'USER_ACTIVITY_LOGOUT'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34805474860067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'COMPLAINS_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34805640611067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'PH_NOTIFICATION_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34805850653067462)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'PH_RETURN_MEDCINE_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34806094603067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'PH_RETURN_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34806229743067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'PH_USERS_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34806440330067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'USER_ACTIVITY_SEQ'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34806638309067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'expenses_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34806862754067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'expired_medcine_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34807035075067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'income_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34807292244067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'invoice_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34807466473067465)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'medcine_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34807678315067467)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'order_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34807820345067467)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'orders_medcine_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34808052089067467)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'ph_setting_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34808229870067468)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'provider_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34808446490067468)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'shortcomings_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34808611771067468)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'unit_seq'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34808828985067470)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DEPT'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34809002525067470)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EMP'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34809232685067470)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PH_COMPLAIN'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34809489521067470)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PH_NOTIFICATION'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34809685938067470)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_expenses'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34809885872067471)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_expired_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34810071413067471)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_income'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34810237292067471)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_invoice'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34810470381067473)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34810608197067473)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_orders'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34810808366067473)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_orders_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34811027161067473)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_providers'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34811280587067475)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_return'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34811453610067475)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_return_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34811608801067475)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_setting'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34811808046067475)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_shortcomings'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34812022777067475)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_unit'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34812233721067476)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_user_activity'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34812417675067476)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ph_users'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34812641348067476)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_COMPLAINS'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34812854193067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_PH_NOTIFICATION'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34813036223067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_PH_USERS'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34813209418067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_ph_return_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34813403509067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_ph_user_activity'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34813657241067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'DEPT_TRG1'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34813853683067478)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EMP_TRG1'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34814072164067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'ph_setting_tri'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34814204022067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_expeneses'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34814472296067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_expired_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34814671003067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_hash_pwd'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34814842776067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_income'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34815009651067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_invoice'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34815278856067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_medcine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34815458881067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_orders'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34815663650067481)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_orders_medccine'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34815872223067482)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_provider'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34816064533067482)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_shortcoming'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(34816222823067482)
,p_script_id=>wwv_flow_imp.id(34800316786067398)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'tri_unit'
,p_last_updated_by=>'WASEAM'
,p_last_updated_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
,p_created_by=>'WASEAM'
,p_created_on=>to_date('20240221020119','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
