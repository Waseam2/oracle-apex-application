prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(24701109188650923)
,p_translation_flow_id=>123456
,p_translation_flow_language_cd=>'ar-eg'
,p_direction_right_to_left=>'Y'
);
wwv_flow_imp.component_end;
end;
/
