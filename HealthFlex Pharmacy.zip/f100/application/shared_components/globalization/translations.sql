prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24701252584688548)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20611159113544719.123456)
,p_translate_from_id=>wwv_flow_imp.id(20611159113544719)
,p_translate_column_id=>3
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\062E\0637\0623 \0641\064A \0639\0645\0644\064A\0647 \062C\0644\0628 \0627\0644\0627\0634\0639\0627\0631\0627\062A'),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Error in Getnotify process ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24701314945688567)
,p_page_id=>0
,p_translated_flow_id=>123456
,p_translate_to_id=>.123456
,p_translate_from_id=>0
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\0641\062D\0647 \0627\0644\0639\0627\0645\0647')
,p_translate_from_text=>'Global Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24701594098688568)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>1.123456
,p_translate_from_id=>1
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0626\064A\0633\064A\0647')
,p_translate_from_text=>'Home'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24701737018688568)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>2.123456
,p_translate_from_id=>2
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\063A\064A\064A\0631 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'change password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24701960848688570)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>3.123456
,p_translate_from_id=>3
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0628\064A\0639')
,p_translate_from_text=>'Sell Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24702113882688570)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>4.123456
,p_translate_from_id=>4
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0634\0631\0627\0621')
,p_translate_from_text=>'Buy Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24702314390688570)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>5.123456
,p_translate_from_id=>5
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24702590721688570)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>6.123456
,p_translate_from_id=>6
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647 \0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Add User'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24702754687688570)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>7.123456
,p_translate_from_id=>7
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24702989829688570)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>8.123456
,p_translate_from_id=>8
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0648\062D\062F\0627\062A')
,p_translate_from_text=>'Unit menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24703176674688570)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>9.123456
,p_translate_from_id=>9
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0648\062D\062F\0647')
,p_translate_from_text=>'Add Unit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24703355657688570)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>10.123456
,p_translate_from_id=>10
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0648\0631\062F\064A\0646')
,p_translate_from_text=>'Provider Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24703560084688571)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>11.123456
,p_translate_from_id=>11
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0645\0648\0631\062F')
,p_translate_from_text=>'Add provider'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24703763615688571)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>12.123456
,p_translate_from_id=>12
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medcine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24703944814688571)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>13.123456
,p_translate_from_id=>13
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \062F\0648\0627\0621')
,p_translate_from_text=>'add medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24704113631688571)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>14.123456
,p_translate_from_id=>14
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062E\062A\0628\0627\0631')
,p_translate_from_text=>'test'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24704314884688571)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>15.123456
,p_translate_from_id=>15
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\062F\0627\062F\0627\062A \0627\0644\0639\0627\0645\0647')
,p_translate_from_text=>'public setting'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24704590770688571)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>16.123456
,p_translate_from_id=>16
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'Invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24704749429688571)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>17.123456
,p_translate_from_id=>17
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0634\0639\0627\0631\0627\062A')
,p_translate_from_text=>'Notification'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24704952485688571)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>18.123456
,p_translate_from_id=>18
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0631\0627\0621 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'buy medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24705118838688571)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>19.123456
,p_translate_from_id=>19
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'Returns'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24705387851688571)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>20.123456
,p_translate_from_id=>20
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24705520561688573)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>21.123456
,p_translate_from_id=>21
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A')
,p_translate_from_text=>'outgoings'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24705794865688573)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>22.123456
,p_translate_from_id=>22
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24705936196688573)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>23.123456
,p_translate_from_id=>23
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Returned Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24706161518688573)
,p_page_id=>24
,p_translated_flow_id=>123456
,p_translate_to_id=>24.123456
,p_translate_from_id=>24
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062D\0635\0648\0644 \0639\0644\064A \0627\0644\0637\0644\0628')
,p_translate_from_text=>'Get Orders'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24706358160688573)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>25.123456
,p_translate_from_id=>25
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0635\0641\062D\0647 \0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'retruned Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24706578375688573)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>26.123456
,p_translate_from_id=>26
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0647 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expiredDate Medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24706735190688573)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>27.123456
,p_translate_from_id=>27
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644 \0627\0644\0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'Edit Data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24706921304688573)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>28.123456
,p_translate_from_id=>28
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'return Medicine'
,p_translate_from_text=>'return Medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24707110332688573)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>29.123456
,p_translate_from_id=>29
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'annual financial report'
,p_translate_from_text=>'annual financial report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24707358855688573)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>30.123456
,p_translate_from_id=>30
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Statistics'
,p_translate_from_text=>'Statistics'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24707529946688576)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>31.123456
,p_translate_from_id=>31
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Add Complain'
,p_translate_from_text=>'Add Complain'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24707796709688576)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>34.123456
,p_translate_from_id=>34
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'show complains'
,p_translate_from_text=>'show complains'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24707911370688576)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>10010.123456
,p_translate_from_id=>10010
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'About'
,p_translate_from_text=>'About'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24708172338688576)
,p_page_id=>10011
,p_translated_flow_id=>123456
,p_translate_to_id=>10011.123456
,p_translate_from_id=>10011
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Help'
,p_translate_from_text=>'Help'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24708306984688578)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>9999.123456
,p_translate_from_id=>9999
,p_translate_column_id=>5
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Login Page'
,p_translate_from_text=>'Login Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24708506216688582)
,p_page_id=>0
,p_translated_flow_id=>123456
,p_translate_to_id=>.123456
,p_translate_from_id=>0
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Global Page'
,p_translate_from_text=>'Global Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24708714055688582)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>1.123456
,p_translate_from_id=>1
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Pharmacy'
,p_translate_from_text=>'Pharmacy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24708954913688582)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>2.123456
,p_translate_from_id=>2
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\063A\064A\064A\0631 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'change password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24709116316688582)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>3.123456
,p_translate_from_id=>3
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0628\064A\0639')
,p_translate_from_text=>'Sell Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24709312921688582)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>4.123456
,p_translate_from_id=>4
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0634\0631\0627\0621')
,p_translate_from_text=>'Buy Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24709597361688582)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>5.123456
,p_translate_from_id=>5
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24709796060688582)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>6.123456
,p_translate_from_id=>6
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647 \0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Add User'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24709931964688584)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>7.123456
,p_translate_from_id=>7
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24710132037688584)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>8.123456
,p_translate_from_id=>8
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0648\062D\062F\0627\062A')
,p_translate_from_text=>'Unit menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24710329143688584)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>9.123456
,p_translate_from_id=>9
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0648\062D\062F\0647')
,p_translate_from_text=>'Add Unit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24710545569688584)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>10.123456
,p_translate_from_id=>10
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0648\0631\062F\064A\0646')
,p_translate_from_text=>'Provider Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24710759042688584)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>11.123456
,p_translate_from_id=>11
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0645\0648\0631\062F')
,p_translate_from_text=>'Add provider'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24710920694688584)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>12.123456
,p_translate_from_id=>12
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medcine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24711142309688584)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>13.123456
,p_translate_from_id=>13
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \062F\0648\0627\0621')
,p_translate_from_text=>'add medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24711340381688587)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>14.123456
,p_translate_from_id=>14
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062E\062A\0628\0627\0631')
,p_translate_from_text=>'test'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24711559015688587)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>15.123456
,p_translate_from_id=>15
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\062F\0627\062F\0627\062A \0627\0644\0639\0627\0645\0647')
,p_translate_from_text=>'public setting'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24711702097688587)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>16.123456
,p_translate_from_id=>16
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'Invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24711989732688587)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>17.123456
,p_translate_from_id=>17
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0634\0639\0627\0631\0627\062A')
,p_translate_from_text=>'Notification'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24712176273688587)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>18.123456
,p_translate_from_id=>18
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0631\0627\0621 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'buy medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24712376942688587)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>19.123456
,p_translate_from_id=>19
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'Returns'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24712581566688587)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>20.123456
,p_translate_from_id=>20
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24712732108688587)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>21.123456
,p_translate_from_id=>21
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A')
,p_translate_from_text=>'outgoings'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24712969665688587)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>22.123456
,p_translate_from_id=>22
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24713107646688587)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>23.123456
,p_translate_from_id=>23
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Returned Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24713398566688587)
,p_page_id=>24
,p_translated_flow_id=>123456
,p_translate_to_id=>24.123456
,p_translate_from_id=>24
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062D\0635\0648\0644 \0639\0644\064A \0627\0644\0637\0644\0628')
,p_translate_from_text=>'Get Orders'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24713559903688590)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>25.123456
,p_translate_from_id=>25
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0635\0641\062D\0647 \0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'retruned Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24713774564688590)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>26.123456
,p_translate_from_id=>26
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0647 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expiredDate Medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24713962879688590)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>27.123456
,p_translate_from_id=>27
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644 \0627\0644\0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'Edit Data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24714150246688590)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>28.123456
,p_translate_from_id=>28
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0631\062A\062C\0639 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'return Medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24714357355688590)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>29.123456
,p_translate_from_id=>29
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062A\0642\0631\064A\0631 \0627\0644\0645\0627\0644\064A \0627\0644\0633\0646\0648\064A ')
,p_translate_from_text=>'annual financial report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24714584190688592)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>30.123456
,p_translate_from_id=>30
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062D\0635\0627\0626\064A\0627\062A')
,p_translate_from_text=>'Statistics'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24714744720688592)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>31.123456
,p_translate_from_id=>31
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0634\0643\0648\064A')
,p_translate_from_text=>'Add Complain'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24714935718688592)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>34.123456
,p_translate_from_id=>34
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0638\0647\0627\0631 \0627\0644\0634\0643\0627\0648\064A')
,p_translate_from_text=>'show complains'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24715164646688592)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>10010.123456
,p_translate_from_id=>10010
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0648\0644')
,p_translate_from_text=>'About'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24715327199688592)
,p_page_id=>10011
,p_translated_flow_id=>123456
,p_translate_to_id=>10011.123456
,p_translate_from_id=>10011
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\0627\0639\062F\0647')
,p_translate_from_text=>'Help'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24715564304688592)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>9999.123456
,p_translate_from_id=>9999
,p_translate_column_id=>6
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\064A\062F\0644\064A\0647 - \062A\0633\062C\064A\0644 \0627\0644\062F\062E\0648\0644')
,p_translate_from_text=>'Pharmacy - Log In'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24715738702688614)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>10010.123456
,p_translate_from_id=>10010
,p_translate_column_id=>12
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_translate_from_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24715938848688620)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917353434930327.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917353434930327)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0623\0643\064A\062F')
,p_translate_from_text=>'Confirm'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24716174872688620)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12405340535263341.123456)
,p_translate_from_id=>wwv_flow_imp.id(12405340535263341)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24716371919688620)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12405302477263340.123456)
,p_translate_from_id=>wwv_flow_imp.id(12405302477263340)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'Invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24716506282688620)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25603038122020017.123456)
,p_translate_from_id=>wwv_flow_imp.id(25603038122020017)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'Invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24716779006688620)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25603251642020019.123456)
,p_translate_from_id=>wwv_flow_imp.id(25603251642020019)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24716934687688620)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7313962775037600.123456)
,p_translate_from_id=>wwv_flow_imp.id(7313962775037600)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647 \0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Add User'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24717182107688620)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6916867843930322.123456)
,p_translate_from_id=>wwv_flow_imp.id(6916867843930322)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\063A\064A\064A\0631 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'change password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24717340087688621)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7306388527037516.123456)
,p_translate_from_id=>wwv_flow_imp.id(7306388527037516)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24717439488688621)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7307799084037538.123456)
,p_translate_from_id=>wwv_flow_imp.id(7307799084037538)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24717680078688623)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7308193412037538.123456)
,p_translate_from_id=>wwv_flow_imp.id(7308193412037538)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'SAVE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24717838802688623)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7308562159037538.123456)
,p_translate_from_id=>wwv_flow_imp.id(7308562159037538)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647')
,p_translate_from_text=>'Add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24718008034688623)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202442562481915.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202442562481915)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\062C\0648\0639')
,p_translate_from_text=>'back'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24718236906688623)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202257808481913.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202257808481913)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0628\0627\0639\0647')
,p_translate_from_text=>'Print'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24718452934688623)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202356006481914.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202356006481914)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0645')
,p_translate_from_text=>'done'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24718630129688625)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10308659723912571.123456)
,p_translate_from_id=>wwv_flow_imp.id(10308659723912571)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0648\062D\062F\0647')
,p_translate_from_text=>'Add Unit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24718832325688625)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10303065175912461.123456)
,p_translate_from_id=>wwv_flow_imp.id(10303065175912461)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24719034345688625)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10304519726912488.123456)
,p_translate_from_id=>wwv_flow_imp.id(10304519726912488)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24719297046688625)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10304894075912488.123456)
,p_translate_from_id=>wwv_flow_imp.id(10304894075912488)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'Save'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24719428709688625)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10305290152912488.123456)
,p_translate_from_id=>wwv_flow_imp.id(10305290152912488)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647')
,p_translate_from_text=>'Add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24719680971688625)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10602674723239825.123456)
,p_translate_from_id=>wwv_flow_imp.id(10602674723239825)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0645\0648\0631\062F')
,p_translate_from_text=>'Add Provider'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24719898942688625)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10705549547257042.123456)
,p_translate_from_id=>wwv_flow_imp.id(10705549547257042)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24720051754688628)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10706932219257050.123456)
,p_translate_from_id=>wwv_flow_imp.id(10706932219257050)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24720279099688628)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10707398584257053.123456)
,p_translate_from_id=>wwv_flow_imp.id(10707398584257053)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'SAVE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24720412037688628)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10707793630257053.123456)
,p_translate_from_id=>wwv_flow_imp.id(10707793630257053)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647')
,p_translate_from_text=>'Add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24720658874688628)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11614386267472746.123456)
,p_translate_from_id=>wwv_flow_imp.id(11614386267472746)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \062F\0648\0627\0621')
,p_translate_from_text=>'add medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24720897557688628)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11606641871472671.123456)
,p_translate_from_id=>wwv_flow_imp.id(11606641871472671)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24721010087688628)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11608077732472691.123456)
,p_translate_from_id=>wwv_flow_imp.id(11608077732472691)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24721299544688628)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11608495610472691.123456)
,p_translate_from_id=>wwv_flow_imp.id(11608495610472691)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'save'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24721419235688628)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11608849090472691.123456)
,p_translate_from_id=>wwv_flow_imp.id(11608849090472691)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647')
,p_translate_from_text=>'add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24721676976688628)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16506367695569043.123456)
,p_translate_from_id=>wwv_flow_imp.id(16506367695569043)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0628\0627\0639\0647')
,p_translate_from_text=>'Print'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24721829094688631)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504937336569029.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504937336569029)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'Save'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24722027511688631)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309079472993639.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309079472993639)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D \0627\0644\0643\0644 ')
,p_translate_from_text=>'Clear All'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24722229979688631)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309191243993640.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309191243993640)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\062D\062F\064A\062B')
,p_translate_from_text=>'refresh'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24722482927688631)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709608135626625.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709608135626625)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24722698415688631)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709685176626626.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709685176626626)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0631\0627\0621')
,p_translate_from_text=>'Buy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24722872747688631)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712475216244106.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712475216244106)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0645')
,p_translate_from_text=>'Done'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24723007470688631)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712417894244105.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712417894244105)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24723290250688632)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103681384172518.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103681384172518)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24723401787688632)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103377945172515.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103377945172515)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'Save'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24723612774688632)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30904026474085172.123456)
,p_translate_from_id=>wwv_flow_imp.id(30904026474085172)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24723874496688632)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30906198797085280.123456)
,p_translate_from_id=>wwv_flow_imp.id(30906198797085280)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0641\0638')
,p_translate_from_text=>'Save'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24724021244688632)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15806832816616135.123456)
,p_translate_from_id=>wwv_flow_imp.id(15806832816616135)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24724217238688632)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15806220197616125.123456)
,p_translate_from_id=>wwv_flow_imp.id(15806220197616125)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0644\063A\0627\0621')
,p_translate_from_text=>'Cancel'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24724411949688632)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15807284126616139.123456)
,p_translate_from_id=>wwv_flow_imp.id(15807284126616139)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0637\0628\064A\0642 \0627\0644\062A\063A\064A\0631\0627\062A')
,p_translate_from_text=>'Apply Changes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24724602591688634)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15807664924616139.123456)
,p_translate_from_id=>wwv_flow_imp.id(15807664924616139)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0639\0645\0644')
,p_translate_from_text=>'Create'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24724844972688634)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6906001604923449.123456)
,p_translate_from_id=>wwv_flow_imp.id(6906001604923449)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0633\062C\064A\0644 \0627\0644\062F\062E\0648\0644')
,p_translate_from_text=>'Sign In'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24725004031688642)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12405340535263341.123456)
,p_translate_from_id=>wwv_flow_imp.id(12405340535263341)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'are you sure you want to leave ? '
,p_translate_from_text=>'are you sure you want to leave ? '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24725203527688642)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7307799084037538.123456)
,p_translate_from_id=>wwv_flow_imp.id(7307799084037538)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_translate_from_text=>'&APP_TEXT$DELETE_MSG!RAW.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24725422941688642)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10304519726912488.123456)
,p_translate_from_id=>wwv_flow_imp.id(10304519726912488)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_translate_from_text=>'&APP_TEXT$DELETE_MSG!RAW.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24725620206688642)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10706932219257050.123456)
,p_translate_from_id=>wwv_flow_imp.id(10706932219257050)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_translate_from_text=>'&APP_TEXT$DELETE_MSG!RAW.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24725895958688642)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11608077732472691.123456)
,p_translate_from_id=>wwv_flow_imp.id(11608077732472691)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_translate_from_text=>'&APP_TEXT$DELETE_MSG!RAW.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24726043247688643)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15806832816616135.123456)
,p_translate_from_id=>wwv_flow_imp.id(15806832816616135)
,p_translate_column_id=>13.1
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_translate_from_text=>'&APP_TEXT$DELETE_MSG!RAW.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24726218039688648)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Date'
,p_translate_from_text=>'Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24726485171688648)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917144013930325.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917144013930325)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631 \0627\0644\062C\062F\064A\062F\0647')
,p_translate_from_text=>'New password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24726682062688648)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917304835930326.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917304835930326)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0643\064A\062F \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'confirm password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24726852938688648)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24727037888688648)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712935017244111.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712935017244111)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Client Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24727246134688648)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24727421198688648)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24727672788688648)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301216024037477.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301216024037477)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'User Id'
,p_translate_from_text=>'User Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24727899184688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301567068037497.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301567068037497)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0633\0645')
,p_translate_from_text=>'Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24728055564688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301883712037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301883712037508)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\064A\0644\064A\0641\0648\0646')
,p_translate_from_text=>'Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24728294639688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302236384037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302236384037508)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\064A\0645\064A\0644')
,p_translate_from_text=>'Email'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24728425586688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302636680037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302636680037510)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0631')
,p_translate_from_text=>'Role'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24728619144688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501710324065215.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501710324065215)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0634\0637')
,p_translate_from_text=>'Active'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24728881203688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7303049088037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7303049088037510)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Username'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24729004025688650)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914514540930298.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914514540930298)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'Password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24729269809688650)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24729444839688651)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301253140912417.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301253140912417)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Unit Id'
,p_translate_from_text=>'Unit Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24729616712688651)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301676580912439.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301676580912439)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24729825872688651)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24730028039688651)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10700974664257016.123456)
,p_translate_from_id=>wwv_flow_imp.id(10700974664257016)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Provider Id'
,p_translate_from_text=>'Provider Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24730257919688651)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701422288257024.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701422288257024)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24730417713688651)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701766810257030.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701766810257030)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\064A\0644\064A\0641\0648\0646')
,p_translate_from_text=>'Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24730689120688651)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702143502257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702143502257033)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\064A\0645\064A\0644')
,p_translate_from_text=>'Email'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24730814943688651)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702534557257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702534557257033)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0635\064A\062F')
,p_translate_from_text=>'Balance'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24731090067688653)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702993425257035.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702993425257035)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24731256242688653)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24731402717688653)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11601175040472569.123456)
,p_translate_from_id=>wwv_flow_imp.id(11601175040472569)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Medcine Id'
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24731675463688653)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11601613597472603.123456)
,p_translate_from_id=>wwv_flow_imp.id(11601613597472603)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\0628\0627\0631\0643\0648\062F')
,p_translate_from_text=>'Barcode Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24731831428688654)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602014103472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602014103472621)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24732067362688654)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602395820472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602395820472621)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24732273075688654)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603033167472656.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603033167472656)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0634\0631\0627\0621')
,p_translate_from_text=>'Buy Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24732401491688654)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603512474472656.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603512474472656)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0628\064A\0639')
,p_translate_from_text=>'Sell Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24732678572688656)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14203027471481920.123456)
,p_translate_from_id=>wwv_flow_imp.id(14203027471481920)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24732856304688656)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24733040127688656)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602880090020015.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602880090020015)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24733246129688656)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203193855959713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203193855959713)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_translate_from_text=>'Notes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24733492492688657)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504233392569022.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504233392569022)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24733694923688657)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504747106569027.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504747106569027)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0642\0644 \0643\0645\064A\0647')
,p_translate_from_text=>'Minmum Quantitiy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24733808603688657)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714644225244128.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714644225244128)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062F\0647 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Returned Duration'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24734023759688657)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504882325569028.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504882325569028)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0642\0644 \062A\0627\0631\064A\062E ')
,p_translate_from_text=>'Minimum date '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24734255950688659)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16505226003569031.123456)
,p_translate_from_id=>wwv_flow_imp.id(16505226003569031)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062E\0631 \062A\0627\0631\064A\062E ')
,p_translate_from_text=>'Last Minimum Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24734476946688659)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E')
,p_translate_from_text=>'Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24734612357688659)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307600621993624.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307600621993624)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24734860600688659)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307659936993625.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307659936993625)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0637\0644\0628')
,p_translate_from_text=>'order id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24735015203688659)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709175971626621.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709175971626621)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medicine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24735269203688660)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709232909626622.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709232909626622)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0628\0627\0631\0643\0648\062F')
,p_translate_from_text=>'barcode'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24735477537688660)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710215221626631.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710215221626631)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0634\0631\0627\0621')
,p_translate_from_text=>'Buy Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24735618435688660)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709342886626623.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709342886626623)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24735840491688660)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expired date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24736000750688660)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602768264020014.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602768264020014)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24736225465688660)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106280260172544.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106280260172544)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24736430225688665)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106379850172545.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106379850172545)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24736652477688665)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106447004172546.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106447004172546)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062C\0645\0627\0644\064A')
,p_translate_from_text=>'total'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24736826941688665)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631487138889622.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631487138889622)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647r')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24737047975688665)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631557873889623.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631557873889623)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24737216833688667)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632274450889630.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632274450889630)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062C\0645\0627\0644\064A ')
,p_translate_from_text=>'Total'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24737481426688667)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605459736020041.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605459736020041)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647r')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24737665039688667)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605625775020042.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605625775020042)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24737827538688670)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605655445020043.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605655445020043)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062C\0645\0627\0644\064A ')
,p_translate_from_text=>'Total'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24738040094688670)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709569867291102.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709569867291102)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Medcine Search'
,p_translate_from_text=>'Medcine Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24738268446688670)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713279186244114.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713279186244114)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\0637\0644\0628')
,p_translate_from_text=>'Order Number'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24738497387688670)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713378822244115.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713378822244115)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Client Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24738686759688670)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103177163172513.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103177163172513)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medicine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24738855421688670)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103796631172519.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103796631172519)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24739080356688671)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103293281172514.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103293281172514)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0643\0645\064A\0647 \0627\0644\0645\0631\062A\062C\0639 ')
,p_translate_from_text=>'Quantity return '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24739287884688671)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901867395085160.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901867395085160)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24739456520688671)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28711977230291126.123456)
,p_translate_from_id=>wwv_flow_imp.id(28711977230291126)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24739679733688671)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712130133291127.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712130133291127)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0633\0633\0645\0627\062D \0628 \0627\0644\0643\0645\064A\0647 \0627\0644\0645\0631\062A\062C\0639\0647')
,p_translate_from_text=>'Allow Returned Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24739831208688671)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30902317031085169.123456)
,p_translate_from_id=>wwv_flow_imp.id(30902317031085169)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0628\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Return Reason'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24740092079688671)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306908240261634.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306908240261634)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24740203959688671)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001546580605315.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001546580605315)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24740425391688675)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503397188891533.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503397188891533)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24740674117688675)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002156806605321.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002156806605321)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24740852813688675)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002949104605329.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002949104605329)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647 ')
,p_translate_from_text=>'Year '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24741026826688675)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003966260605339.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003966260605339)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24741215181688675)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504538143891545.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504538143891545)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24741423232688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20100802369048604.123456)
,p_translate_from_id=>wwv_flow_imp.id(20100802369048604)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647')
,p_translate_from_text=>'year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24741688725688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101647605048612.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101647605048612)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0647r')
,p_translate_from_text=>'Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24741831721688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001235166605312.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001235166605312)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24742082213688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503409893891534.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503409893891534)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'month'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24742227556688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003048038605330.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003048038605330)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24742407946688676)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504622845891546.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504622845891546)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24742656816688678)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101744232048613.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101744232048613)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24742803826688678)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504700465891547.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504700465891547)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0627\0621 \0627\0644\0627\0639\0644\064A ')
,p_translate_from_text=>'Top Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24743093059688678)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803524366616106.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803524366616106)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Customer Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24743281849688678)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803901538616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803901538616107)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \062A\064A\0644\064A\0641\0648\0646 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Customer Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24743436847688679)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15804390414616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15804390414616107)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062D\062A\0648\064A \0627\0644\0634\0643\0648\064A')
,p_translate_from_text=>'Complain Text'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24743684024688679)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502853568891528.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502853568891528)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24743819922688679)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24744084875688679)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6905147704923424.123456)
,p_translate_from_id=>wwv_flow_imp.id(6905147704923424)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'Password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24744266083688679)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6905582533923442.123456)
,p_translate_from_id=>wwv_flow_imp.id(6905582533923442)
,p_translate_column_id=>14
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0630\0643\0631 \0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Remember username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24744479214688687)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917433950930328.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917433950930328)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631 \063A\064A\0631 \0645\062A\0637\0627\0628\0642\0647 ')
,p_translate_from_text=>'passwords not match'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24744659644688689)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20102023865048616.123456)
,p_translate_from_id=>wwv_flow_imp.id(20102023865048616)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0646 \0641\0636\0644\0643 \0627\062F\062E\0644 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'Please Enter The Password!'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24744838816688689)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601077828019997.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601077828019997)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' \064A\062C\0628 \0627\0646 \064A\062D\062A\0648\064A \0639\0644\064A \0628\064A\0627\0646\0627\062A #LABEL# ')
,p_translate_from_text=>'#LABEL# must have some value.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24745070063688689)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601239181019999.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601239181019999)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' \064A\062C\0628 \0627\0646 \064A\062D\062A\0648\064A \0639\0644\064A \0628\064A\0627\0646\0627\062A #LABEL# ')
,p_translate_from_text=>'#LABEL# must have some value.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24745252455688689)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34104110308172522.123456)
,p_translate_from_id=>wwv_flow_imp.id(34104110308172522)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\0627\0644\0643\0645\064A\0647 \062E\0627\0631\062C \0627\0644\0645\062F\064A  '),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'the Quantity out of range ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24745498776688689)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712469106291131.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712469106291131)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\0627\0644\0643\0645\064A\0647 \0627\0644\0645\0631\062A\062C\0639\0647 \0644\0627 \064A\0645\0643\0646 \0627\0646 \062A\0643\0648\0646 \0627\0643\0628\0631 \0645\0646 \0627\0644\0643\0645\064A\0647 \0627\0644\0645\0633\0645\0648\062D\0647 '),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The returned Quantity can''t be more than allow quantity ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24745611851688689)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712831615291134.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712831615291134)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0645\0643\0646\0643 \0627\0631\062C\0627\0639 \0647\0630\0627 \0627\0644\062F\0648\0627\0621 ')
,p_translate_from_text=>'you can''t return this medcine no medcine allowed to return '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24745882035688690)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501816458065216.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501816458065216)
,p_translate_column_id=>16
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span>This Account is <span style="color:red">Locked</span> Please Call The Administrator !</span>'
,p_translate_from_text=>'<span>This Account is <span style="color:red">Locked</span> Please Call The Administrator !</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24746015803688698)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918024597930333.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918024597930333)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062E\0637\0623 \0644\0627 \064A\0645\0643\0646 \062A\063A\064A\064A\0631 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'Error password can''t change'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24746231477688698)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' #SQLERRM_TEXT# \0627\0644\0639\0645\0644\064A\0647 \0641\0634\0644\062A')
,p_translate_from_text=>'process failed  #SQLERRM_TEXT#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24746468881688698)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309742207037546.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309742207037546)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \0641\0634\0644\062A')
,p_translate_from_text=>'process failed'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24746680095688698)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305577872993604.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305577872993604)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\0641\0634\0644 &P7_ORDER_ID. \0627\0644\0637\0644\0628 .'),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'order &P7_ORDER_ID. failed .',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24746814150688698)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \0641\0634\0644\062A')
,p_translate_from_text=>'proccess failed'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24747001358688698)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708958451257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708958451257060)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \0641\0634\0644\062A')
,p_translate_from_text=>'proccess failed'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24747297234688700)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16505275160569032.123456)
,p_translate_from_id=>wwv_flow_imp.id(16505275160569032)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062E\0637\0623 \0641\064A \0627\0644\062A\062D\062F\064A\062B ')
,p_translate_from_text=>'error in update '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24747420182688700)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710299139626632.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710299139626632)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr(' #SQLERRM_TEXT# \0627\0644\0627\0636\0627\0641\0647 \0641\0634\0644\062A'),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'add failed  #SQLERRM_TEXT#',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24747693735688700)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712883100291135.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712883100291135)
,p_translate_column_id=>17
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0636\0627\0641\0647 \0641\0634\0644\062A')
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'add failed',
'',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24747816959688706)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918024597930333.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918024597930333)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0645 \062A\062D\062F\064A\062B \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631 \0628\0646\062C\0627\062D')
,p_translate_from_text=>'password update successfully'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24748057682688706)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \062A\0645\062A \0628\0646\062C\0627\062D')
,p_translate_from_text=>'process complete successfully'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24748207558688706)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309742207037546.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309742207037546)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \062A\0645\062A \0628\0646\062C\0627\062D')
,p_translate_from_text=>'process complete successfully'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24748487839688706)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305577872993604.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305577872993604)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\0627\0643\062A\0645\0644 \0628\0646\062C\0627\062D &P7_ORDER_ID.  \0627\0644\0637\0644\0628 '),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'order &P7_ORDER_ID. successfully completed',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24748628860688707)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \062A\0645\062A \0628\0646\062C\0627\062D')
,p_translate_from_text=>'proccess complete successfully'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24748807877688707)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708958451257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708958451257060)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0639\0645\0644\064A\0647 \062A\0645\062A \0628\0646\062C\0627\062D')
,p_translate_from_text=>'proccess complete successfully'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749033189688707)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16505275160569032.123456)
,p_translate_from_id=>wwv_flow_imp.id(16505275160569032)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0645 \0627\0644\062A\062D\062F\064A\062B \0628\0646\062C\0627\062D')
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update successfully',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749292847688709)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710299139626632.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710299139626632)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' \062A\0645 \0627\0644\0627\0636\0627\0641\0647 \0628\0646\062C\0627\062D')
,p_translate_from_text=>'add successfully to chart '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749463906688709)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712883100291135.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712883100291135)
,p_translate_column_id=>18
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' \062A\0645 \0627\0644\0627\0636\0627\0641\0647 \0628\0646\062C\0627\062D')
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'add successfully',
'',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749677428688725)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6908711381923486.123456)
,p_translate_from_id=>wwv_flow_imp.id(6908711381923486)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0635\064A\062F\0644\064A\0647 ')
,p_translate_from_text=>'Pharmacy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749712069688726)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8502438786065222.123456)
,p_translate_from_id=>wwv_flow_imp.id(8502438786065222)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0646\0634\0637\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Activity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24749921935688726)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8500516064065203.123456)
,p_translate_from_id=>wwv_flow_imp.id(8500516064065203)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\062F\0648\064A\0647 \0645\0646\062E\0641\0636\0647 \0627\0644\0645\062E\0632\0648\0646')
,p_translate_from_text=>'Low Stock Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24750127730688726)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0629 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired medcine '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24750336645688726)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917013588930323.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917013588930323)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062A\063A\064A\064A\0631 \0643\0644\0645\0647 \0627\0644\0645\0631\0648\0631')
,p_translate_from_text=>'change password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24750566921688726)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401248112263300.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401248112263300)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medicine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24750770215688726)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401122031263298.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401122031263298)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24750932347688726)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12400948634263297.123456)
,p_translate_from_id=>wwv_flow_imp.id(12400948634263297)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0628\062D\062B ')
,p_translate_from_text=>'search '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24751125577688726)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12303172363927499.123456)
,p_translate_from_id=>wwv_flow_imp.id(12303172363927499)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24751344656688726)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24706937930626599.123456)
,p_translate_from_id=>wwv_flow_imp.id(24706937930626599)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medicine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24751555660688726)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710609528626635.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710609528626635)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0637\0644\0628\0627\062A \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medicine  orders'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24751779862688726)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7310739278037575.123456)
,p_translate_from_id=>wwv_flow_imp.id(7310739278037575)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24751955183688729)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30611711086648126.123456)
,p_translate_from_id=>wwv_flow_imp.id(30611711086648126)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\0639\0644\0648\0645\0627\062A\0643')
,p_translate_from_text=>'Your Information'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24752180999688729)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7300827667037460.123456)
,p_translate_from_id=>wwv_flow_imp.id(7300827667037460)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647 \0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Add User'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24752398758688729)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7306020471037514.123456)
,p_translate_from_id=>wwv_flow_imp.id(7306020471037514)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0632\0631\0627\0631')
,p_translate_from_text=>'Buttons'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24752579440688729)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12405071674263338.123456)
,p_translate_from_id=>wwv_flow_imp.id(12405071674263338)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24752749388688731)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202130068481911.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202130068481911)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0644\0627 \062A\0648\062C\062F \0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'no invoice '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24752981026688731)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10307347086912550.123456)
,p_translate_from_id=>wwv_flow_imp.id(10307347086912550)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0648\062D\062F\0627\062A')
,p_translate_from_text=>'Unit menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24753135046688731)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301030663912405.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301030663912405)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0648\062D\062F\0647')
,p_translate_from_text=>'Add Unit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24753305281688731)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10302635953912455.123456)
,p_translate_from_id=>wwv_flow_imp.id(10302635953912455)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0632\0631\0627\0631')
,p_translate_from_text=>'Buttons'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24753557311688732)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17707792188395409.123456)
,p_translate_from_id=>wwv_flow_imp.id(17707792188395409)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0648\0631\062F\064A\0646')
,p_translate_from_text=>'Provider menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24753764079688732)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10700708547257011.123456)
,p_translate_from_id=>wwv_flow_imp.id(10700708547257011)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0645\0648\0631\062F')
,p_translate_from_text=>'Add provider'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24753954048688732)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10705226468257042.123456)
,p_translate_from_id=>wwv_flow_imp.id(10705226468257042)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0632\0631\0627\0631')
,p_translate_from_text=>'Buttons'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24754123676688734)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611128425472722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611128425472722)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medcine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24754323960688734)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11600819465472561.123456)
,p_translate_from_id=>wwv_flow_imp.id(11600819465472561)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \062F\0648\0627\0621')
,p_translate_from_text=>'add medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24754543497688734)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11606329427472671.123456)
,p_translate_from_id=>wwv_flow_imp.id(11606329427472671)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0632\0631\0627\0631')
,p_translate_from_text=>'Buttons'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24754771832688734)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503086156569010.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503086156569010)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24754903500688734)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504678749569026.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504678749569026)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\062F\0627\062F\0627\062A \0627\0644\0639\0627\0645\0647')
,p_translate_from_text=>'public setting'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24755123375688734)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305964111993608.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305964111993608)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'invoices'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24755310556688735)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308013194993628.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308013194993628)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\0634\0639\0627\0631\0627\062A')
,p_translate_from_text=>'notification'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24755574185688735)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708946916626619.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708946916626619)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0634\0631\0627\0621 \062F\0648\0627\0621')
,p_translate_from_text=>'Buy medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24755729705688737)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105452736172536.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105452736172536)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062A\062D\0643\0645')
,p_translate_from_text=>'contorls'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24755941094688737)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105569997172537.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105569997172537)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062A\0642\0631\064A\0631')
,p_translate_from_text=>'report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24756159115688737)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38127836996230391.123456)
,p_translate_from_id=>wwv_flow_imp.id(38127836996230391)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24756370588688737)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10904041108601366.123456)
,p_translate_from_id=>wwv_flow_imp.id(10904041108601366)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0645\0631\062A\062C\0639 (\064A\0648\0645)')
,p_translate_from_text=>'Return Chart Day'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24756521668688739)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(4402396388185417.123456)
,p_translate_from_id=>wwv_flow_imp.id(4402396388185417)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0645\0631\062A\062C\0639 (\0634\0647\0648\0631)')
,p_translate_from_text=>'Return Chart Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24756789854688739)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631351713889621.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631351713889621)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062A\062D\0643\0645')
,p_translate_from_text=>'controls'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24756972973688739)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802265181841591.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802265181841591)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24757194073688739)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709177930291098.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709177930291098)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24757316446688740)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38307470945261640.123456)
,p_translate_from_id=>wwv_flow_imp.id(38307470945261640)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0648\0627\0631\062F\0627\062A (\0627\0644\064A\0648\0645)')
,p_translate_from_text=>'Income Chart day'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24757552572688740)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40702699347108797.123456)
,p_translate_from_id=>wwv_flow_imp.id(40702699347108797)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0648\0627\0631\062F\0627\062A (\0627\0644\0634\0647\0631)')
,p_translate_from_text=>'Income Chart month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24757753789688740)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604958034020036.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604958034020036)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0645\0635\0631\0648\0641\0627\062A')
,p_translate_from_text=>'Expenses '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24757995395688742)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605364868020040.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605364868020040)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062A\062D\0643\0645')
,p_translate_from_text=>'Contols'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24758127744688742)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(27909124296113928.123456)
,p_translate_from_id=>wwv_flow_imp.id(27909124296113928)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24758343134688742)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40703744007108808.123456)
,p_translate_from_id=>wwv_flow_imp.id(40703744007108808)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0645\0635\0648\0641\0627\062A (\0627\0644\064A\0648\0645)')
,p_translate_from_text=>'Outcomings chart day'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24758519351688742)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40703905494108809.123456)
,p_translate_from_id=>wwv_flow_imp.id(40703905494108809)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0645\0635\0648\0641\0627\062A (\0627\0644\0634\0647\0631)')
,p_translate_from_text=>'Outcoming chart month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24758716752688743)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20633655317889644.123456)
,p_translate_from_id=>wwv_flow_imp.id(20633655317889644)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24758952675688743)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24216823871695185.123456)
,p_translate_from_id=>wwv_flow_imp.id(24216823871695185)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24759110244688743)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713520427244116.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713520427244116)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062A\0641\0627\0635\064A\0644 \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Detalis'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24759322374688745)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712960119291136.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712960119291136)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0637\0644\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Return Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24759527941688745)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(29106333627879363.123456)
,p_translate_from_id=>wwv_flow_imp.id(29106333627879363)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24759726669688745)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709390409291100.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709390409291100)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062D\0635\0648\0644 \0639\0644\064A \0627\0644\0645\0639\0644\0648\0645\0627\062A')
,p_translate_from_text=>'Get information '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24759974554688745)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710661087291113.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710661087291113)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062A\0641\0627\0635\064A\0644 \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Detalis'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24760121762688745)
,p_page_id=>24
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709911767291105.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709911767291105)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\062E\0631 \0627\0644\0637\0644\0628\0627\062A')
,p_translate_from_text=>'last orders'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24760356284688745)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715324531244134.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715324531244134)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062D\0635\0648\0644 \0639\0644\064A \0627\0644\0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'get Data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24760555805688745)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715377867244235.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715377867244235)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'medicine data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24760798217688745)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24220134275728472.123456)
,p_translate_from_id=>wwv_flow_imp.id(24220134275728472)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24760951284688745)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24220807042728477.123456)
,p_translate_from_id=>wwv_flow_imp.id(24220807042728477)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0647 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expiredDate Medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24761148522688745)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103030968172511.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103030968172511)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644 \0627\0644\0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'Edit Data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24761377548688748)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901231401085124.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901231401085124)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0645\0631\062A\062C\0639 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'return Medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24761570490688748)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30903563778085172.123456)
,p_translate_from_id=>wwv_flow_imp.id(30903563778085172)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0632\0631\0627\0631')
,p_translate_from_text=>'Buttons'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24761736611688748)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303608551261601.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303608551261601)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0645\062E\0637\0637')
,p_translate_from_text=>'chart'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24761936373688748)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306492416261630.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306492416261630)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A \0627\0644\0633\0646\0648\064A\0647')
,p_translate_from_text=>'Annual Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24762119077688748)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38419098168856963.123456)
,p_translate_from_id=>wwv_flow_imp.id(38419098168856963)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\062A\0642\0631\064A\0631 \0627\0644\0645\0627\0644\064A \0627\0644\0633\0646\0648\064A ')
,p_translate_from_text=>'annual financial report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24762312467688748)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503281540891532.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503281540891532)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0627\0644\0627\0643\062B\0631 \0645\0628\064A\0639\0627')
,p_translate_from_text=>'best-selling medicne'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24762501799688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001600445605316.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001600445605316)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0648\0631\062F\064A\0646')
,p_translate_from_text=>'Providers Medicine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24762704194688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13400859564780715.123456)
,p_translate_from_id=>wwv_flow_imp.id(13400859564780715)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24762991790688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002405941605324.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002405941605324)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A \0641\064A \0627\0644\064A\0648\0645 ')
,p_translate_from_text=>'Income In Day '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24763163576688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003352580605333.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003352580605333)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A \0641\064A \0627\0644\0634\0647\0631')
,p_translate_from_text=>'Income In Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24763359563688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501891578891518.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501891578891518)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0642\0631\064A\0628\0627')
,p_translate_from_text=>'comming soon'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24763580357688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501107014891511.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501107014891511)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A & \0627\0644\0648\0627\0631\062F\0627\062A ')
,p_translate_from_text=>'Income & Expenses '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24763727601688750)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19000181312605301.123456)
,p_translate_from_id=>wwv_flow_imp.id(19000181312605301)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0646\0634\0637\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Activity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24763927613688751)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19004978400605349.123456)
,p_translate_from_id=>wwv_flow_imp.id(19004978400605349)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0645\0635\0631\0648\0641\0627\062A \0641\064A \0627\0644\0634\0647\0631')
,p_translate_from_text=>'Expenses In Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24764189748688751)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101152856048607.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101152856048607)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A \0641\064A \0627\0644\064A\0648\0645')
,p_translate_from_text=>'Expenses In Day'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24764368949688751)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15801891003615989.123456)
,p_translate_from_id=>wwv_flow_imp.id(15801891003615989)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>'Breadcrumb'
,p_translate_from_text=>'Breadcrumb'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24764590768688753)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15802400011616060.123456)
,p_translate_from_id=>wwv_flow_imp.id(15802400011616060)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0634\0643\0648\064A')
,p_translate_from_text=>'Add Complain'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24764797449688753)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24764928448688753)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16002178969668968.123456)
,p_translate_from_id=>wwv_flow_imp.id(16002178969668968)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0627\0638\0647\0627\0631 \0627\0644\0634\0643\0627\0648\064A')
,p_translate_from_text=>'show complains'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24765128614688754)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904278716923381.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904278716923381)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0635\064A\062F\0644\064A\0647 ')
,p_translate_from_text=>'Pharmacy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24765308461688754)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6909825038923558.123456)
,p_translate_from_id=>wwv_flow_imp.id(6909825038923558)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\062D\0648\0644')
,p_translate_from_text=>'About Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24765584784688756)
,p_page_id=>10011
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6910460694923566.123456)
,p_translate_from_id=>wwv_flow_imp.id(6910460694923566)
,p_translate_column_id=>20
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'Y'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search Dialog'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24765790649688770)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select substr((select "medcine_name" from "ph_medcine" m where m."medcine_id" = e."medcine_id"),1,30)',
'as "name"  , "expired_date"  as "date" from "ph_expired_medcine" e ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select substr((select "medcine_name" from "ph_medcine" m where m."medcine_id" = e."medcine_id"),1,30)',
'as "name"  , "expired_date"  as "date" from "ph_expired_medcine" e ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24765940391688770)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401248112263300.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401248112263300)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       "medcine_id",   ',
'      substr("medcine_name",1,20) as medcine_name, --substr(your_string, 1, 32760) to get limit number of character ',
'       "unit_id",',
'       "QUANTITY",',
'       "sell_price",',
'       "expired_date",',
'       NOTES,',
'       case when "QUANTITY" < :MINQUANTITI  then ''red''',
'       else ''green'' ',
'       end as color,',
'       case',
'            when months_between("expired_date" , sysdate) < 0 then ''red''',
'            when months_between("expired_date" , sysdate) < :lastmindate  then ''red''',
'            when months_between("expired_date" , sysdate) < :MINDATE   then ''orange''',
'        else ''green'' ',
'        end as color2 ',
'  from "ph_medcine"',
'  where',
'  upper(''%''||"medcine_name"||''%'') like upper (''%''||:P3_SEARCH||''%'') ',
'  or',
'  "barcode_id" = :P3_SEARCH ; ',
'  ',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       "medcine_id",   ',
'      substr("medcine_name",1,20) as medcine_name, --substr(your_string, 1, 32760) to get limit number of character ',
'       "unit_id",',
'       "QUANTITY",',
'       "sell_price",',
'       "expired_date",',
'       NOTES,',
'       case when "QUANTITY" < :MINQUANTITI  then ''red''',
'       else ''green'' ',
'       end as color,',
'       case',
'            when months_between("expired_date" , sysdate) < 0 then ''red''',
'            when months_between("expired_date" , sysdate) < :lastmindate  then ''red''',
'            when months_between("expired_date" , sysdate) < :MINDATE   then ''orange''',
'        else ''green'' ',
'        end as color2 ',
'  from "ph_medcine"',
'  where',
'  upper(''%''||"medcine_name"||''%'') like upper (''%''||:P3_SEARCH||''%'') ',
'  or',
'  "barcode_id" = :P3_SEARCH ; ',
'  ',
''))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24766193446688770)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401122031263298.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401122031263298)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'      ',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'  where ',
'    "order_id" = :P3_ORDER_ID'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'      ',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'  where ',
'    "order_id" = :P3_ORDER_ID'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24766390621688770)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24706937930626599.123456)
,p_translate_from_id=>wwv_flow_imp.id(24706937930626599)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       "medcine_id",   ',
'      substr("medcine_name",1,20) as medcine_name, --substr(your_string, 1, 32760) to get limit number of character ',
'       "QUANTITY",',
'       "expired_date",',
'       "buy_price",',
'       "barcode_id"',
'       from "ph_medcine"',
'  where',
'  upper(''%''||"medcine_name"||''%'') like upper (''%''||:P4_SEARCH||''%'') ',
'  or',
'  "barcode_id" = :P4_SEARCH ; ',
'  ',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       "medcine_id",   ',
'      substr("medcine_name",1,20) as medcine_name, --substr(your_string, 1, 32760) to get limit number of character ',
'       "QUANTITY",',
'       "expired_date",',
'       "buy_price",',
'       "barcode_id"',
'       from "ph_medcine"',
'  where',
'  upper(''%''||"medcine_name"||''%'') like upper (''%''||:P4_SEARCH||''%'') ',
'  or',
'  "barcode_id" = :P4_SEARCH ; ',
'  ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24766500710688771)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710609528626635.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710609528626635)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "order_id",',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'  where "order_id" = :P4_ORDER_ID;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "order_id",',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'  where "order_id" = :P4_ORDER_ID;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24766728508688771)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7310739278037575.123456)
,p_translate_from_id=>wwv_flow_imp.id(7310739278037575)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where upper(NAME) like upper (''%''||:P5_SEARCH||''%'')  ',
'  or ',
'        upper(USERNAME) like upper(''%''||:P5_SEARCH ||''%'')'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where upper(NAME) like upper (''%''||:P5_SEARCH||''%'')  ',
'  or ',
'        upper(USERNAME) like upper(''%''||:P5_SEARCH ||''%'')'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24766993119688771)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30611711086648126.123456)
,p_translate_from_id=>wwv_flow_imp.id(30611711086648126)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where upper(USERNAME) = :APP_USER'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       active,',
'       ROLE,',
'       USERNAME',
'  from "ph_users"',
'  where upper(USERNAME) = :APP_USER'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24767110359688771)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7300827667037460.123456)
,p_translate_from_id=>wwv_flow_imp.id(7300827667037460)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       ROLE,',
'       active,',
'       USERNAME,',
'       password',
'  from "ph_users"'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select USER_ID,',
'       NAME,',
'       PHONE,',
'       EMAIL,',
'       ROLE,',
'       active,',
'       USERNAME,',
'       password',
'  from "ph_users"'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24767337139688771)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12405071674263338.123456)
,p_translate_from_id=>wwv_flow_imp.id(12405071674263338)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'cursor cur is select  m."medcine_name" , m."sell_price",o."buy_price", o."quantitiy" ',
'from "ph_medcine" m , "ph_orders_medcine" o ',
'where o."order_id" = :P7_ORDER_ID  and o."medcine_id" = m."medcine_id";',
'total number(20) :=0 ;  --total for partical item',
'sumt number(20) :=0 ;    --total for all items',
'actualPrice number(20) := 0 ; -- this is a real price choose between sell price or buy price depend on the condtion',
'begin',
'---------------------------for type of the invoice ------------------------------',
'    if :P7_INVOICE_TYPE = ''s'' then ',
'       :P7_INVOICE_TYPE := ''sell invoice'' ;',
'    elsif :P7_INVOICE_TYPE = ''r'' then ',
'          :P7_INVOICE_TYPE := ''returned invoice'';',
'    else',
'          :P7_INVOICE_TYPE := ''buy invoice'';',
'    end if;',
'----------------------------end type of the invoice -------------------------------',
'htp.p(',
'    ''',
'    ',
'        <!DOCTYPE html>',
'<html lang="en">',
'<head>',
'    <meta charset="UTF-8">',
'    <link rel="stylesheet" href="#APP_FILES#invoice.css">',
'    <title>invoice</title>',
'</head>',
'<body>',
'        <div class="container">',
'            <div class="design">',
'            <div class="desHead">',
'                <div class="intro">',
'                    <h1>Medical Invoice</h1>',
'                    <br>',
'                    <br>',
'                    <br>',
'                </div> ',
'                <div class="desBody">',
'                    <table>',
'                        <tr>',
'                            <td>invoice type</td>',
'                            <td>''||:P7_INVOICE_TYPE||''</td>',
'                        </tr>',
'                          <tr>',
'                            <td>order_number</td>',
'                            <td>''||:P7_ORDER_ID||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>date </td>',
'                            <td>''||:P7_DATE||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>user name</td>',
'                            <td>''||:P7_USER_NAME||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>client Name</td>',
'                            <td>''||:P7_CLIENT_NAME||''</td>',
'                        </tr>',
'                       ',
'                    </table>',
'                </div>',
'            </div>',
'            <div class="destable">',
'            <table>',
'                    <thead>',
'                        <tr>',
'                            <th>Medicine</th>',
'                            <th>Quantitiy</th>',
'                            <th>Price</th>',
'                            <th>Total</th>',
'                        </tr>',
'                    </thead>'');',
'',
'for s in cur ',
'loop',
'      ------------------------to choose the sell price or buy price in sell invoice and buy invoice ------------',
'    if :P7_INVOICE_TYPE = ''sell invoice'' or :P7_INVOICE_TYPE = ''returned invoice'' then',
'        actualPrice := s."sell_price";',
'    else ',
'        actualPrice := s."buy_price";',
'    end if ; ',
'-------------------------------------------end choosing -------------------------',
'total := s."quantitiy" * actualPrice;  -- sum items',
'sumt := sumt + total ;  --sum for all items ',
':P7_TOTAL := sumt;',
'htp.p(''',
'                    <tbody>',
'                        <tr>',
'                            <td>''||s."medcine_name"||''</td>',
'                            <td>''||s."quantitiy"||''</td>',
'                            <td>''||actualPrice||'' $</td>',
'                            <td>''||total||'' $</td>',
'                        </tr>',
'                       ',
'                       ',
'                    </tbody>'');',
'end loop;',
'htp.p(''',
'                    <tfoot>',
'                        <tr>',
'                            <td colspan="3">total</td>',
'                            ',
'                            <td>''||sumt||'' $</td>',
'                        </tr> ',
'                    </tfoot>',
'                </table>',
'            </div>    ',
'        </div>',
'        </div>',
'</body>',
'</html>',
'',
'    ''',
');',
'',
'---------------------------to cancel type of the invoice ------------------------------',
'    if :P7_INVOICE_TYPE = ''sell invoice'' then ',
'       :P7_INVOICE_TYPE := ''s'' ;',
'    elsif :P7_INVOICE_TYPE = ''returned invoice'' then ',
'          :P7_INVOICE_TYPE := ''r'';',
'    else',
'          :P7_INVOICE_TYPE := ''b'';',
'    end if;',
'----------------------------end canceltion type of the invoice -------------------------------',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'cursor cur is select  m."medcine_name" , m."sell_price",o."buy_price", o."quantitiy" ',
'from "ph_medcine" m , "ph_orders_medcine" o ',
'where o."order_id" = :P7_ORDER_ID  and o."medcine_id" = m."medcine_id";',
'total number(20) :=0 ;  --total for partical item',
'sumt number(20) :=0 ;    --total for all items',
'actualPrice number(20) := 0 ; -- this is a real price choose between sell price or buy price depend on the condtion',
'begin',
'---------------------------for type of the invoice ------------------------------',
'    if :P7_INVOICE_TYPE = ''s'' then ',
'       :P7_INVOICE_TYPE := ''sell invoice'' ;',
'    elsif :P7_INVOICE_TYPE = ''r'' then ',
'          :P7_INVOICE_TYPE := ''returned invoice'';',
'    else',
'          :P7_INVOICE_TYPE := ''buy invoice'';',
'    end if;',
'----------------------------end type of the invoice -------------------------------',
'htp.p(',
'    ''',
'    ',
'        <!DOCTYPE html>',
'<html lang="en">',
'<head>',
'    <meta charset="UTF-8">',
'    <link rel="stylesheet" href="#APP_FILES#invoice.css">',
'    <title>invoice</title>',
'</head>',
'<body>',
'        <div class="container">',
'            <div class="design">',
'            <div class="desHead">',
'                <div class="intro">',
'                    <h1>Medical Invoice</h1>',
'                    <br>',
'                    <br>',
'                    <br>',
'                </div> ',
'                <div class="desBody">',
'                    <table>',
'                        <tr>',
'                            <td>invoice type</td>',
'                            <td>''||:P7_INVOICE_TYPE||''</td>',
'                        </tr>',
'                          <tr>',
'                            <td>order_number</td>',
'                            <td>''||:P7_ORDER_ID||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>date </td>',
'                            <td>''||:P7_DATE||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>user name</td>',
'                            <td>''||:P7_USER_NAME||''</td>',
'                        </tr>',
'                        <tr>',
'                            <td>client Name</td>',
'                            <td>''||:P7_CLIENT_NAME||''</td>',
'                        </tr>',
'                       ',
'                    </table>',
'                </div>',
'            </div>',
'            <div class="destable">',
'            <table>',
'                    <thead>',
'                        <tr>',
'                            <th>Medicine</th>',
'                            <th>Quantitiy</th>',
'                            <th>Price</th>',
'                            <th>Total</th>',
'                        </tr>',
'                    </thead>'');',
'',
'for s in cur ',
'loop',
'      ------------------------to choose the sell price or buy price in sell invoice and buy invoice ------------',
'    if :P7_INVOICE_TYPE = ''sell invoice'' or :P7_INVOICE_TYPE = ''returned invoice'' then',
'        actualPrice := s."sell_price";',
'    else ',
'        actualPrice := s."buy_price";',
'    end if ; ',
'-------------------------------------------end choosing -------------------------',
'total := s."quantitiy" * actualPrice;  -- sum items',
'sumt := sumt + total ;  --sum for all items ',
':P7_TOTAL := sumt;',
'htp.p(''',
'                    <tbody>',
'                        <tr>',
'                            <td>''||s."medcine_name"||''</td>',
'                            <td>''||s."quantitiy"||''</td>',
'                            <td>''||actualPrice||'' $</td>',
'                            <td>''||total||'' $</td>',
'                        </tr>',
'                       ',
'                       ',
'                    </tbody>'');',
'end loop;',
'htp.p(''',
'                    <tfoot>',
'                        <tr>',
'                            <td colspan="3">total</td>',
'                            ',
'                            <td>''||sumt||'' $</td>',
'                        </tr> ',
'                    </tfoot>',
'                </table>',
'            </div>    ',
'        </div>',
'        </div>',
'</body>',
'</html>',
'',
'    ''',
');',
'',
'---------------------------to cancel type of the invoice ------------------------------',
'    if :P7_INVOICE_TYPE = ''sell invoice'' then ',
'       :P7_INVOICE_TYPE := ''s'' ;',
'    elsif :P7_INVOICE_TYPE = ''returned invoice'' then ',
'          :P7_INVOICE_TYPE := ''r'';',
'    else',
'          :P7_INVOICE_TYPE := ''b'';',
'    end if;',
'----------------------------end canceltion type of the invoice -------------------------------',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24767533298688798)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202130068481911.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202130068481911)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h1 style="text-align:center">\0644\0627 \062A\0648\062C\062F \0641\0627\062A\0648\0631\0647 '),
'</h1>'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 style="text-align:center">no invoice to display',
'</h1>'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24767765780688812)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10307347086912550.123456)
,p_translate_from_id=>wwv_flow_imp.id(10307347086912550)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "unit_id",',
'       "unit_name"',
'  from "ph_unit"',
'  where upper("unit_name") like upper(''%''||:P8_SEARCH ||''%'');'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "unit_id",',
'       "unit_name"',
'  from "ph_unit"',
'  where upper("unit_name") like upper(''%''||:P8_SEARCH ||''%'');'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24767925369688812)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17707792188395409.123456)
,p_translate_from_id=>wwv_flow_imp.id(17707792188395409)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "provider_id",',
'       "provider_name",',
'       "phone",',
'       "Email",',
'       "balance",',
'       TYPE',
'  from "ph_providers"',
'',
'  where upper("provider_name") like upper(''%'' || :P10_SEARCH ||''%'')'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "provider_id",',
'       "provider_name",',
'       "phone",',
'       "Email",',
'       "balance",',
'       TYPE',
'  from "ph_providers"',
'',
'  where upper("provider_name") like upper(''%'' || :P10_SEARCH ||''%'')'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24768194722688812)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611128425472722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611128425472722)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "medcine_id",',
'       "barcode_id",',
'       "medcine_name",',
'       "unit_id",',
'       "QUANTITY",',
'       "buy_price",',
'       "sell_price",',
'       "expired_date",',
'       provider_id,',
'       NOTES,',
'       case ',
'        when  "QUANTITY" < :MINQUANTITI  then ''red''',
'        else ''green''',
'        end as color,',
'       case ',
'       when  months_between("expired_date" , sysdate) < 0 then ''red''',
'       when  months_between("expired_date" , sysdate) < :lastmindate then ''red''',
'       when  months_between("expired_date" , sysdate) < :MINDATE  then ''orange''',
'       else ''green''',
'       end as color2 ',
'  ',
'  from "ph_medcine"',
'  where ',
'  upper("medcine_name") like upper(''%''||:P12_SEARCH||''%'')',
'  or',
'  upper("barcode_id") like upper(''%''||:P12_SEARCH||''%'')',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "medcine_id",',
'       "barcode_id",',
'       "medcine_name",',
'       "unit_id",',
'       "QUANTITY",',
'       "buy_price",',
'       "sell_price",',
'       "expired_date",',
'       provider_id,',
'       NOTES,',
'       case ',
'        when  "QUANTITY" < :MINQUANTITI  then ''red''',
'        else ''green''',
'        end as color,',
'       case ',
'       when  months_between("expired_date" , sysdate) < 0 then ''red''',
'       when  months_between("expired_date" , sysdate) < :lastmindate then ''red''',
'       when  months_between("expired_date" , sysdate) < :MINDATE  then ''orange''',
'       else ''green''',
'       end as color2 ',
'  ',
'  from "ph_medcine"',
'  where ',
'  upper("medcine_name") like upper(''%''||:P12_SEARCH||''%'')',
'  or',
'  upper("barcode_id") like upper(''%''||:P12_SEARCH||''%'')',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24768323306688814)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503086156569010.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503086156569010)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "medcine_id",',
'       "barcode_id",',
'       "medcine_name",',
'       "unit_id",',
'       "buy_price",',
'       "sell_price",',
'       "expired_date",',
'       NOTES,',
'       QUANTITY,',
'        months_between( "expired_date" ,:P14_NEW   ) as y,',
'        case ',
'          when  "QUANTITY" < :MINQUANTITI  then ''red'' ',
'            else  ''green'' ',
'          end as color,',
'          case',
'              when months_between("expired_date" , :P14_NEW ) < 0 then ''red'' ',
'              when months_between("expired_date" , :P14_NEW ) < :lastmindate then  ''red''',
'              when months_between("expired_date", :P14_NEW  )  < :MINDATE  then  ''orange''',
'          else    ''green''',
'            end as color2',
'  from "ph_medcine"',
'',
'        '))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "medcine_id",',
'       "barcode_id",',
'       "medcine_name",',
'       "unit_id",',
'       "buy_price",',
'       "sell_price",',
'       "expired_date",',
'       NOTES,',
'       QUANTITY,',
'        months_between( "expired_date" ,:P14_NEW   ) as y,',
'        case ',
'          when  "QUANTITY" < :MINQUANTITI  then ''red'' ',
'            else  ''green'' ',
'          end as color,',
'          case',
'              when months_between("expired_date" , :P14_NEW ) < 0 then ''red'' ',
'              when months_between("expired_date" , :P14_NEW ) < :lastmindate then  ''red''',
'              when months_between("expired_date", :P14_NEW  )  < :MINDATE  then  ''orange''',
'          else    ''green''',
'            end as color2',
'  from "ph_medcine"',
'',
'        '))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24768557909688814)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305964111993608.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305964111993608)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_id",',
'       "invoice_date",',
'       "user_id",',
'       "order_id",',
'       "type",',
'       "provider_id",',
'       "total_price",',
'       "client_name"',
'      ',
'',
'  from "ph_invoice" ',
'  where "invoice_date" like (''%''||:P16_DATE||''%'')',
'    and   ',
'        "order_id" like (''%''||:P16_ORDER_ID ||''%'')',
'    and  ',
'        "type"  like  (''%''||:P16_TYPE||''%'') ; ',
' ',
'    '))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_id",',
'       "invoice_date",',
'       "user_id",',
'       "order_id",',
'       "type",',
'       "provider_id",',
'       "total_price",',
'       "client_name"',
'      ',
'',
'  from "ph_invoice" ',
'  where "invoice_date" like (''%''||:P16_DATE||''%'')',
'    and   ',
'        "order_id" like (''%''||:P16_ORDER_ID ||''%'')',
'    and  ',
'        "type"  like  (''%''||:P16_TYPE||''%'') ; ',
' ',
'    '))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24768707334688814)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308013194993628.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308013194993628)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOT_ID,',
'       substr(MEDCINE_NAME,1,20) as Medcine_name,',
'       BARCODE,',
'       MEDCINE_ID,',
'       STATUS,',
'       INFORMATION',
'  from PH_NOTIFICATION'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOT_ID,',
'       substr(MEDCINE_NAME,1,20) as Medcine_name,',
'       BARCODE,',
'       MEDCINE_ID,',
'       STATUS,',
'       INFORMATION',
'  from PH_NOTIFICATION'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24768992031688814)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105569997172537.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105569997172537)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select  extract(year from "return_date")||''-''||extract(month from "return_date")||''-''||extract(day from "return_date") as "return date",',
'--  sum("money") as money from "ph_return_medcine"',
'--  where ',
'--     (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'--     and ',
'--     (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
'--   group by extract(DAY from "return_date"),extract(month from "return_date"),extract(year from "return_date") order by extract(day from"return_date") desc ;',
'',
'',
'-- select to_char("return_date",''YYYY-MM-DD'') as "return date" ,',
'--     sum("money") as "money" from "ph_return_medcine"',
'--  where ',
'--     (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'--     and ',
'--     (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
'--   group by to_char("return_date",''YYYY-MM-DD'') desc ;',
'',
'select to_char("return_date",''YYYY-MM-DD'') as "return date" , sum("money") as money ',
'from  "ph_return_medcine"',
'   where ',
'    (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'    and ',
'    (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
' group by to_char("return_date",''YYYY-MM-DD'') ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select  extract(year from "return_date")||''-''||extract(month from "return_date")||''-''||extract(day from "return_date") as "return date",',
'--  sum("money") as money from "ph_return_medcine"',
'--  where ',
'--     (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'--     and ',
'--     (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
'--   group by extract(DAY from "return_date"),extract(month from "return_date"),extract(year from "return_date") order by extract(day from"return_date") desc ;',
'',
'',
'-- select to_char("return_date",''YYYY-MM-DD'') as "return date" ,',
'--     sum("money") as "money" from "ph_return_medcine"',
'--  where ',
'--     (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'--     and ',
'--     (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
'--   group by to_char("return_date",''YYYY-MM-DD'') desc ;',
'',
'select to_char("return_date",''YYYY-MM-DD'') as "return date" , sum("money") as money ',
'from  "ph_return_medcine"',
'   where ',
'    (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'    and ',
'    (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null)',
' group by to_char("return_date",''YYYY-MM-DD'') ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24769189363688814)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802265181841591.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802265181841591)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "income_id",',
'       "money",',
'       "income_date"',
'  from "ph_income"  ',
'  where  ',
'     -------------- first case if  you want to filter the content with month-----------',
'         :P20_YEAR = 0  and (  extract(month from "income_date") = :P20_MONTH )',
'         or',
'     --------------- second case if you want to filter the content with year-------------------',
'         :P20_MONTH = 0 and (extract(year from "income_date") = :P20_YEAR)',
'         or ',
'     ----------------third case if you want to filter the content with year and month ',
'         extract(month from "income_date") = :P20_MONTH ',
'         and  ',
'         extract(year from "income_date") = :P20_YEAR',
'         or ',
'           :P20_MONTH=0 and :P20_YEAR =0 ;',
'      ',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "income_id",',
'       "money",',
'       "income_date"',
'  from "ph_income"  ',
'  where  ',
'     -------------- first case if  you want to filter the content with month-----------',
'         :P20_YEAR = 0  and (  extract(month from "income_date") = :P20_MONTH )',
'         or',
'     --------------- second case if you want to filter the content with year-------------------',
'         :P20_MONTH = 0 and (extract(year from "income_date") = :P20_YEAR)',
'         or ',
'     ----------------third case if you want to filter the content with year and month ',
'         extract(month from "income_date") = :P20_MONTH ',
'         and  ',
'         extract(year from "income_date") = :P20_YEAR',
'         or ',
'           :P20_MONTH=0 and :P20_YEAR =0 ;',
'      ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24769300224688814)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604958034020036.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604958034020036)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "expenses_id",',
'       "money",',
'       EXPENSES_DATE',
'  from "ph_expenses"',
'  where ',
'        :P21_MONTH = 0 and   extract (year from expenses_date) = :P21_YEAR ',
'        or',
'        :P21_YEAR = 0 and extract(month from expenses_date) =:P21_MONTH  ',
'        or',
'        extract(month from expenses_date) = :P21_MONTH   and extract(year from expenses_date) = :P21_YEAR  ',
'        or',
'        :P21_MONTH = 0 and :P21_YEAR = 0 ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "expenses_id",',
'       "money",',
'       EXPENSES_DATE',
'  from "ph_expenses"',
'  where ',
'        :P21_MONTH = 0 and   extract (year from expenses_date) = :P21_YEAR ',
'        or',
'        :P21_YEAR = 0 and extract(month from expenses_date) =:P21_MONTH  ',
'        or',
'        extract(month from expenses_date) = :P21_MONTH   and extract(year from expenses_date) = :P21_YEAR  ',
'        or',
'        :P21_MONTH = 0 and :P21_YEAR = 0 ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24769544311688815)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24216823871695185.123456)
,p_translate_from_id=>wwv_flow_imp.id(24216823871695185)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum as rowNumber,',
'       "shortcoming_id",',
'       "medcine_id",',
'       "quantity"',
'  from "ph_shortcomings"'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum as rowNumber,',
'       "shortcoming_id",',
'       "medcine_id",',
'       "quantity"',
'  from "ph_shortcomings"'))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24769748572688815)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713520427244116.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713520427244116)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_id",',
'       "invoice_date",',
'       "order_id",',
'       "total_price",',
'       "client_name"',
'  from "ph_invoice"',
'  where ',
'    "type" = ''s'' ',
'    and ',
'    ((upper("client_name") like upper(''%''||:P23_CLIENT_NAME ||''%'') and "order_id" = :P23_ORDER_NO) ',
'    OR   ',
'    (:P23_CLIENT_NAME is null and "order_id" = :P23_ORDER_NO)',
'    or   ',
'    (upper("client_name") like upper(''%''||:P23_CLIENT_NAME ||''%'') and :P23_ORDER_NO is null )',
'    or    ',
'    :P23_ORDER_NO is null and :P23_CLIENT_NAME is null ) and months_between(sysdate, "invoice_date") < :RETURNED_DURATION',
'    ',
'    ',
'    ',
'    ',
'    ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_id",',
'       "invoice_date",',
'       "order_id",',
'       "total_price",',
'       "client_name"',
'  from "ph_invoice"',
'  where ',
'    "type" = ''s'' ',
'    and ',
'    ((upper("client_name") like upper(''%''||:P23_CLIENT_NAME ||''%'') and "order_id" = :P23_ORDER_NO) ',
'    OR   ',
'    (:P23_CLIENT_NAME is null and "order_id" = :P23_ORDER_NO)',
'    or   ',
'    (upper("client_name") like upper(''%''||:P23_CLIENT_NAME ||''%'') and :P23_ORDER_NO is null )',
'    or    ',
'    :P23_ORDER_NO is null and :P23_CLIENT_NAME is null ) and months_between(sysdate, "invoice_date") < :RETURNED_DURATION',
'    ',
'    ',
'    ',
'    ',
'    ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24769995936688815)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712960119291136.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712960119291136)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'',
'  where "order_id" = :P23_ORDER_ID;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'',
'  where "order_id" = :P23_ORDER_ID;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24770171719688815)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710661087291113.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710661087291113)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v."invoice_id",',
'       v."invoice_date",',
'       v."order_id",',
'       v."total_price",',
'       v."client_name"',
'  from "ph_invoice" v join "ph_orders_medcine" o',
'on v."order_id" = o."order_id"',
'where ',
'v."type" =''s''  and months_between(sysdate , v."invoice_date") < :RETURNED_DURATION and',
'',
'   ( (o."medcine_id" = (select  "medcine_id" from "ph_medcine" where "barcode_id" = :P23_MEDCINE_SEARCH fetch first 1 row only ) or :P23_MEDCINE_SEARCH is null) ',
'      or  ',
'      (o."medcine_id" = (select "medcine_id" from "ph_medcine" where "medcine_name" like ''%''||:P23_MEDCINE_SEARCH ||''%'' order by length("medcine_name") fetch first 1 row only ) or :P23_MEDCINE_SEARCH is null)',
'   )'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v."invoice_id",',
'       v."invoice_date",',
'       v."order_id",',
'       v."total_price",',
'       v."client_name"',
'  from "ph_invoice" v join "ph_orders_medcine" o',
'on v."order_id" = o."order_id"',
'where ',
'v."type" =''s''  and months_between(sysdate , v."invoice_date") < :RETURNED_DURATION and',
'',
'   ( (o."medcine_id" = (select  "medcine_id" from "ph_medcine" where "barcode_id" = :P23_MEDCINE_SEARCH fetch first 1 row only ) or :P23_MEDCINE_SEARCH is null) ',
'      or  ',
'      (o."medcine_id" = (select "medcine_id" from "ph_medcine" where "medcine_name" like ''%''||:P23_MEDCINE_SEARCH ||''%'' order by length("medcine_name") fetch first 1 row only ) or :P23_MEDCINE_SEARCH is null)',
'   )'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24770347690688815)
,p_page_id=>24
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709911767291105.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709911767291105)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_date",',
'       "user_id",',
'       "order_id",',
'       "type",',
'       "provider_id",',
'       "total_price"',
'  from "ph_invoice"',
'  where months_between("invoice_date" , sysdate) < 1 ; '))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "invoice_date",',
'       "user_id",',
'       "order_id",',
'       "type",',
'       "provider_id",',
'       "total_price"',
'  from "ph_invoice"',
'  where months_between("invoice_date" , sysdate) < 1 ; '))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24770542957688815)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715377867244235.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715377867244235)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "order_id",',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'    where "order_id" = :P25_ORDER_ID ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "order_id",',
'       "medcine_id",',
'       "quantitiy"',
'  from "ph_orders_medcine"',
'    where "order_id" = :P25_ORDER_ID ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24770771244688815)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24220807042728477.123456)
,p_translate_from_id=>wwv_flow_imp.id(24220807042728477)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ROWNUM as rownumber,',
'       "expMedcine_id",',
'       "medcine_id",',
'       "expired_date"',
'  from "ph_expired_medcine"'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ROWNUM as rownumber,',
'       "expMedcine_id",',
'       "medcine_id",',
'       "expired_date"',
'  from "ph_expired_medcine"'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24770945181688817)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306492416261630.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306492416261630)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select extract(year from"income_date") as dat ,sum("money") as money, ''sell'' as type from "ph_income"  ',
'where extract(year from "income_date") = :P29_YEAR',
'group by extract(year from "income_date")  ',
'',
'union all ',
'',
'select  extract(year from "EXPENSES_DATE") as dat , sum("money") * -1 as money , ''buy'' as type from "ph_expenses" ',
'where extract(year from "EXPENSES_DATE") = :P29_YEAR',
'group by extract(year from "EXPENSES_DATE") ',
'',
'-- union all ',
'',
'-- select extract (year from "return_date") as dat , sum("money") * -1  as money , ''return'' as type from "ph_return_medcine"',
'-- where  extract(year from "return_date") =  :P29_YEAR ',
'-- group by extract(year from "return_date")'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select extract(year from"income_date") as dat ,sum("money") as money, ''sell'' as type from "ph_income"  ',
'where extract(year from "income_date") = :P29_YEAR',
'group by extract(year from "income_date")  ',
'',
'union all ',
'',
'select  extract(year from "EXPENSES_DATE") as dat , sum("money") * -1 as money , ''buy'' as type from "ph_expenses" ',
'where extract(year from "EXPENSES_DATE") = :P29_YEAR',
'group by extract(year from "EXPENSES_DATE") ',
'',
'-- union all ',
'',
'-- select extract (year from "return_date") as dat , sum("money") * -1  as money , ''return'' as type from "ph_return_medcine"',
'-- where  extract(year from "return_date") =  :P29_YEAR ',
'-- group by extract(year from "return_date")'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24771167959688817)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501891578891518.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501891578891518)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<h1 style="text-align:center;text-transform:capitalize;">comming soon ......! </h1>'
,p_translate_from_text=>'<h1 style="text-align:center;text-transform:capitalize;">comming soon ......! </h1>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24771341118688817)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6909825038923558.123456)
,p_translate_from_id=>wwv_flow_imp.id(6909825038923558)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0647\0644\0627 \0627\0646\0627 \0648\0633\064A\0645')
,p_translate_from_text=>'Text about this application can be placed here.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24771580658688817)
,p_page_id=>10011
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6910460694923566.123456)
,p_translate_from_id=>wwv_flow_imp.id(6910460694923566)
,p_translate_column_id=>21
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ',
'(',
'    select page_title, help_text ',
'      from apex_application_pages',
'     where page_id = :P10011_PAGE_ID ',
'       and application_id = :APP_ID',
')',
'loop',
'    if c1.help_text is null then',
'        sys.htp.p(''No help is available for this page.'');',
'    else',
'        if substr(c1.help_text, 1, 3) != ''<p>'' then',
'            sys.htp.p(''<p>'');',
'        end if;',
'',
'        sys.htp.p(apex_application.do_substitutions(c1.help_text));',
'',
'        if substr(trim(c1.help_text), -4) != ''</p>'' then',
'            sys.htp.p(''</p>'');',
'        end if;',
'    end if;',
'end loop;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ',
'(',
'    select page_title, help_text ',
'      from apex_application_pages',
'     where page_id = :P10011_PAGE_ID ',
'       and application_id = :APP_ID',
')',
'loop',
'    if c1.help_text is null then',
'        sys.htp.p(''No help is available for this page.'');',
'    else',
'        if substr(c1.help_text, 1, 3) != ''<p>'' then',
'            sys.htp.p(''<p>'');',
'        end if;',
'',
'        sys.htp.p(apex_application.do_substitutions(c1.help_text));',
'',
'        if substr(trim(c1.help_text), -4) != ''</p>'' then',
'            sys.htp.p(''</p>'');',
'        end if;',
'    end if;',
'end loop;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24771728820688859)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10600903489239797.123456)
,p_translate_from_id=>wwv_flow_imp.id(10600903489239797)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0648\0631\062F\064A\0646')
,p_translate_from_text=>'Provider Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24771859601688859)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11610728480472713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11610728480472713)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medcine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24772036895688859)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12300753318881238.123456)
,p_translate_from_id=>wwv_flow_imp.id(12300753318881238)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0637\0644\0628\0627\062A')
,p_translate_from_text=>'orders'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24772294567688859)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12301188083922652.123456)
,p_translate_from_id=>wwv_flow_imp.id(12301188083922652)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0628\064A\0639')
,p_translate_from_text=>'Sell Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24772456130688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12302689855927483.123456)
,p_translate_from_id=>wwv_flow_imp.id(12302689855927483)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0634\0631\0627\0621')
,p_translate_from_text=>'Buy Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24772688276688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(29105938138879314.123456)
,p_translate_from_id=>wwv_flow_imp.id(29105938138879314)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Returned Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24772801849688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17203660142764299.123456)
,p_translate_from_id=>wwv_flow_imp.id(17203660142764299)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\0627\062F\0627\0631\0647 \0627\0644\062A\0637\0628\064A\0642'),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Manage Application',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24773029885688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17204116048777519.123456)
,p_translate_from_id=>wwv_flow_imp.id(17204116048777519)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\062F\0627\062F\0627\062A')
,p_translate_from_text=>'Setting'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24773277301688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20000772830551221.123456)
,p_translate_from_id=>wwv_flow_imp.id(20000772830551221)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0627\0631\0647 \0627\0644\0645\0627\0644\064A\0647')
,p_translate_from_text=>'financial management'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24773409261688860)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20100674483623333.123456)
,p_translate_from_id=>wwv_flow_imp.id(20100674483623333)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0641\0648\0627\062A\064A\0631')
,p_translate_from_text=>'Invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24773633211688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23801238724841466.123456)
,p_translate_from_id=>wwv_flow_imp.id(23801238724841466)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24773851389688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(27908726755113897.123456)
,p_translate_from_id=>wwv_flow_imp.id(27908726755113897)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A')
,p_translate_from_text=>'Outgoings'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24774063306688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38127358923230358.123456)
,p_translate_from_id=>wwv_flow_imp.id(38127358923230358)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'Returns'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24774206631688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38418634211856597.123456)
,p_translate_from_id=>wwv_flow_imp.id(38418634211856597)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062A\0642\0631\064A\0631 \0627\0644\0645\0627\0644\064A \0627\0644\0633\0646\0648\064A')
,p_translate_from_text=>'Annual Financial Report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24774450794688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16500753287555155.123456)
,p_translate_from_id=>wwv_flow_imp.id(16500753287555155)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062E\062A\0628\0627\0631')
,p_translate_from_text=>'test'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24774675719688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24215048947677600.123456)
,p_translate_from_id=>wwv_flow_imp.id(24215048947677600)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\062A\0628\0639 \062D\0627\0644\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'Medecine Condition tracker '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24774880371688862)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24215822565695041.123456)
,p_translate_from_id=>wwv_flow_imp.id(24215822565695041)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' [&MIN_QUANTITY_NUM.]  \0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine [&MIN_QUANTITY_NUM.]'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24775022135688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24219665321728436.123456)
,p_translate_from_id=>wwv_flow_imp.id(24219665321728436)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' [&EX_DATE_NUM.]\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0647 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expiredDate Medecine  [&EX_DATE_NUM.]'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24775223260688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6907899512923469.123456)
,p_translate_from_id=>wwv_flow_imp.id(6907899512923469)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0626\064A\0633\064A\0647')
,p_translate_from_text=>'Home'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24775403538688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7000915233895049.123456)
,p_translate_from_id=>wwv_flow_imp.id(7000915233895049)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647')
,p_translate_from_text=>'Add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24775623802688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7310362589037555.123456)
,p_translate_from_id=>wwv_flow_imp.id(7310362589037555)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'User Menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24775834652688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10306969364912530.123456)
,p_translate_from_id=>wwv_flow_imp.id(10306969364912530)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0648\062D\062F\0627\062A')
,p_translate_from_text=>'Unit menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24776064492688864)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15801454253615925.123456)
,p_translate_from_id=>wwv_flow_imp.id(15801454253615925)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0634\0643\0648\064A')
,p_translate_from_text=>'Add Complain'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24776247722688867)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16001183841668942.123456)
,p_translate_from_id=>wwv_flow_imp.id(16001183841668942)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr(' [&COMPLAIN_NUM.] \0627\0638\0647\0627\0631 \0627\0644\0634\0643\0627\0648\064A')
,p_translate_from_text=>'show complains [&COMPLAIN_NUM.]'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24776454892688867)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13400342468780657.123456)
,p_translate_from_id=>wwv_flow_imp.id(13400342468780657)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062D\0635\0627\0626\064A\0627\062A')
,p_translate_from_text=>'Statistics'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24776689894688867)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20608956163481456.123456)
,p_translate_from_id=>wwv_flow_imp.id(20608956163481456)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0634\0639\0627\0631\0627\062A')
,p_translate_from_text=>'Notification'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24776839706688867)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6911314144923571.123456)
,p_translate_from_id=>wwv_flow_imp.id(6911314144923571)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0648\0644')
,p_translate_from_text=>'About'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24777011424688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6911781072923575.123456)
,p_translate_from_id=>wwv_flow_imp.id(6911781072923575)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0633\0627\0639\062F\0647')
,p_translate_from_text=>'Page Help'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24777275370688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6912112052923577.123456)
,p_translate_from_id=>wwv_flow_imp.id(6912112052923577)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'---'
,p_translate_from_text=>'---'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24777426164688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6912467905923577.123456)
,p_translate_from_id=>wwv_flow_imp.id(6912467905923577)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0648\0644')
,p_translate_from_text=>'About Page'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24777697665688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6912739104923580.123456)
,p_translate_from_id=>wwv_flow_imp.id(6912739104923580)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&APP_USER.'
,p_translate_from_text=>'&APP_USER.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24777866073688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6913317292923583.123456)
,p_translate_from_id=>wwv_flow_imp.id(6913317292923583)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'---'
,p_translate_from_text=>'---'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24778000808688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6913685821923583.123456)
,p_translate_from_id=>wwv_flow_imp.id(6913685821923583)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0633\062C\064A\0644 \0627\0644\062E\0631\0648\062C')
,p_translate_from_text=>'Sign Out'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24778250375688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8800830893199257.123456)
,p_translate_from_id=>wwv_flow_imp.id(8800830893199257)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0628\064A\0639')
,p_translate_from_text=>'Sell Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24778407783688870)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8801294011199265.123456)
,p_translate_from_id=>wwv_flow_imp.id(8801294011199265)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcomming medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24778694903688871)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8801658984199265.123456)
,p_translate_from_id=>wwv_flow_imp.id(8801658984199265)
,p_translate_column_id=>28
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Expired Medcine'
,p_translate_from_text=>'Expired Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24778870243688907)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401248112263300.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401248112263300)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h1>\0647\0630\0627 \0627\0644\062F\0648\0627\0621 \063A\064A\0631 \0645\062A\0648\0641\0631  </h1>'),
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>no medicicne found </h1>',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24779033118688907)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401122031263298.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401122031263298)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h2>\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A '),
'</h2>'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>no data to display ',
'</h2>'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24779203989688907)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7310739278037575.123456)
,p_translate_from_id=>wwv_flow_imp.id(7310739278037575)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24779491220688909)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30611711086648126.123456)
,p_translate_from_id=>wwv_flow_imp.id(30611711086648126)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24779625777688909)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10307347086912550.123456)
,p_translate_from_id=>wwv_flow_imp.id(10307347086912550)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24779897447688909)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17707792188395409.123456)
,p_translate_from_id=>wwv_flow_imp.id(17707792188395409)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24780039591688909)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611128425472722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611128425472722)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24780214907688912)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305964111993608.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305964111993608)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('<h1> \0644\0627 \062A\0648\062C\062F \0641\0627\062A\0648\0631\0647  </h1>')
,p_translate_from_text=>'<h1> no invoice found </h1>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24780404612688914)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308013194993628.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308013194993628)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('<h1 style="text-align:center">\0644\0627 \062A\0648\062C\062F \0627\0634\0639\0627\0631\0627\062A </h1>')
,p_translate_from_text=>'<h1 style="text-align:center">no notification found </h1>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24780626064688915)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802265181841591.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802265181841591)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('<h2> \0644\0627 \062A\0648\062C\062F \0628\064A\0627\0646\0627\062A </h2>')
,p_translate_from_text=>'<h2> No Data found in Incoming </h2>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24780800773688917)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604958034020036.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604958034020036)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<h1 style="text-align:center">No data in Table</h1>'
,p_translate_from_text=>'<h1 style="text-align:center">No data in Table</h1>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781048094688917)
,p_page_id=>22
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24216823871695185.123456)
,p_translate_from_id=>wwv_flow_imp.id(24216823871695185)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781269353688918)
,p_page_id=>26
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24220807042728477.123456)
,p_translate_from_id=>wwv_flow_imp.id(24220807042728477)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781428458688918)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16002178969668968.123456)
,p_translate_from_id=>wwv_flow_imp.id(16002178969668968)
,p_translate_column_id=>36
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627 \064A\0648\062C\062F \0628\064A\0627\0646\0627\062A')
,p_translate_from_text=>'no data found'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781608894688945)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802265181841591.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802265181841591)
,p_translate_column_id=>42
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0627\0631\0628\0627\062D')
,p_translate_from_text=>'Total profits'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781770397688945)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604958034020036.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604958034020036)
,p_translate_column_id=>42
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062C\0645\0627\0644\064A ')
,p_translate_from_text=>'Total'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24781947819688945)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306492416261630.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306492416261630)
,p_translate_column_id=>42
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0635\0627\0641\064A \0627\0644\0627\0631\0628\0627\062D')
,p_translate_from_text=>'Net profit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24782166144689046)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>63
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search Dialog'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24782268095689059)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>66
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<div class="t-PopupLOV-actions t-Form--large">'
,p_translate_from_text=>'<div class="t-PopupLOV-actions t-Form--large">'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24782409548689065)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>67
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'</div>'
,p_translate_from_text=>'</div>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24782640503689078)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>70
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<div class="t-PopupLOV-links">'
,p_translate_from_text=>'<div class="t-PopupLOV-links">'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24782891964689084)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>71
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'</div>'
,p_translate_from_text=>'</div>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24783062006689089)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>72
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'Search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24783229849689093)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>73
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\0644\0642')
,p_translate_from_text=>'Close'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24783445508689096)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>74
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('&gt; \0627\0644\062A\0627\0644\064A ')
,p_translate_from_text=>'Next &gt;'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24783694009689101)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>75
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('&lt; \0627\0644\0633\0627\0628\0642')
,p_translate_from_text=>'&lt; Previous'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24783810202689114)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917144013930325.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917144013930325)
,p_translate_column_id=>78
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<i id="pass-status" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword()"></i>'
,p_translate_from_text=>'<i id="pass-status" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword()"></i>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784080801689114)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917304835930326.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917304835930326)
,p_translate_column_id=>78
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<i id="pass-status1" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword2()"></i>'
,p_translate_from_text=>'<i id="pass-status1" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword2()"></i>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784285971689114)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914514540930298.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914514540930298)
,p_translate_column_id=>78
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<i id="pass-status" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword()"></i>',
'',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<i id="pass-status" class="fa fa-eye field-icon" aria-hidden="true" onClick="viewPassword()"></i>',
'',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784463669689126)
,p_translated_flow_id=>123456
,p_translate_to_id=>100.123456
,p_translate_from_id=>100
,p_translate_column_id=>80
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HealthFlex Pharmacy'
,p_translate_from_text=>'HealthFlex Pharmacy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784551088689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6705592593922330.123456)
,p_translate_from_id=>wwv_flow_imp.id(6705592593922330)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0626\064A\0633\064A\0647')
,p_translate_from_text=>'Home'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784708913689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10310188067912580.123456)
,p_translate_from_id=>wwv_flow_imp.id(10310188067912580)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0648\062D\062F\0627\062A')
,p_translate_from_text=>'Unit menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24784929074689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11615845514472756.123456)
,p_translate_from_id=>wwv_flow_imp.id(11615845514472756)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0642\0627\0626\0645\0647 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'medcine menu'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24785104412689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12302104043922694.123456)
,p_translate_from_id=>wwv_flow_imp.id(12302104043922694)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0628\064A\0639')
,p_translate_from_text=>'Sell Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24785361289689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12303621159927500.123456)
,p_translate_from_id=>wwv_flow_imp.id(12303621159927500)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0634\0631\0627\0621')
,p_translate_from_text=>'Buy Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24785562509689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13401217542780721.123456)
,p_translate_from_id=>wwv_flow_imp.id(13401217542780721)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062D\0635\0627\0626\064A\0627\062A')
,p_translate_from_text=>'Statistics'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24785757760689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15802269574616012.123456)
,p_translate_from_id=>wwv_flow_imp.id(15802269574616012)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0636\0627\0641\0647 \0634\0643\0648\064A')
,p_translate_from_text=>'Add Complain'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24785902901689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16001951395668964.123456)
,p_translate_from_id=>wwv_flow_imp.id(16001951395668964)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0638\0647\0627\0631 \0627\0644\0634\0643\0627\0648\064A')
,p_translate_from_text=>'show complains'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24786195454689217)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17204940339777556.123456)
,p_translate_from_id=>wwv_flow_imp.id(17204940339777556)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\062F\0627\062F\0627\062A \0627\0644\0639\0627\0645\0647')
,p_translate_from_text=>'public setting'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24786312837689220)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802104740841583.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802104740841583)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24786544461689220)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24216592225695167.123456)
,p_translate_from_id=>wwv_flow_imp.id(24216592225695167)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0648\0627\0642\0635 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'shortcoming medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24786796671689220)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24220583299728475.123456)
,p_translate_from_id=>wwv_flow_imp.id(24220583299728475)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\062F\0648\064A\0647 \0645\0646\062A\0647\064A\0647 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'expiredDate Medecine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24786966771689220)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(27909448351113939.123456)
,p_translate_from_id=>wwv_flow_imp.id(27909448351113939)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0635\0627\062F\0631\0627\062A')
,p_translate_from_text=>'outgoings'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24787178609689221)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(29106797295879375.123456)
,p_translate_from_id=>wwv_flow_imp.id(29106797295879375)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0644\0628 \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Returned Order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24787216594689221)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38128321276230399.123456)
,p_translate_from_id=>wwv_flow_imp.id(38128321276230399)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0631\062A\062C\0639\0627\062A')
,p_translate_from_text=>'Returns'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24787422069689221)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38419377914857005.123456)
,p_translate_from_id=>wwv_flow_imp.id(38419377914857005)
,p_translate_column_id=>100
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062A\0642\0631\064A\0631 \0627\0644\0645\0627\0644\064A \0627\0644\0633\0646\0648\064A')
,p_translate_from_text=>'Annual Financial Report'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24787600495689237)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7318250785072838.123456)
,p_translate_from_id=>wwv_flow_imp.id(7318250785072838)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'admin'
,p_translate_from_text=>'admin'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24787890681689237)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7318662477072841.123456)
,p_translate_from_id=>wwv_flow_imp.id(7318662477072841)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Casher'
,p_translate_from_text=>'Casher'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24788029696689237)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10711993621284496.123456)
,p_translate_from_id=>wwv_flow_imp.id(10711993621284496)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0631\0643\0647')
,p_translate_from_text=>'Company'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24788256659689237)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10712417352284502.123456)
,p_translate_from_id=>wwv_flow_imp.id(10712417352284502)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062E\0632\0646')
,p_translate_from_text=>'Storehouse'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24788480857689237)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18522609937688181.123456)
,p_translate_from_id=>wwv_flow_imp.id(18522609937688181)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\064A\0646\0627\064A\0631')
,p_translate_from_text=>'January'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24788615346689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18523045168688187.123456)
,p_translate_from_id=>wwv_flow_imp.id(18523045168688187)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0641\0628\0631\0627\064A\0631')
,p_translate_from_text=>'February '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24788806315689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18523478670688187.123456)
,p_translate_from_id=>wwv_flow_imp.id(18523478670688187)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0627\0631\0633')
,p_translate_from_text=>'March '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24789093873689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18523882039688187.123456)
,p_translate_from_id=>wwv_flow_imp.id(18523882039688187)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0628\0631\064A\0644 ')
,p_translate_from_text=>'April '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24789204424689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18524227049688189.123456)
,p_translate_from_id=>wwv_flow_imp.id(18524227049688189)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0627\064A\0648')
,p_translate_from_text=>'May '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24789457523689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18524632815688189.123456)
,p_translate_from_id=>wwv_flow_imp.id(18524632815688189)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\064A\0648\0646\064A\0648 ')
,p_translate_from_text=>'June '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24789638284689239)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18525030764688193.123456)
,p_translate_from_id=>wwv_flow_imp.id(18525030764688193)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\064A\0648\0644\064A\0648 ')
,p_translate_from_text=>'July '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24789847782689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18525466920688193.123456)
,p_translate_from_id=>wwv_flow_imp.id(18525466920688193)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\063A\0633\0637\0633 ')
,p_translate_from_text=>'August '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24790008677689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18525863960688193.123456)
,p_translate_from_id=>wwv_flow_imp.id(18525863960688193)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0628\062A\0645\0628\0631 ')
,p_translate_from_text=>'September '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24790274596689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18526241734688195.123456)
,p_translate_from_id=>wwv_flow_imp.id(18526241734688195)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0643\062A\0648\0628\0631 ')
,p_translate_from_text=>'October '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24790468835689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18526654879688195.123456)
,p_translate_from_id=>wwv_flow_imp.id(18526654879688195)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0648\0641\0645\0628\0631 ')
,p_translate_from_text=>'November '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24790687210689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(18527053190688196.123456)
,p_translate_from_id=>wwv_flow_imp.id(18527053190688196)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062F\064A\0633\064A\0645\0628\0631')
,p_translate_from_text=>'December'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24790890574689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20308552863003950.123456)
,p_translate_from_id=>wwv_flow_imp.id(20308552863003950)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0641\0627\062A\0648\0631\0647 \0628\064A\0639')
,p_translate_from_text=>'sell invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24791073784689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20309020545003956.123456)
,p_translate_from_id=>wwv_flow_imp.id(20309020545003956)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0641\0627\062A\0648\0631\0647 \0634\0631\0627\0621')
,p_translate_from_text=>'buy invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24791272264689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20309402980003956.123456)
,p_translate_from_id=>wwv_flow_imp.id(20309402980003956)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0641\0627\062A\0648\0631\0647 \0645\0631\062A\062C\0639')
,p_translate_from_text=>'return invoice'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24791439989689240)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(21800926800345290.123456)
,p_translate_from_id=>wwv_flow_imp.id(21800926800345290)
,p_translate_column_id=>103
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Data Entry'
,p_translate_from_text=>'Data Entry'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24791683361689259)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307600621993624.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307600621993624)
,p_translate_column_id=>105
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'no type'
,p_translate_from_text=>'no type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24791824619689259)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504700465891547.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504700465891547)
,p_translate_column_id=>105
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'all'
,p_translate_from_text=>'all'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24792015105689262)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24218050416695330.123456)
,p_translate_from_id=>wwv_flow_imp.id(24218050416695330)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24792210166689262)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34104943656172531.123456)
,p_translate_from_id=>wwv_flow_imp.id(34104943656172531)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24792474519689264)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105093053172532.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105093053172532)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0637\0644\0628')
,p_translate_from_text=>'Order Id'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24792622175689264)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105132902172533.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105132902172533)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0633\0639\0631')
,p_translate_from_text=>'Total Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24792847290689264)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105312035172534.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105312035172534)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Client Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24793039182689265)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713666893244118.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713666893244118)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24793221448689265)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713919233244120.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713919233244120)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0637\0644\0628')
,p_translate_from_text=>'Order Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24793461021689265)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714229284244123.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714229284244123)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0633\0639\0631')
,p_translate_from_text=>'Total Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24793640050689265)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714269227244124.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714269227244124)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Client Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24793846184689265)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28713702574291143.123456)
,p_translate_from_id=>wwv_flow_imp.id(28713702574291143)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24794004663689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28713812395291144.123456)
,p_translate_from_id=>wwv_flow_imp.id(28713812395291144)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantitiy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24794200968689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31711710819244098.123456)
,p_translate_from_id=>wwv_flow_imp.id(31711710819244098)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24794491411689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710055460291107.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710055460291107)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24794638445689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710220607291108.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710220607291108)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'User Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24794848221689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710255771291109.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710255771291109)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0637\0644\0628')
,p_translate_from_text=>'Order Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24795026078689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710409114291110.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710409114291110)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24795221601689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710484969291111.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710484969291111)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24795451106689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710618820291112.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710618820291112)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0633\0639\0631')
,p_translate_from_text=>'Total Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24795676658689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34102338372172505.123456)
,p_translate_from_id=>wwv_flow_imp.id(34102338372172505)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24795819645689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34102485834172506.123456)
,p_translate_from_id=>wwv_flow_imp.id(34102485834172506)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantitiy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24796053308689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34102701139172508.123456)
,p_translate_from_id=>wwv_flow_imp.id(34102701139172508)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'Edit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24796249945689267)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24706737474626597.123456)
,p_translate_from_id=>wwv_flow_imp.id(24706737474626597)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Rownumber'
,p_translate_from_text=>'Rownumber'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24796461118689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24221581090728496.123456)
,p_translate_from_id=>wwv_flow_imp.id(24221581090728496)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24796653919689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24222353095728497.123456)
,p_translate_from_id=>wwv_flow_imp.id(24222353095728497)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24796856923689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38307251436261638.123456)
,p_translate_from_id=>wwv_flow_imp.id(38307251436261638)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Date'
,p_translate_from_text=>'Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24797019163689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306976977261635.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306976977261635)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0642\0648\062F')
,p_translate_from_text=>'Money'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24797297903689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306817760261633.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306817760261633)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24797423769689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16002946466669003.123456)
,p_translate_from_id=>wwv_flow_imp.id(16002946466669003)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'User Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24797662631689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16003308785669003.123456)
,p_translate_from_id=>wwv_flow_imp.id(16003308785669003)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Customer Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24797817265689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16003766752669003.123456)
,p_translate_from_id=>wwv_flow_imp.id(16003766752669003)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \062A\064A\0644\064A\0641\0648\0646 \0627\0644\0639\0645\064A\0644')
,p_translate_from_text=>'Customer Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24798092689689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16004142555669003.123456)
,p_translate_from_id=>wwv_flow_imp.id(16004142555669003)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062D\062A\0648\064A \0627\0644\0634\0643\0648\064A')
,p_translate_from_text=>'Complain Text'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24798236299689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502039108891520.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502039108891520)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0630\0641')
,p_translate_from_text=>'delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24798419533689270)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14205004134481940.123456)
,p_translate_from_id=>wwv_flow_imp.id(14205004134481940)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24798682292689273)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401952290263307.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401952290263307)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24798875134689273)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14204674388481937.123456)
,p_translate_from_id=>wwv_flow_imp.id(14204674388481937)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24799088645689273)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402217164263309.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402217164263309)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0628\064A\0639')
,p_translate_from_text=>'Sell Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24799234637689273)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401721700263304.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401721700263304)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24799452113689275)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402817680263315.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402817680263315)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062D\0630\0641')
,p_translate_from_text=>'remove'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24799682733689275)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402319727263310.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402319727263310)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_translate_from_text=>'Notes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24799826229689275)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402869061263316.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402869061263316)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0623\0636\0627\0641\0647')
,p_translate_from_text=>'add'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24800003901689275)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403839609263326.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403839609263326)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24800240569689276)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403957193263327.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403957193263327)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantitiy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24800435321689276)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404087180263328.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404087180263328)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\063A\0627\0621 \0627\0644\0637\0644\0628')
,p_translate_from_text=>'cancel order'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24800656812689276)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708229131626611.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708229131626611)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24800852882689276)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24707922130626608.123456)
,p_translate_from_id=>wwv_flow_imp.id(24707922130626608)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24801058193689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24707673727626606.123456)
,p_translate_from_id=>wwv_flow_imp.id(24707673727626606)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24801200131689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708516079626614.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708516079626614)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0634\0631\0627\0621')
,p_translate_from_text=>'Buy Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24801422479689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708765672626617.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708765672626617)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0631\0627\0621')
,p_translate_from_text=>'Buy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24801655002689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708847033626618.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708847033626618)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\0628\0627\0631\0643\0648\062F')
,p_translate_from_text=>'Barcode Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24801866313689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24711467365626644.123456)
,p_translate_from_id=>wwv_flow_imp.id(24711467365626644)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24802098853689279)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24711552725626645.123456)
,p_translate_from_id=>wwv_flow_imp.id(24711552725626645)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantitiy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24802254845689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601397570020000.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601397570020000)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24802438384689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7311136261037588.123456)
,p_translate_from_id=>wwv_flow_imp.id(7311136261037588)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'Edit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24802600312689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7311492191037596.123456)
,p_translate_from_id=>wwv_flow_imp.id(7311492191037596)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0633\0645')
,p_translate_from_text=>'Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24802865734689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7311876185037596.123456)
,p_translate_from_id=>wwv_flow_imp.id(7311876185037596)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\064A\0644\064A\0641\0648\0646')
,p_translate_from_text=>'Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24803089898689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7312236378037597.123456)
,p_translate_from_id=>wwv_flow_imp.id(7312236378037597)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\064A\0645\064A\0644')
,p_translate_from_text=>'Email'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24803234551689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7312717834037599.123456)
,p_translate_from_id=>wwv_flow_imp.id(7312717834037599)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0631')
,p_translate_from_text=>'Role'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24803498925689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7313074015037599.123456)
,p_translate_from_id=>wwv_flow_imp.id(7313074015037599)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24803688618689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914567509930299.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914567509930299)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24803839535689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10307764240912563.123456)
,p_translate_from_id=>wwv_flow_imp.id(10307764240912563)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'Edit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24804095482689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10308190395912571.123456)
,p_translate_from_id=>wwv_flow_imp.id(10308190395912571)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24804221530689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918882436930342.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918882436930342)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24804472823689281)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512185115195299.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512185115195299)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'Edit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24804644851689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512327372195300.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512327372195300)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24804888387689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512337310195301.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512337310195301)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\064A\0644\064A\0641\0648\0646')
,p_translate_from_text=>'Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24805042313689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10602249776239822.123456)
,p_translate_from_id=>wwv_flow_imp.id(10602249776239822)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24805237995689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512516843195302.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512516843195302)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\064A\0645\064A\0644')
,p_translate_from_text=>'Email'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24805431050689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512630658195303.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512630658195303)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0635\064A\062F')
,p_translate_from_text=>'Balance'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24805648421689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512688879195304.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512688879195304)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24805853221689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611467784472733.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611467784472733)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'EDIT'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24806023490689284)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611867938472741.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611867938472741)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0628\0627\0631\0643\0648\062F')
,p_translate_from_text=>'Barcode ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24806225100689287)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11612306497472741.123456)
,p_translate_from_id=>wwv_flow_imp.id(11612306497472741)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24806411253689287)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11612693530472741.123456)
,p_translate_from_id=>wwv_flow_imp.id(11612693530472741)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24806638590689287)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202869930481919.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202869930481919)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24806809190689287)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11613033671472741.123456)
,p_translate_from_id=>wwv_flow_imp.id(11613033671472741)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0634\0631\0627\0621')
,p_translate_from_text=>'Buy Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24807008196689289)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11613474172472744.123456)
,p_translate_from_id=>wwv_flow_imp.id(11613474172472744)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0628\064A\0639')
,p_translate_from_text=>'Sell Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24807279313689289)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11613919028472744.123456)
,p_translate_from_id=>wwv_flow_imp.id(11613919028472744)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24807485008689289)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203413562959715.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203413562959715)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0633\062D')
,p_translate_from_text=>'Delete'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24807632118689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602966531020016.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602966531020016)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24807843789689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203259085959714.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203259085959714)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_translate_from_text=>'Notes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24808048104689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503162003569011.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503162003569011)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24808216191689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503281050569012.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503281050569012)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\0628\0627\0631\0643\0648\062F')
,p_translate_from_text=>'Barcode Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24808404721689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503390863569013.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503390863569013)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24808638808689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503463253569014.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503463253569014)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0648\062D\062F\0647')
,p_translate_from_text=>'Unit Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24808863952689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503569502569015.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503569502569015)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0634\0631\0627\0621')
,p_translate_from_text=>'Buy Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24809053513689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503725917569016.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503725917569016)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0639\0631 \0627\0644\0628\064A\0639')
,p_translate_from_text=>'Sell Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24809236809689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503738648569017.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503738648569017)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0646\062A\0647\0627\0621 \0627\0644\0635\0644\0627\062D\064A\0647')
,p_translate_from_text=>'Expired Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24809414834689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503847091569018.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503847091569018)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_translate_from_text=>'Notes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24809662032689293)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504163014569021.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504163014569021)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0643\0645\064A\0647')
,p_translate_from_text=>'Quantity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24809828551689296)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504571323569025.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504571323569025)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24810038522689296)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504375889569023.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504375889569023)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Color2'
,p_translate_from_text=>'Color2'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24810291329689296)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306065103993609.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306065103993609)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0638\0647\0627\0631 \0627\0644\0641\0627\062A\0648\0631\0647l')
,p_translate_from_text=>'show bill'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24810422014689298)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306210862993610.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306210862993610)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0647')
,p_translate_from_text=>'Invoice Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24810611619689298)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306294831993611.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306294831993611)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'User Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24810834604689300)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306396950993612.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306396950993612)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0637\0644\0628')
,p_translate_from_text=>'Order Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24811045265689300)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306483364993613.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306483364993613)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0648\0639')
,p_translate_from_text=>'Type'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24811282973689300)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306631269993614.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306631269993614)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0645\0648\0631\062F')
,p_translate_from_text=>'Provider Id'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24811416690689300)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306671141993615.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306671141993615)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0633\0639\0631')
,p_translate_from_text=>'Total Price'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24811625935689300)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308071808993629.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308071808993629)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\0644\0642')
,p_translate_from_text=>'close'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24811810464689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20629623924889603.123456)
,p_translate_from_id=>wwv_flow_imp.id(20629623924889603)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24812078136689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20629647424889604.123456)
,p_translate_from_id=>wwv_flow_imp.id(20629647424889604)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0628\0627\0631\0643\0648\0631')
,p_translate_from_text=>'Barcode'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24812251040689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20629831409889605.123456)
,p_translate_from_id=>wwv_flow_imp.id(20629831409889605)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062D\0627\0644\0647')
,p_translate_from_text=>'Status'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24812478741689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20629856595889606.123456)
,p_translate_from_id=>wwv_flow_imp.id(20629856595889606)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0639\0644\0648\0645\0627\062A')
,p_translate_from_text=>'Information'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24812694472689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106095114172542.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106095114172542)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0645\0631\062A\062C\0639')
,p_translate_from_text=>'Return Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24812877155689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106202066172543.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106202066172543)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0642\0648\062F')
,p_translate_from_text=>'Money'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24813038510689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23802582025841669.123456)
,p_translate_from_id=>wwv_flow_imp.id(23802582025841669)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\0639\0631\064A\0641\064A \0644\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24813256286689301)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23803023692841683.123456)
,p_translate_from_id=>wwv_flow_imp.id(23803023692841683)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0642\0648\062F')
,p_translate_from_text=>'Money'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24813487627689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23803385680841683.123456)
,p_translate_from_id=>wwv_flow_imp.id(23803385680841683)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0648\0627\0631\062F')
,p_translate_from_text=>'Income Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24813656438689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605139133020038.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605139133020038)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0646\0642\0648\062F')
,p_translate_from_text=>'Money'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24813826643689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605275853020039.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605275853020039)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0627\0631\064A\062E \0627\0644\0635\0627\062F\0631')
,p_translate_from_text=>'Expenses Date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24814088477689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24706878764626598.123456)
,p_translate_from_id=>wwv_flow_imp.id(24706878764626598)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Rownumber'
,p_translate_from_text=>'Rownumber'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24814277170689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24217679026695330.123456)
,p_translate_from_id=>wwv_flow_imp.id(24217679026695330)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0627\0621')
,p_translate_from_text=>'Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24814487721689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501662445065214.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501662445065214)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0634\0637')
,p_translate_from_text=>'Active'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24814675675689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23301280045610637.123456)
,p_translate_from_id=>wwv_flow_imp.id(23301280045610637)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062A\0639\062F\064A\0644')
,p_translate_from_text=>'Edit'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24814802665689303)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23301528287610648.123456)
,p_translate_from_id=>wwv_flow_imp.id(23301528287610648)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0633\0645')
,p_translate_from_text=>'Name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24815064798689304)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23301923667610648.123456)
,p_translate_from_id=>wwv_flow_imp.id(23301923667610648)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0631\0642\0645 \0627\0644\062A\064A\0644\064A\0641\0648\0646')
,p_translate_from_text=>'Phone'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24815202884689304)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23302391082610648.123456)
,p_translate_from_id=>wwv_flow_imp.id(23302391082610648)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\064A\0645\064A\0644')
,p_translate_from_text=>'Email'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24815485034689304)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23302704149610650.123456)
,p_translate_from_id=>wwv_flow_imp.id(23302704149610650)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\062F\0648\0631')
,p_translate_from_text=>'Role'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24815602083689304)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23303125771610650.123456)
,p_translate_from_id=>wwv_flow_imp.id(23303125771610650)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24815813044689304)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23303981639610653.123456)
,p_translate_from_id=>wwv_flow_imp.id(23303981639610653)
,p_translate_column_id=>106
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0634\0637')
,p_translate_from_text=>'Active'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24816014965689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105093053172532.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105093053172532)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#order_id#'
,p_translate_from_text=>'#order_id#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24816281492689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713919233244120.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713919233244120)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#order_id#'
,p_translate_from_text=>'#order_id#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24816490265689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31711710819244098.123456)
,p_translate_from_id=>wwv_flow_imp.id(31711710819244098)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24816648077689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28710255771291109.123456)
,p_translate_from_id=>wwv_flow_imp.id(28710255771291109)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#order_id#'
,p_translate_from_text=>'#order_id#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24816892708689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34102701139172508.123456)
,p_translate_from_id=>wwv_flow_imp.id(34102701139172508)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24817082706689317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502039108891520.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502039108891520)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash-o"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash-o"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24817212440689318)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402817680263315.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402817680263315)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>' <span aria-hidden="true" class="t-Icon fa fa-minus-circle"></span>'
,p_translate_from_text=>' <span aria-hidden="true" class="t-Icon fa fa-minus-circle"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24817481831689318)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12402869061263316.123456)
,p_translate_from_id=>wwv_flow_imp.id(12402869061263316)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-plus-circle"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-plus-circle"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24817678403689318)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404087180263328.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404087180263328)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-times-circle"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-times-circle"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24817897458689320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708765672626617.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708765672626617)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-credit-card"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-credit-card"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818025396689320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601397570020000.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601397570020000)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818294647689320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7311136261037588.123456)
,p_translate_from_id=>wwv_flow_imp.id(7311136261037588)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818427937689320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914567509930299.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914567509930299)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818655417689320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10307764240912563.123456)
,p_translate_from_id=>wwv_flow_imp.id(10307764240912563)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818841398689321)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918882436930342.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918882436930342)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24818928335689321)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10512185115195299.123456)
,p_translate_from_id=>wwv_flow_imp.id(10512185115195299)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24819154839689321)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10602249776239822.123456)
,p_translate_from_id=>wwv_flow_imp.id(10602249776239822)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24819340664689321)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11611467784472733.123456)
,p_translate_from_id=>wwv_flow_imp.id(11611467784472733)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24819578047689323)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203413562959715.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203413562959715)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-trash"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24819758359689323)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19306065103993609.123456)
,p_translate_from_id=>wwv_flow_imp.id(19306065103993609)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-file-text-o"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-file-text-o"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24819903905689323)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308071808993629.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308071808993629)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span aria-hidden="true" class="t-Icon fa fa-times-circle"></span>'
,p_translate_from_text=>'<span aria-hidden="true" class="t-Icon fa fa-times-circle"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24820191278689323)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106095114172542.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106095114172542)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#return date#'
,p_translate_from_text=>'#return date#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24820360710689323)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23803385680841683.123456)
,p_translate_from_id=>wwv_flow_imp.id(23803385680841683)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#income_date#'
,p_translate_from_text=>'#income_date#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24820540688689325)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605275853020039.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605275853020039)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#EXPENSES_DATE#'
,p_translate_from_text=>'#EXPENSES_DATE#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24820739112689325)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(23301280045610637.123456)
,p_translate_from_id=>wwv_flow_imp.id(23301280045610637)
,p_translate_column_id=>107
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
,p_translate_from_text=>' <span aria-hidden="true" class="t-Icon fa fa-pencil-square"></span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24820902210689329)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14204674388481937.123456)
,p_translate_from_id=>wwv_flow_imp.id(14204674388481937)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
,p_translate_from_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24821176763689329)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401721700263304.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401721700263304)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR2#">#expired_date#</span>'
,p_translate_from_text=>'<span style="color:#COLOR2#">#expired_date#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24821325234689329)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202869930481919.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202869930481919)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
,p_translate_from_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24821502749689329)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11613919028472744.123456)
,p_translate_from_id=>wwv_flow_imp.id(11613919028472744)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR2#">#expired_date#</span>'
,p_translate_from_text=>'<span style="color:#COLOR2#">#expired_date#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24821779180689332)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504163014569021.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504163014569021)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
,p_translate_from_text=>'<span style="color:#COLOR#">#QUANTITY#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24821924321689332)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504375889569023.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504375889569023)
,p_translate_column_id=>108
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="color:#COLOR2#">#COLOR2#</span>'
,p_translate_from_text=>'<span style="color:#COLOR2#">#COLOR2#</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24822157161689345)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504747106569027.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504747106569027)
,p_translate_column_id=>111
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="text-transform:capitalize;">this is the minimum quantitiy before warn you about the quantity in the stock</span>'
,p_translate_from_text=>'<span style="text-transform:capitalize;">this is the minimum quantitiy before warn you about the quantity in the stock</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24822393078689345)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504882325569028.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504882325569028)
,p_translate_column_id=>111
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="text-transform:capitalize;">this the minimum date  you will receive warn in notificatin center of the medcine ,tell you the expire date of medcine (in month)</span>'
,p_translate_from_text=>'<span style="text-transform:capitalize;">this the minimum date  you will receive warn in notificatin center of the medcine ,tell you the expire date of medcine (in month)</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24822532686689345)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16505226003569031.123456)
,p_translate_from_id=>wwv_flow_imp.id(16505226003569031)
,p_translate_column_id=>111
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="text-transform:capitalize;"> ',
'    this the last date tell you the medicine is expired and the medicine not valid to use (in Month)',
'    </span>'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="text-transform:capitalize;"> ',
'    this the last date tell you the medicine is expired and the medicine not valid to use (in Month)',
'    </span>'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24822759823689346)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714644225244128.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714644225244128)
,p_translate_column_id=>111
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<span style="text-transform:capitalize">This is the period within which the customer can return the medication</span>'
,p_translate_from_text=>'<span style="text-transform:capitalize">This is the period within which the customer can return the medication</span>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24822990197689350)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6877217481923041.123456)
,p_translate_from_id=>wwv_flow_imp.id(6877217481923041)
,p_translate_column_id=>112
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'<div class="t-PopupLOV-pagination">Row(s) #FIRST_ROW# - #LAST_ROW#</div>'
,p_translate_from_text=>'<div class="t-PopupLOV-pagination">Row(s) #FIRST_ROW# - #LAST_ROW#</div>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24823165411689404)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17302276701088558.123456)
,p_translate_from_id=>wwv_flow_imp.id(17302276701088558)
,p_translate_column_id=>124
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'error in mini quantitity in computation'
,p_translate_from_text=>'error in mini quantitity in computation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24823393423689404)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17302498027093135.123456)
,p_translate_from_id=>wwv_flow_imp.id(17302498027093135)
,p_translate_column_id=>124
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'error in minidate in computation '
,p_translate_from_text=>'error in minidate in computation '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24823587832689407)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(17302651476094956.123456)
,p_translate_from_id=>wwv_flow_imp.id(17302651476094956)
,p_translate_column_id=>124
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'error in lastminidate in computaiton'
,p_translate_from_text=>'error in lastminidate in computaiton'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24823714748689407)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(33506958438723613.123456)
,p_translate_from_id=>wwv_flow_imp.id(33506958438723613)
,p_translate_column_id=>124
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'error in retured duration process ',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'error in retured duration process ',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24823943452689420)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503086156569010.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503086156569010)
,p_translate_column_id=>142
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0628\0627\0639\0647')
,p_translate_from_text=>'Print'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824184555689420)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306492416261630.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306492416261630)
,p_translate_column_id=>142
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0637\0628\0627\0639\0647')
,p_translate_from_text=>'Print'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824311221689426)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16503086156569010.123456)
,p_translate_from_id=>wwv_flow_imp.id(16503086156569010)
,p_translate_column_id=>143
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824404809689426)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306492416261630.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306492416261630)
,p_translate_column_id=>143
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'data'
,p_translate_from_text=>'data'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824636947689937)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22300473024741143.123456)
,p_translate_from_id=>wwv_flow_imp.id(22300473024741143)
,p_translate_column_id=>257
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\064A\0631 \0645\0635\0631\062D \0644\0643 \0628\0627\0644\062F\062E\0648\0644 \0644\0647\0630\0647 \0627\0644\0635\0641\062D\0647 \0645\0646 \0641\0636\0644\0637 \062A\0648\0627\0635\0644 \0645\0639 \0627\0644\0645\0633\0624\0644')
,p_translate_from_text=>'You are not allowed to be here Please Call the administrator!!'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824743809689939)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22900277267522539.123456)
,p_translate_from_id=>wwv_flow_imp.id(22900277267522539)
,p_translate_column_id=>257
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\064A\0631 \0645\0635\0631\062D \0644\0643 \0628\0627\0644\062F\062E\0648\0644 \0644\0647\0630\0647 \0627\0644\0635\0641\062D\0647 \0645\0646 \0641\0636\0644\0637 \062A\0648\0627\0635\0644 \0645\0639 \0627\0644\0645\0633\0624\0644')
,p_translate_from_text=>'You are not allowed to be here Please Call the administrator!!'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24824976848689945)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22300644307745342.123456)
,p_translate_from_id=>wwv_flow_imp.id(22300644307745342)
,p_translate_column_id=>257
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\064A\0631 \0645\0635\0631\062D \0644\0643 \0628\0627\0644\062F\062E\0648\0644 \0644\0647\0630\0647 \0627\0644\0635\0641\062D\0647 \0645\0646 \0641\0636\0644\0637 \062A\0648\0627\0635\0644 \0645\0639 \0627\0644\0645\0633\0624\0644')
,p_translate_from_text=>'You are not allowed to be here Please Call the administrator!!'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24825101181689945)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22101237470508314.123456)
,p_translate_from_id=>wwv_flow_imp.id(22101237470508314)
,p_translate_column_id=>257
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\063A\064A\0631 \0645\0635\0631\062D \0644\0643 \0628\0627\0644\062F\062E\0648\0644 \0644\0647\0630\0647 \0627\0644\0635\0641\062D\0647 \0645\0646 \0641\0636\0644\0637 \062A\0648\0627\0635\0644 \0645\0639 \0627\0644\0645\0633\0624\0644')
,p_translate_from_text=>'You are not allowed to be here Please Call the administrator!!'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24825344521689996)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24825513898689996)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917047054930324.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917047054930324)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24825726044689996)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917144013930325.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917144013930325)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24825902702689996)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917304835930326.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917304835930326)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24826114745689996)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24826332312690001)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403248231263320.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403248231263320)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24826523086690001)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712935017244111.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712935017244111)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24826764252690001)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403371438263321.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403371438263321)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24826919602690001)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14203333045481924.123456)
,p_translate_from_id=>wwv_flow_imp.id(14203333045481924)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24827175267690001)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20629962577889607.123456)
,p_translate_from_id=>wwv_flow_imp.id(20629962577889607)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24827329880690001)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710711418626636.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710711418626636)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24827590736690004)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601713891020003.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601713891020003)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24827791926690004)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24827989475690004)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915339498930307.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915339498930307)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24828138974690004)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24828367350690004)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301216024037477.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301216024037477)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24828582115690004)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301567068037497.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301567068037497)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24828781860690004)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301883712037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301883712037508)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24828916895690006)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302236384037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302236384037508)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24829156279690006)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302636680037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302636680037510)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'1'
,p_translate_from_text=>'1'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24829334103690006)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501710324065215.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501710324065215)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24829506909690006)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7303049088037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7303049088037510)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24829796692690006)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914514540930298.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914514540930298)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24829923375690006)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604258717020029.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604258717020029)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24830183746690006)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14201443285481905.123456)
,p_translate_from_id=>wwv_flow_imp.id(14201443285481905)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24830364993690006)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14201981319481910.123456)
,p_translate_from_id=>wwv_flow_imp.id(14201981319481910)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24830593977690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14201644421481907.123456)
,p_translate_from_id=>wwv_flow_imp.id(14201644421481907)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24830784668690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14201577544481906.123456)
,p_translate_from_id=>wwv_flow_imp.id(14201577544481906)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24830943737690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14201764913481908.123456)
,p_translate_from_id=>wwv_flow_imp.id(14201764913481908)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24831196933690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604871643020035.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604871643020035)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24831389779690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305324097993601.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305324097993601)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24831584628690010)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713037280244112.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713037280244112)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24831748467690010)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24831934375690010)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919289011930346.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919289011930346)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24832112216690012)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301253140912417.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301253140912417)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24832322979690012)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301676580912439.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301676580912439)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24832577670690012)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24832730979690012)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603485392239856.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603485392239856)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24832963336690012)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10700974664257016.123456)
,p_translate_from_id=>wwv_flow_imp.id(10700974664257016)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24833171508690012)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701422288257024.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701422288257024)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24833395566690012)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702143502257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702143502257033)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24833593282690012)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702993425257035.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702993425257035)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24833757764690014)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204007706959721.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204007706959721)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24833976807690014)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24834136876690014)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11601175040472569.123456)
,p_translate_from_id=>wwv_flow_imp.id(11601175040472569)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24834366911690014)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602014103472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602014103472621)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24834565404690014)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602395820472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602395820472621)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24834703877690014)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24834991407690014)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602880090020015.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602880090020015)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24835177490690015)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203193855959713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203193855959713)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24835307772690015)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504233392569022.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504233392569022)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24835591092690015)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714644225244128.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714644225244128)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24835700984690015)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24835981017690015)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307600621993624.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307600621993624)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24836146430690015)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308654977993635.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308654977993635)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24836337162690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710019647626629.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710019647626629)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24836540197690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24711225888626641.123456)
,p_translate_from_id=>wwv_flow_imp.id(24711225888626641)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24836748847690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709175971626621.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709175971626621)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24836969095690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709232909626622.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709232909626622)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24837155298690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710215221626631.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710215221626631)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24837315375690017)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24837578645690018)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602768264020014.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602768264020014)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24837744894690018)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106280260172544.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106280260172544)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24837939732690018)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106379850172545.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106379850172545)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24838196665690018)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106447004172546.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106447004172546)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24838353459690018)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631487138889622.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631487138889622)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24838532863690018)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631557873889623.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631557873889623)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24838738277690018)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632274450889630.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632274450889630)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24838960838690018)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605459736020041.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605459736020041)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24839177441690021)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605625775020042.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605625775020042)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24839384273690021)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605655445020043.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605655445020043)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24839596260690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34104522962172526.123456)
,p_translate_from_id=>wwv_flow_imp.id(34104522962172526)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24839749004690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709569867291102.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709569867291102)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24839953660690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713279186244114.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713279186244114)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24840151064690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712128717244102.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712128717244102)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24840349649690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713378822244115.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713378822244115)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24840557959690023)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28713181710291138.123456)
,p_translate_from_id=>wwv_flow_imp.id(28713181710291138)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24840721368690023)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715153895244133.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715153895244133)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24840998736690025)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103071448172512.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103071448172512)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24841155214690025)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103177163172513.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103177163172513)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24841318991690025)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103796631172519.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103796631172519)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24841528178690025)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28713281443291139.123456)
,p_translate_from_id=>wwv_flow_imp.id(28713281443291139)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24841791324690025)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901500228085136.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901500228085136)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24841978431690025)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901867395085160.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901867395085160)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24842143089690025)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712130133291127.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712130133291127)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24842344214690025)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30902317031085169.123456)
,p_translate_from_id=>wwv_flow_imp.id(30902317031085169)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24842566954690026)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306908240261634.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306908240261634)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24842782912690026)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001546580605315.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001546580605315)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24842951175690026)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503397188891533.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503397188891533)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24843120555690026)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002156806605321.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002156806605321)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24843349065690026)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002949104605329.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002949104605329)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24843507486690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003966260605339.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003966260605339)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24843721169690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504538143891545.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504538143891545)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24843949989690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20100802369048604.123456)
,p_translate_from_id=>wwv_flow_imp.id(20100802369048604)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24844126662690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101647605048612.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101647605048612)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24844314080690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001235166605312.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001235166605312)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24844589716690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503409893891534.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503409893891534)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24844758552690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003048038605330.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003048038605330)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24844927107690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504622845891546.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504622845891546)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24845188595690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101744232048613.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101744232048613)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24845329282690029)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504700465891547.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504700465891547)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24845554604690029)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15802725879616060.123456)
,p_translate_from_id=>wwv_flow_imp.id(15802725879616060)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24845767192690029)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501938475891519.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501938475891519)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24845937534690029)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803524366616106.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803524366616106)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24846138859690029)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15804390414616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15804390414616107)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24846376518690029)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502853568891528.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502853568891528)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'ROW'
,p_translate_from_text=>'ROW'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24846579612690032)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502338308891523.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502338308891523)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24846746871690032)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24846918491690032)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6905147704923424.123456)
,p_translate_from_id=>wwv_flow_imp.id(6905147704923424)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24847102980690032)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6905582533923442.123456)
,p_translate_from_id=>wwv_flow_imp.id(6905582533923442)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24847328263690032)
,p_page_id=>10011
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6910898321923569.123456)
,p_translate_from_id=>wwv_flow_imp.id(6910898321923569)
,p_translate_column_id=>268
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24847524718690040)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP'
,p_translate_from_text=>'POPUP'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24847794630690040)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24847944212690040)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712935017244111.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712935017244111)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24848196616690040)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24848353206690040)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24848559951690042)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301567068037497.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301567068037497)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24848715812690042)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301883712037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301883712037508)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24848920116690042)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302236384037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302236384037508)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24849164352690042)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7303049088037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7303049088037510)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24849310466690042)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24849525902690042)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301676580912439.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301676580912439)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24849712568690042)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24849999251690043)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701422288257024.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701422288257024)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24850188765690043)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702143502257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702143502257033)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24850345387690043)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702993425257035.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702993425257035)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24850518353690043)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24850776034690043)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602014103472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602014103472621)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24850962127690043)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602395820472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602395820472621)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24851109926690043)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP'
,p_translate_from_text=>'POPUP'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24851398506690045)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602880090020015.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602880090020015)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24851530485690045)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203193855959713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203193855959713)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24851789612690045)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504233392569022.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504233392569022)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24851959927690045)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31714644225244128.123456)
,p_translate_from_id=>wwv_flow_imp.id(31714644225244128)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24852199603690045)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP'
,p_translate_from_text=>'POPUP'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24852340634690045)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307600621993624.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307600621993624)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24852593424690050)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709175971626621.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709175971626621)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24852715426690050)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709232909626622.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709232909626622)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24852976743690050)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710215221626631.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710215221626631)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24853176602690050)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP'
,p_translate_from_text=>'POPUP'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24853325537690050)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602768264020014.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602768264020014)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24853558191690050)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106280260172544.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106280260172544)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24853737052690050)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106379850172545.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106379850172545)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24853932024690050)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106447004172546.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106447004172546)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24854174357690050)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631487138889622.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631487138889622)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24854379376690050)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631557873889623.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631557873889623)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24854542780690050)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632274450889630.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632274450889630)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24854761907690050)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605459736020041.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605459736020041)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24854972734690051)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605625775020042.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605625775020042)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24855192331690051)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605655445020043.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605655445020043)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24855346609690051)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709569867291102.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709569867291102)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24855509466690051)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713279186244114.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713279186244114)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24855755165690051)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713378822244115.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713378822244115)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24855929972690054)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103177163172513.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103177163172513)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'LOV'
,p_translate_from_text=>'LOV'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24856129067690054)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103796631172519.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103796631172519)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24856322535690054)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901867395085160.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901867395085160)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'LOV'
,p_translate_from_text=>'LOV'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24856555730690054)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712130133291127.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712130133291127)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VALUE'
,p_translate_from_text=>'VALUE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24856774608690054)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30902317031085169.123456)
,p_translate_from_id=>wwv_flow_imp.id(30902317031085169)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24856916196690054)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38306908240261634.123456)
,p_translate_from_id=>wwv_flow_imp.id(38306908240261634)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24857149723690054)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001546580605315.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001546580605315)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24857396071690054)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503397188891533.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503397188891533)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24857551721690054)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002156806605321.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002156806605321)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24857722072690054)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002949104605329.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002949104605329)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24857963263690054)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003966260605339.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003966260605339)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24858116800690056)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504538143891545.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504538143891545)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24858370497690056)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20100802369048604.123456)
,p_translate_from_id=>wwv_flow_imp.id(20100802369048604)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24858565293690056)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101647605048612.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101647605048612)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24858734032690056)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001235166605312.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001235166605312)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24858916146690056)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503409893891534.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503409893891534)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24859119804690059)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003048038605330.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003048038605330)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24859380330690059)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504622845891546.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504622845891546)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24859578226690059)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101744232048613.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101744232048613)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24859792153690059)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13504700465891547.123456)
,p_translate_from_id=>wwv_flow_imp.id(13504700465891547)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24859911051690059)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803524366616106.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803524366616106)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24860128829690059)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15804390414616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15804390414616107)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24860364471690059)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502853568891528.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502853568891528)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'FACET'
,p_translate_from_text=>'FACET'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24860507314690059)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>269
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24860715879690067)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24860975280690067)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701766810257030.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701766810257030)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24861197625690073)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702534557257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702534557257033)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24861304582690073)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11601613597472603.123456)
,p_translate_from_id=>wwv_flow_imp.id(11601613597472603)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24861547515690073)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603033167472656.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603033167472656)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24861716718690073)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603512474472656.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603512474472656)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24861980925690075)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14203027471481920.123456)
,p_translate_from_id=>wwv_flow_imp.id(14203027471481920)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24862135560690075)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24862314647690075)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504747106569027.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504747106569027)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24862563270690075)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504882325569028.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504882325569028)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24862793662690075)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16505226003569031.123456)
,p_translate_from_id=>wwv_flow_imp.id(16505226003569031)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24862973086690075)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24863156379690076)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307659936993625.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307659936993625)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24863389318690076)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709342886626623.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709342886626623)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24863544828690076)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24863718324690076)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103293281172514.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103293281172514)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'center'
,p_translate_from_text=>'center'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24863929529690079)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28711977230291126.123456)
,p_translate_from_id=>wwv_flow_imp.id(28711977230291126)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'right'
,p_translate_from_text=>'right'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24864104260690079)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30902317031085169.123456)
,p_translate_from_id=>wwv_flow_imp.id(30902317031085169)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24864372255690079)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803901538616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803901538616107)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'left'
,p_translate_from_text=>'left'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24864576832690079)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15804390414616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15804390414616107)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24864739652690081)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>270
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24864964950690085)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24865110091690085)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712935017244111.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712935017244111)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24865377574690087)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24865589938690087)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24865731169690090)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301567068037497.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301567068037497)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24865921969690090)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301883712037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301883712037508)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24866163305690090)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302236384037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302236384037508)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'EMAIL'
,p_translate_from_text=>'EMAIL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24866383357690090)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7303049088037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7303049088037510)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24866559051690090)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24866743294690090)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301676580912439.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301676580912439)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24866930949690090)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24867183072690090)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701422288257024.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701422288257024)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24867304377690090)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702143502257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702143502257033)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'EMAIL'
,p_translate_from_text=>'EMAIL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24867545098690092)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24867758467690092)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602014103472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602014103472621)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24867968814690092)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203193855959713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203193855959713)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24868125005690092)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504233392569022.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504233392569022)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24868346358690092)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709175971626621.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709175971626621)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24868587431690092)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709232909626622.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709232909626622)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24868779531690093)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710215221626631.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710215221626631)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24868970914690093)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106447004172546.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106447004172546)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24869149430690093)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632274450889630.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632274450889630)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24869383476690093)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605655445020043.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605655445020043)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24869597571690093)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709569867291102.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709569867291102)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24869739686690095)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713279186244114.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713279186244114)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24869906494690095)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713378822244115.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713378822244115)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24870181887690095)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103177163172513.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103177163172513)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24870312526690095)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103796631172519.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103796631172519)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24870542506690095)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901867395085160.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901867395085160)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24870705870690095)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712130133291127.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712130133291127)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24870970866690095)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30902317031085169.123456)
,p_translate_from_id=>wwv_flow_imp.id(30902317031085169)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24871174175690095)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803524366616106.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803524366616106)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24871321474690096)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15804390414616107.123456)
,p_translate_from_id=>wwv_flow_imp.id(15804390414616107)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24871522457690098)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>271
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24871764842690103)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24871913703690103)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712935017244111.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712935017244111)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24872172717690103)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24872337412690103)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24872518539690103)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301567068037497.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301567068037497)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24872780155690106)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7301883712037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7301883712037508)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24872981654690106)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7302236384037508.123456)
,p_translate_from_id=>wwv_flow_imp.id(7302236384037508)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24873162684690107)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7303049088037510.123456)
,p_translate_from_id=>wwv_flow_imp.id(7303049088037510)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24873331220690107)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24873559163690107)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10301676580912439.123456)
,p_translate_from_id=>wwv_flow_imp.id(10301676580912439)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24873773411690107)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24873963079690107)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10701422288257024.123456)
,p_translate_from_id=>wwv_flow_imp.id(10701422288257024)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24874163793690107)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10702143502257033.123456)
,p_translate_from_id=>wwv_flow_imp.id(10702143502257033)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24874314948690107)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24874584905690107)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11602014103472621.123456)
,p_translate_from_id=>wwv_flow_imp.id(11602014103472621)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24874796151690110)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203193855959713.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203193855959713)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24874907244690110)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504233392569022.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504233392569022)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24875119339690110)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709175971626621.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709175971626621)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24875320382690110)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709232909626622.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709232909626622)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24875534956690110)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24710215221626631.123456)
,p_translate_from_id=>wwv_flow_imp.id(24710215221626631)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24875762397690110)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34106447004172546.123456)
,p_translate_from_id=>wwv_flow_imp.id(34106447004172546)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24875985150690114)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632274450889630.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632274450889630)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24876158405690114)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605655445020043.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605655445020043)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24876364800690114)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709569867291102.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709569867291102)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24876594413690114)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713279186244114.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713279186244114)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24876773287690114)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31713378822244115.123456)
,p_translate_from_id=>wwv_flow_imp.id(31713378822244115)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24876971807690114)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103177163172513.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103177163172513)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24877187713690114)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103796631172519.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103796631172519)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24877302032690114)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30901867395085160.123456)
,p_translate_from_id=>wwv_flow_imp.id(30901867395085160)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24877555269690114)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712130133291127.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712130133291127)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLAIN'
,p_translate_from_text=>'PLAIN'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24877704924690114)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15803524366616106.123456)
,p_translate_from_id=>wwv_flow_imp.id(15803524366616106)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'BOTH'
,p_translate_from_text=>'BOTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24877943228690114)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>272
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24878111952690121)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>273
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24878207074690123)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>273
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24878468657690123)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>273
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24878635349690123)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>273
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'NONE'
,p_translate_from_text=>'NONE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24878808279690135)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>276
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24879064080690135)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>276
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24879219001690137)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>276
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24879498958690140)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>276
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24879661194690150)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604736209020034.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604736209020034)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'CLEAR_CACHE_FOR_PAGES'
,p_translate_from_text=>'CLEAR_CACHE_FOR_PAGES'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24879878516690150)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'REGION_SOURCE'
,p_translate_from_text=>'REGION_SOURCE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24880039098690150)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305872120993607.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305872120993607)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'CLEAR_CACHE_FOR_PAGES'
,p_translate_from_text=>'CLEAR_CACHE_FOR_PAGES'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24880209772690151)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10306129952912517.123456)
,p_translate_from_id=>wwv_flow_imp.id(10306129952912517)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'REGION_SOURCE'
,p_translate_from_text=>'REGION_SOURCE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24880462056690151)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'REGION_SOURCE'
,p_translate_from_text=>'REGION_SOURCE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24880613975690151)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11609722281472700.123456)
,p_translate_from_id=>wwv_flow_imp.id(11609722281472700)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'REGION_SOURCE'
,p_translate_from_text=>'REGION_SOURCE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24880845055690151)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15808844347616156.123456)
,p_translate_from_id=>wwv_flow_imp.id(15808844347616156)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'REGION_SOURCE'
,p_translate_from_text=>'REGION_SOURCE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24881043092690151)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6907623333923464.123456)
,p_translate_from_id=>wwv_flow_imp.id(6907623333923464)
,p_translate_column_id=>278
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'CLEAR_CACHE_CURRENT_PAGE'
,p_translate_from_text=>'CLEAR_CACHE_CURRENT_PAGE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24881224189690171)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25604736209020034.123456)
,p_translate_from_id=>wwv_flow_imp.id(25604736209020034)
,p_translate_column_id=>281
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'4'
,p_translate_from_text=>'4'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24881424073690171)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305872120993607.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305872120993607)
,p_translate_column_id=>281
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'3,4'
,p_translate_from_text=>'3,4'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24881647679690179)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>282
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24881875216690179)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10306129952912517.123456)
,p_translate_from_id=>wwv_flow_imp.id(10306129952912517)
,p_translate_column_id=>282
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24882007678690179)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>282
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24882212528690179)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11609722281472700.123456)
,p_translate_from_id=>wwv_flow_imp.id(11609722281472700)
,p_translate_column_id=>282
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24882473064690179)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15808844347616156.123456)
,p_translate_from_id=>wwv_flow_imp.id(15808844347616156)
,p_translate_column_id=>282
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24882616914690184)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>283
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24882856010690184)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10306129952912517.123456)
,p_translate_from_id=>wwv_flow_imp.id(10306129952912517)
,p_translate_column_id=>283
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24883052420690184)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>283
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24883217164690187)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11609722281472700.123456)
,p_translate_from_id=>wwv_flow_imp.id(11609722281472700)
,p_translate_column_id=>283
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24883478197690187)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15808844347616156.123456)
,p_translate_from_id=>wwv_flow_imp.id(15808844347616156)
,p_translate_column_id=>283
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24883688789690196)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7309346494037544.123456)
,p_translate_from_id=>wwv_flow_imp.id(7309346494037544)
,p_translate_column_id=>285
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24883895237690196)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10306129952912517.123456)
,p_translate_from_id=>wwv_flow_imp.id(10306129952912517)
,p_translate_column_id=>285
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24884097348690196)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10708626345257060.123456)
,p_translate_from_id=>wwv_flow_imp.id(10708626345257060)
,p_translate_column_id=>285
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24884205031690196)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11609722281472700.123456)
,p_translate_from_id=>wwv_flow_imp.id(11609722281472700)
,p_translate_column_id=>285
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24884497172690196)
,p_page_id=>31
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(15808844347616156.123456)
,p_translate_from_id=>wwv_flow_imp.id(15808844347616156)
,p_translate_column_id=>285
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24884623294690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403164741263319.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403164741263319)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'order_test number :=0;',
'medicine_test number :=0;',
'medicineQuant number :=0;',
'exDate date ; ',
'found boolean :=false ;',
'begin',
'',
'        --get quqntitiy to variable to use it ',
'        select "QUANTITY" into :P3_QUANTITIY from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'       ------------------------------------------------------------------------------------------------------',
'       -----------------------------------------------expird date check ------------------------------------',
'        --get expired Date to variable to use it ',
'',
'       select "expired_date" into :P3_EXPIREDDATE from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'            -- found := expiredate(exDate);',
'            -- if found then ',
'            --     :P3_EXPIREDDATE := ''false'' ; ',
'            -- else ',
'            --     :P3_EXPIREDDATE :=''true'' ;',
'            -- end if ; ',
'',
'          -- select "expired_date" into :P3_EXPIREDDATE from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'        --     if to_date(exDate,''YYYY-MM-DD'') < to_date(sysdate,''YYYY-MM-DD'')  then ',
'        --         :P3_EXPIREDDATE := ''false'';',
'        --     else ',
'        --         :P3_EXPIREDDATE := ''true'';',
'        --     end if ;',
'        --   ----------------  ----------------------------------------------------------------------------------',
'',
'          ',
'        --check if the quantitiy is available or not and if date is vaild or not ',
'        select "QUANTITY" , "expired_date" into medicineQuant , exDate from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'    ',
'    if medicineQuant >= 1 and to_date(exDate,''YYYY-MM-DD'') > to_date(sysdate,''YYYY-MM-DD'') then ',
'',
'            /* if make order first time this will be excuted  */',
'            if :P3_ORDER_ID is null  then ',
'                insert into "ph_orders" ("type") values (''s'');',
'                :P3_ORDER_ID := "order_seq".currval ;',
'            end if ;',
'',
'            -- select  "order_id" , "medince_id" into order_test , medicine_test  from "ph_orders_medcine" ',
'            --    where "order_id" = :P3_ORDER_ID and  ',
'',
'            found := checkmedcine(:P3_ORDER_ID , :P3_MEDICINE_ID);',
'            -- if :P3_QUANTITIY >= 1 then ',
'                    if found  then   --  test if the medcine exist in table or add new ',
'                       update "ph_orders_medcine" set "quantitiy" = "quantitiy" + 1 ',
'                         where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'                         update "ph_medcine" set "QUANTITY" ="QUANTITY" -1 where "medcine_id" = :P3_MEDICINE_ID ; -- for decrese one  from the stock',
'                    else ',
'                        insert into "ph_orders_medcine" ("order_id","medcine_id","quantitiy") ',
'                                                    values (:P3_ORDER_ID, :P3_MEDICINE_ID,1);',
'                        update "ph_medcine" set "QUANTITY" ="QUANTITY" -1 where "medcine_id" = :P3_MEDICINE_ID ;   -- for decrese one  from the stock',
'                    end if; ',
'            -- else ',
'            --     htp.p(''hello'');',
'            -- end if;',
'    else ',
'            ',
'          htp.p(''<script>alert(no data );</script>'');',
'',
'',
'    end if ;',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'order_test number :=0;',
'medicine_test number :=0;',
'medicineQuant number :=0;',
'exDate date ; ',
'found boolean :=false ;',
'begin',
'',
'        --get quqntitiy to variable to use it ',
'        select "QUANTITY" into :P3_QUANTITIY from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'       ------------------------------------------------------------------------------------------------------',
'       -----------------------------------------------expird date check ------------------------------------',
'        --get expired Date to variable to use it ',
'',
'       select "expired_date" into :P3_EXPIREDDATE from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'            -- found := expiredate(exDate);',
'            -- if found then ',
'            --     :P3_EXPIREDDATE := ''false'' ; ',
'            -- else ',
'            --     :P3_EXPIREDDATE :=''true'' ;',
'            -- end if ; ',
'',
'          -- select "expired_date" into :P3_EXPIREDDATE from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'        --     if to_date(exDate,''YYYY-MM-DD'') < to_date(sysdate,''YYYY-MM-DD'')  then ',
'        --         :P3_EXPIREDDATE := ''false'';',
'        --     else ',
'        --         :P3_EXPIREDDATE := ''true'';',
'        --     end if ;',
'        --   ----------------  ----------------------------------------------------------------------------------',
'',
'          ',
'        --check if the quantitiy is available or not and if date is vaild or not ',
'        select "QUANTITY" , "expired_date" into medicineQuant , exDate from "ph_medcine" where "medcine_id" = :P3_MEDICINE_ID;',
'    ',
'    if medicineQuant >= 1 and to_date(exDate,''YYYY-MM-DD'') > to_date(sysdate,''YYYY-MM-DD'') then ',
'',
'            /* if make order first time this will be excuted  */',
'            if :P3_ORDER_ID is null  then ',
'                insert into "ph_orders" ("type") values (''s'');',
'                :P3_ORDER_ID := "order_seq".currval ;',
'            end if ;',
'',
'            -- select  "order_id" , "medince_id" into order_test , medicine_test  from "ph_orders_medcine" ',
'            --    where "order_id" = :P3_ORDER_ID and  ',
'',
'            found := checkmedcine(:P3_ORDER_ID , :P3_MEDICINE_ID);',
'            -- if :P3_QUANTITIY >= 1 then ',
'                    if found  then   --  test if the medcine exist in table or add new ',
'                       update "ph_orders_medcine" set "quantitiy" = "quantitiy" + 1 ',
'                         where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'                         update "ph_medcine" set "QUANTITY" ="QUANTITY" -1 where "medcine_id" = :P3_MEDICINE_ID ; -- for decrese one  from the stock',
'                    else ',
'                        insert into "ph_orders_medcine" ("order_id","medcine_id","quantitiy") ',
'                                                    values (:P3_ORDER_ID, :P3_MEDICINE_ID,1);',
'                        update "ph_medcine" set "QUANTITY" ="QUANTITY" -1 where "medcine_id" = :P3_MEDICINE_ID ;   -- for decrese one  from the stock',
'                    end if; ',
'            -- else ',
'            --     htp.p(''hello'');',
'            -- end if;',
'    else ',
'            ',
'          htp.p(''<script>alert(no data );</script>'');',
'',
'',
'    end if ;',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24884871751690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14204252704481933.123456)
,p_translate_from_id=>wwv_flow_imp.id(14204252704481933)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = $v(''P3_QUANTITIY'');',
'',
'if (value < 1)',
'{',
'    alert("no enough medcine in the stock ");',
'}',
'',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = $v(''P3_QUANTITIY'');',
'',
'if (value < 1)',
'{',
'    alert("no enough medcine in the stock ");',
'}',
'',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24885067685690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631290187889620.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631290187889620)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const  exdate = $v(''P3_EXPIREDDATE'');',
'const currentDate = new Date(); ',
'',
'const ex = new Date(exdate); //this is expired date of medecine',
'const current = new Date(currentDate); //this is the current date ',
'if (ex  < current) { ',
'    alert(" this medecine is expired can''t sell it !!  " );',
'}'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const  exdate = $v(''P3_EXPIREDDATE'');',
'const currentDate = new Date(); ',
'',
'const ex = new Date(exdate); //this is expired date of medecine',
'const current = new Date(currentDate); //this is the current date ',
'if (ex  < current) { ',
'    alert(" this medecine is expired can''t sell it !!  " );',
'}'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24885227640690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404238836263330.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404238836263330)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24885410765690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403598433263323.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403598433263323)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24885642363690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404409036263331.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404409036263331)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'found boolean :=false ;',
'quant number := 0 ; ',
'begin',
'',
'    /* if make order first time this will be excuted  */',
'    -- if :P3_ORDER_ID is null  then ',
'    --     insert into "ph_orders" ("type") values (''s'');',
'    --     :P3_ORDER_ID := "order_seq".currval ;',
'    -- end if ;',
'',
'    -- select  "order_id" , "medince_id" into order_test , medicine_test  from "ph_orders_medcine" ',
'    --    where "order_id" = :P3_ORDER_ID and  ',
'',
'     found := checkmedcine(:P3_ORDER_ID , :P3_MEDICINE_ID);',
'     select "quantitiy" into quant from "ph_orders_medcine" where ',
'        "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        if  quant != 1 then',
'             if found then ',
'               update "ph_orders_medcine" set "quantitiy" = "quantitiy" - 1 ',
'                 where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'                 update "ph_medcine" set "QUANTITY" = "QUANTITY" + 1 ',
'                 where  "medcine_id" = :P3_MEDICINE_ID;',
'             end if;',
'        else    ',
'',
'            delete from "ph_orders_medcine" where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'            update "ph_medcine" set "QUANTITY" = "QUANTITY" + 1 ',
'                 where  "medcine_id" = :P3_MEDICINE_ID;',
'        end if ;',
'',
'    exception ',
'    when no_data_found then ',
'    htp.p(''gg'');',
'        ',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'found boolean :=false ;',
'quant number := 0 ; ',
'begin',
'',
'    /* if make order first time this will be excuted  */',
'    -- if :P3_ORDER_ID is null  then ',
'    --     insert into "ph_orders" ("type") values (''s'');',
'    --     :P3_ORDER_ID := "order_seq".currval ;',
'    -- end if ;',
'',
'    -- select  "order_id" , "medince_id" into order_test , medicine_test  from "ph_orders_medcine" ',
'    --    where "order_id" = :P3_ORDER_ID and  ',
'',
'     found := checkmedcine(:P3_ORDER_ID , :P3_MEDICINE_ID);',
'     select "quantitiy" into quant from "ph_orders_medcine" where ',
'        "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        if  quant != 1 then',
'             if found then ',
'               update "ph_orders_medcine" set "quantitiy" = "quantitiy" - 1 ',
'                 where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'                 update "ph_medcine" set "QUANTITY" = "QUANTITY" + 1 ',
'                 where  "medcine_id" = :P3_MEDICINE_ID;',
'             end if;',
'        else    ',
'',
'            delete from "ph_orders_medcine" where "order_id" = :P3_ORDER_ID and "medcine_id" =:P3_MEDICINE_ID;',
'            update "ph_medcine" set "QUANTITY" = "QUANTITY" + 1 ',
'                 where  "medcine_id" = :P3_MEDICINE_ID;',
'        end if ;',
'',
'    exception ',
'    when no_data_found then ',
'    htp.p(''gg'');',
'        ',
'',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24885870953690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404823334263335.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404823334263335)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24886040441690214)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404866572263336.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404866572263336)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'medQuant number(10) := 0 ; ',
'',
'begin',
'        --  to get all quantitiy of the medcine in order;',
'    select "quantitiy" into medQuant from "ph_orders_medcine" where  "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        -- delete order from the order table ',
'    delete from "ph_orders_medcine" where "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        -- add the quantitiy of the medcine in the stock again',
'    update "ph_medcine" set "QUANTITY" = "QUANTITY" + medQuant where  "medcine_id" = :P3_MEDICINE_ID;',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'medQuant number(10) := 0 ; ',
'',
'begin',
'        --  to get all quantitiy of the medcine in order;',
'    select "quantitiy" into medQuant from "ph_orders_medcine" where  "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        -- delete order from the order table ',
'    delete from "ph_orders_medcine" where "order_id" = :P3_ORDER_ID and "medcine_id" = :P3_MEDICINE_ID;',
'        -- add the quantitiy of the medcine in the stock again',
'    update "ph_medcine" set "QUANTITY" = "QUANTITY" + medQuant where  "medcine_id" = :P3_MEDICINE_ID;',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24886257821690214)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601614924020002.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601614924020002)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24886488754690214)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602103738020007.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602103738020007)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'',
'delete from "ph_orders_medcine" where "order_id" =:P4_ORDER_ID and "medcine_id" = :P4_MEDICINE_ID ; ',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'',
'delete from "ph_orders_medcine" where "order_id" =:P4_ORDER_ID and "medcine_id" = :P4_MEDICINE_ID ; ',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24886634366690214)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914990014930303.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914990014930303)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('<h3>\0647\0644 \0627\0646\062A \0645\062A\0627\0643\062F \0627\0646\0643 \062A\0631\064A\062F \0645\0633\062D \0647\0630\0627 \0627\0644\0645\0633\062A\062E\062F\0645 <h3>')
,p_translate_from_text=>'<h3>are you sure you want to delete this user? <h3>'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24886886938690217)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915268009930306.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915268009930306)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24887046425690217)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915162025930305.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915162025930305)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from "ph_user_activity" where upper("user_name") = (select upper(USERNAME) from "ph_users" ',
'    where USER_ID =  :P5_USER_ID);',
'',
'delete from "ph_users" where "USER_ID" = :P5_USER_ID ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from "ph_user_activity" where upper("user_name") = (select upper(USERNAME) from "ph_users" ',
'    where USER_ID =  :P5_USER_ID);',
'',
'delete from "ph_users" where "USER_ID" = :P5_USER_ID ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24887298927690217)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19305091435993599.123456)
,p_translate_from_id=>wwv_flow_imp.id(19305091435993599)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'window.print()'
,p_translate_from_text=>'window.print()'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24887437894690217)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919118559930344.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919118559930344)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0647\0644 \0627\0646\062A \0645\062A\0627\0643\062F \0627\0646\0643 \062A\0631\064A\062F \0645\0633\062D \0647\0630\0647 \0627\0644\0648\062D\062F\0647\061F')
,p_translate_from_text=>'are you sure you want to delete this unit?'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24887674577690217)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919158888930345.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919158888930345)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24887825386690217)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10511994398195297.123456)
,p_translate_from_id=>wwv_flow_imp.id(10511994398195297)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'delete from "ph_unit" where "unit_id" = :P8_UNIT_ID;'
,p_translate_from_text=>'delete from "ph_unit" where "unit_id" = :P8_UNIT_ID;'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24888043491690217)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606188533239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606188533239867)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0647\0644 \0627\0646\062A \0645\062A\0627\0643\062F \0627\0646\0643 \062A\0631\064A\062F \0645\0633\062D \0647\0630\0647 \0627\0644\0648\062D\062F\0647\061F')
,p_translate_from_text=>'are you sure you want to delete this unit?'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24888209987690220)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606661548239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606661548239867)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24888465215690220)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10607180076239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10607180076239867)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'delete from "ph_providers" where "provider_id" = :P10_PROVIDER_ID;'
,p_translate_from_text=>'delete from "ph_providers" where "provider_id" = :P10_PROVIDER_ID;'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24888610486690220)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203607695959717.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203607695959717)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0647\0644 \0627\0646\062A \0645\062A\0627\0643\062F \0627\0646\0643 \062A\0631\064A\062F \0645\0633\062D \0647\0630\0627 \0627\0644\062F\0648\0627\0621 \061F')
,p_translate_from_text=>'are you sure you want to delete this medcine?'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24888832117690220)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203656283959718.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203656283959718)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889085766690220)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204089814959722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204089814959722)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'delete from "ph_medcine" where "medcine_id" = :P12_MEDCINE_ID;'
,p_translate_from_text=>'delete from "ph_medcine" where "medcine_id" = :P12_MEDCINE_ID;'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889267147690220)
,p_page_id=>14
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16506600883569045.123456)
,p_translate_from_id=>wwv_flow_imp.id(16506600883569045)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sTable = $("#doc .t-Region-bodyWrap").html();',
'',
'var style = "<style>";',
'',
'style = style + ".table {width: 100%;font: 8px Calibri;}";',
'',
'style = style + ".table, th, td { border-collapse: collapse;border:1px solid black;";',
'',
'style = style + "padding: 2px 2px;}";',
'',
'style = style + "</style>";',
'',
'var win = window.open('''', '''', ''height=700,width=700''); // SET THE PAGE HEIGHT AND WIDTH',
'',
'win.document.write(''<html><head>'');',
'',
'win.document.write(''<title>Printable Page</title>'');   // FOR PDF HEADER',
'',
'win.document.write(style);          // ADD STYLE',
'',
'win.document.write(''</head>'');',
'',
'win.document.write(''<body>'');',
'',
'win.document.write(sTable);         // PRINT PART OF THE PAGE',
'',
'win.document.write(''</body></html>'');',
'',
'win.document.close();     // CLOSE THE CURRENT WINDOW.',
'',
'win.print();    // PRINT THE INTENDED PART'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var sTable = $("#doc .t-Region-bodyWrap").html();',
'',
'var style = "<style>";',
'',
'style = style + ".table {width: 100%;font: 8px Calibri;}";',
'',
'style = style + ".table, th, td { border-collapse: collapse;border:1px solid black;";',
'',
'style = style + "padding: 2px 2px;}";',
'',
'style = style + "</style>";',
'',
'var win = window.open('''', '''', ''height=700,width=700''); // SET THE PAGE HEIGHT AND WIDTH',
'',
'win.document.write(''<html><head>'');',
'',
'win.document.write(''<title>Printable Page</title>'');   // FOR PDF HEADER',
'',
'win.document.write(style);          // ADD STYLE',
'',
'win.document.write(''</head>'');',
'',
'win.document.write(''<body>'');',
'',
'win.document.write(sTable);         // PRINT PART OF THE PAGE',
'',
'win.document.write(''</body></html>'');',
'',
'win.document.close();     // CLOSE THE CURRENT WINDOW.',
'',
'win.print();    // PRINT THE INTENDED PART'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889401539690220)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308596763993634.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308596763993634)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889658394690220)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308798474993636.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308798474993636)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'delete from PH_NOTIFICATION where NOT_ID = :P17_NOTI_ID ; ',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'delete from PH_NOTIFICATION where NOT_ID = :P17_NOTI_ID ; ',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889776945690221)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309477820993643.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309477820993643)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'delete from PH_NOTIFICATION;',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'delete from PH_NOTIFICATION;',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24889939370690221)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309775706993646.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309775706993646)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'cursor cur is select "medcine_name" , "medcine_id", "barcode_id" , QUANTITY  from "ph_medcine" where QUANTITY < :MINQUANTITI;',
'cursor dat is select "medcine_name" , "medcine_id", "barcode_id" , "expired_date" from "ph_medcine" where  months_between("expired_date" , sysdate ) < :lastmindate ; ',
'found number(20) := 0    ;',
'found2 number(20) :=0 ;',
'begin ',
'    for i in cur ',
'        loop',
'            select count(*)  into found  from PH_NOTIFICATION where  MEDCINE_ID = i."medcine_id" ; ',
'                if found = 0 then',
'                --''the medcine ''||i."medcine_name"||'' available in the stock only ''||i.QUANTITY||''. barcode id is ''||i."barcode_id"||'' '' , ''quantitiy'', i."medcine_id"',
'                    insert into PH_NOTIFICATION (MEDCINE_NAME , BARCODE , MEDCINE_ID , STATUS, INFORMATION) values (i."medcine_name",i."barcode_id",i."medcine_id",''quantity'' , ''this product have minmum quantitiy ''||i.QUANTITY); ',
'                end if ;',
'        end loop;',
'',
'    for f in dat ',
'        loop',
'            select count(*)  into found2  from PH_NOTIFICATION where  MEDCINE_ID = f."medcine_id" ; ',
'                if found2 = 0 then',
'                 --   insert into PH_NOTIFICATION (NOT_TEXT , NOT_RESON , MEDCINE_ID) values (''the medcine ''||f."medcine_name"||'' is goning to  expired , exired date is  ''||f."expired_date"||''. barcode id is ''||f."barcode_id"||'' '' , ''expired'', f."med'
||'cine_id");',
'                      insert into PH_NOTIFICATION (MEDCINE_NAME , BARCODE , MEDCINE_ID , STATUS, INFORMATION) values (f."medcine_name",f."barcode_id",f."medcine_id",''date'' , ''expired date of this medcine is  ''||f."expired_date"); ',
'',
'                end if ;',
'        end loop;',
'end ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'cursor cur is select "medcine_name" , "medcine_id", "barcode_id" , QUANTITY  from "ph_medcine" where QUANTITY < :MINQUANTITI;',
'cursor dat is select "medcine_name" , "medcine_id", "barcode_id" , "expired_date" from "ph_medcine" where  months_between("expired_date" , sysdate ) < :lastmindate ; ',
'found number(20) := 0    ;',
'found2 number(20) :=0 ;',
'begin ',
'    for i in cur ',
'        loop',
'            select count(*)  into found  from PH_NOTIFICATION where  MEDCINE_ID = i."medcine_id" ; ',
'                if found = 0 then',
'                --''the medcine ''||i."medcine_name"||'' available in the stock only ''||i.QUANTITY||''. barcode id is ''||i."barcode_id"||'' '' , ''quantitiy'', i."medcine_id"',
'                    insert into PH_NOTIFICATION (MEDCINE_NAME , BARCODE , MEDCINE_ID , STATUS, INFORMATION) values (i."medcine_name",i."barcode_id",i."medcine_id",''quantity'' , ''this product have minmum quantitiy ''||i.QUANTITY); ',
'                end if ;',
'        end loop;',
'',
'    for f in dat ',
'        loop',
'            select count(*)  into found2  from PH_NOTIFICATION where  MEDCINE_ID = f."medcine_id" ; ',
'                if found2 = 0 then',
'                 --   insert into PH_NOTIFICATION (NOT_TEXT , NOT_RESON , MEDCINE_ID) values (''the medcine ''||f."medcine_name"||'' is goning to  expired , exired date is  ''||f."expired_date"||''. barcode id is ''||f."barcode_id"||'' '' , ''expired'', f."med'
||'cine_id");',
'                      insert into PH_NOTIFICATION (MEDCINE_NAME , BARCODE , MEDCINE_ID , STATUS, INFORMATION) values (f."medcine_name",f."barcode_id",f."medcine_id",''date'' , ''expired date of this medcine is  ''||f."expired_date"); ',
'',
'                end if ;',
'        end loop;',
'end ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24890190419690221)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303364928261599.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303364928261599)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'select sum("money") into :P19_TOTAL from "ph_return_medcine" ',
'',
'    where ',
'        (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'        and ',
'        (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null );',
'',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'select sum("money") into :P19_TOTAL from "ph_return_medcine" ',
'',
'    where ',
'        (:P19_YEAR = extract(year from "return_date") or :P19_YEAR is null)',
'        and ',
'        (:P19_MONTH = extract(month from "return_date") or :P19_MONTH is null );',
'',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24890319907690223)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632914491889636.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632914491889636)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
' begin',
'',
'select sum("money") into :P20_TOTAL  from "ph_income" where ',
'        :P20_MONTH = 0 and extract (year from "income_date") = :P20_YEAR ',
'        or',
'        :P20_YEAR = 0 and extract  (month from "income_date") = :P20_MONTH',
'        or',
'        extract (year from "income_date") = :P20_YEAR and extract(month from "income_date") = :P20_MONTH',
'        or',
'        :P20_MONTH = 0 and :P20_YEAR = 0 ;',
'',
'end ; '))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
' begin',
'',
'select sum("money") into :P20_TOTAL  from "ph_income" where ',
'        :P20_MONTH = 0 and extract (year from "income_date") = :P20_YEAR ',
'        or',
'        :P20_YEAR = 0 and extract  (month from "income_date") = :P20_MONTH',
'        or',
'        extract (year from "income_date") = :P20_YEAR and extract(month from "income_date") = :P20_MONTH',
'        or',
'        :P20_MONTH = 0 and :P20_YEAR = 0 ;',
'',
'end ; '))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24890597644690223)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709120886291097.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709120886291097)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'select sum("money") into :P21_TOTAL from "ph_expenses" where ',
'    :P21_MONTH = 0 and extract(year from expenses_date) = :P21_YEAR',
'    or ',
'    :P21_YEAR = 0 and extract(month from expenses_date) = :P21_MONTH ',
'    or ',
'    extract(month from expenses_date) = :P21_MONTH and extract(year from expenses_date) = :P21_YEAR',
'    or ',
'    :P21_MONTH = 0 and :P21_YEAR = 0 ;  ',
'',
'',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'',
'select sum("money") into :P21_TOTAL from "ph_expenses" where ',
'    :P21_MONTH = 0 and extract(year from expenses_date) = :P21_YEAR',
'    or ',
'    :P21_YEAR = 0 and extract(month from expenses_date) = :P21_MONTH ',
'    or ',
'    extract(month from expenses_date) = :P21_MONTH and extract(year from expenses_date) = :P21_YEAR',
'    or ',
'    :P21_MONTH = 0 and :P21_YEAR = 0 ;  ',
'',
'',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24890703700690225)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31711936632244101.123456)
,p_translate_from_id=>wwv_flow_imp.id(31711936632244101)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24890958830690225)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712291511244104.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712291511244104)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'',
'Sell_order number(10) := 0 ; ',
'SellQuantity number(10) := 0;',
'sellDate date ;',
'sellPrice number(10) := 0 ; ',
'',
'begin',
'----------------------------------------------get sell price for income table ----------------',
'select "sell_price" into sellPrice from "ph_medcine" where "medcine_id" = :P23_MEDCINE_ID ; ',
'-------------------------------------------------------------------------------',
'select "sell_order_no" , "quantity" , "sell_date"  into sell_order , sellQuantity,sellDate  from "ph_return_medcine"',
'    where  "return_order_id" = :P23_ORDER_ID; ',
'',
'----------------------------end query----------------------------------------------------------',
'--////////////////////////////////////////////////////////////////////////////////////////////',
'------------------------ return every medcine to sell order ----------------------------------',
'   ',
'            update "ph_orders_medcine" set "quantitiy" = "quantitiy" + sellQuantity',
'                where "medcine_id" = :P23_MEDCINE_ID and "order_id" = sell_order; ',
'                --------------delete the medicine in return order table  ------------------------------------------',
'     delete from "ph_orders_medcine" where "medcine_id" = :P23_MEDCINE_ID and "order_id" = :P23_ORDER_ID ; ',
'            --delete the quantity from the stock--',
'            update "ph_medcine" set "QUANTITY" = "QUANTITY" - sellQuantity where "medcine_id" = :P23_MEDCINE_ID;',
'        ',
'    --------------------- Delete medcine from Ph_return_medcine ---------------------------',
'        delete from "ph_return_medcine" where "medcine_id" = :P23_MEDCINE_ID and "return_order_id" = :P23_ORDER_ID;    ',
'    ------------- increase the money in income table if delete retured order -----------------------',
'',
'    update "ph_income" set "money" = "money" + (sellQuantity *sellPrice )  where  "income_date" = sellDate;',
'end;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'',
'Sell_order number(10) := 0 ; ',
'SellQuantity number(10) := 0;',
'sellDate date ;',
'sellPrice number(10) := 0 ; ',
'',
'begin',
'----------------------------------------------get sell price for income table ----------------',
'select "sell_price" into sellPrice from "ph_medcine" where "medcine_id" = :P23_MEDCINE_ID ; ',
'-------------------------------------------------------------------------------',
'select "sell_order_no" , "quantity" , "sell_date"  into sell_order , sellQuantity,sellDate  from "ph_return_medcine"',
'    where  "return_order_id" = :P23_ORDER_ID; ',
'',
'----------------------------end query----------------------------------------------------------',
'--////////////////////////////////////////////////////////////////////////////////////////////',
'------------------------ return every medcine to sell order ----------------------------------',
'   ',
'            update "ph_orders_medcine" set "quantitiy" = "quantitiy" + sellQuantity',
'                where "medcine_id" = :P23_MEDCINE_ID and "order_id" = sell_order; ',
'                --------------delete the medicine in return order table  ------------------------------------------',
'     delete from "ph_orders_medcine" where "medcine_id" = :P23_MEDCINE_ID and "order_id" = :P23_ORDER_ID ; ',
'            --delete the quantity from the stock--',
'            update "ph_medcine" set "QUANTITY" = "QUANTITY" - sellQuantity where "medcine_id" = :P23_MEDCINE_ID;',
'        ',
'    --------------------- Delete medcine from Ph_return_medcine ---------------------------',
'        delete from "ph_return_medcine" where "medcine_id" = :P23_MEDCINE_ID and "return_order_id" = :P23_ORDER_ID;    ',
'    ------------- increase the money in income table if delete retured order -----------------------',
'',
'    update "ph_income" set "money" = "money" + (sellQuantity *sellPrice )  where  "income_date" = sellDate;',
'end;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24891143380690225)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712304502291129.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712304502291129)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    -- select sum(o."quantitiy") into :P23_QUANTITY from "ph_orders_medcine" o , "ph_invoice" v ',
'    --     where o."medcine_id" = :P23_MEDCINE_SEARCH and v."type" = ''s'' and o."order_id" = v."order_id" ; ',
'',
'select sum("quantitiy") into :P28_ALLOW_RETURNED_QUANTITY from "ph_orders_medcine" o , "ph_invoice" v  ',
'where',
' o."medcine_id" = :P28_MEDCINE_ID  and o."order_id" = v."order_id" and v."type" = ''s'' and months_between(  sysdate,v."invoice_date" ) < 0.25 and o."quantitiy" > 0   -- you can return medcine for last week only ',
'  ;',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    -- select sum(o."quantitiy") into :P23_QUANTITY from "ph_orders_medcine" o , "ph_invoice" v ',
'    --     where o."medcine_id" = :P23_MEDCINE_SEARCH and v."type" = ''s'' and o."order_id" = v."order_id" ; ',
'',
'select sum("quantitiy") into :P28_ALLOW_RETURNED_QUANTITY from "ph_orders_medcine" o , "ph_invoice" v  ',
'where',
' o."medcine_id" = :P28_MEDCINE_ID  and o."order_id" = v."order_id" and v."type" = ''s'' and months_between(  sysdate,v."invoice_date" ) < 0.25 and o."quantitiy" > 0   -- you can return medcine for last week only ',
'  ;',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24891399581690225)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502691086891526.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502691086891526)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'delete from ph_complain where complain_id = :P34_COMPLAIN_ID ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'delete from ph_complain where complain_id = :P34_COMPLAIN_ID ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24891518875690225)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502208520891522.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502208520891522)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0647\0644 \0627\0646\062A \0645\062A\0627\0643\062F \0627\0646\0643 \062A\0631\064A\062F \0645\0633\062D \0647\0630\0647 \0627\0644\0634\0643\0648\064A')
,p_translate_from_text=>'are you sure you want delete this complain ?'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24891745521690225)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502448253891524.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502448253891524)
,p_translate_column_id=>288
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'JAVASCRIPT_EXPRESSION'
,p_translate_from_text=>'JAVASCRIPT_EXPRESSION'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24891932848690234)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403164741263319.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403164741263319)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
,p_translate_from_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24892159345690234)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404409036263331.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404409036263331)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
,p_translate_from_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24892387792690234)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404866572263336.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404866572263336)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
,p_translate_from_text=>'P3_ORDER_ID,P3_MEDICINE_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24892521378690234)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602103738020007.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602103738020007)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P4_MEDICINE_ID,P4_ORDER_ID'
,p_translate_from_text=>'P4_MEDICINE_ID,P4_ORDER_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24892759336690234)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915162025930305.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915162025930305)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P5_USER_ID'
,p_translate_from_text=>'P5_USER_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24892980842690234)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10511994398195297.123456)
,p_translate_from_id=>wwv_flow_imp.id(10511994398195297)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P8_UNIT_ID'
,p_translate_from_text=>'P8_UNIT_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24893138932690234)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10607180076239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10607180076239867)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P10_PROVIDER_ID'
,p_translate_from_text=>'P10_PROVIDER_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24893324299690235)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204089814959722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204089814959722)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P12_MEDCINE_ID'
,p_translate_from_text=>'P12_MEDCINE_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24893521338690235)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308798474993636.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308798474993636)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P17_NOTI_ID'
,p_translate_from_text=>'P17_NOTI_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24893723112690235)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303364928261599.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303364928261599)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P19_YEAR,P19_MONTH'
,p_translate_from_text=>'P19_YEAR,P19_MONTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24893906626690235)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632914491889636.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632914491889636)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P20_MONTH,P20_YEAR'
,p_translate_from_text=>'P20_MONTH,P20_YEAR'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24894195480690235)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709120886291097.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709120886291097)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P21_YEAR,P21_MONTH'
,p_translate_from_text=>'P21_YEAR,P21_MONTH'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24894318209690239)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712291511244104.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712291511244104)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P23_MEDCINE_ID,P23_ORDER_NO'
,p_translate_from_text=>'P23_MEDCINE_ID,P23_ORDER_NO'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24894528570690239)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712304502291129.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712304502291129)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P28_MEDCINE_ID'
,p_translate_from_text=>'P28_MEDCINE_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24894742409690239)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502691086891526.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502691086891526)
,p_translate_column_id=>289
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P34_COMPLAIN_ID'
,p_translate_from_text=>'P34_COMPLAIN_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24894948710690243)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403164741263319.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403164741263319)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P3_ORDER_ID,P3_EXPIREDDATE,P3_QUANTITIY'
,p_translate_from_text=>'P3_ORDER_ID,P3_EXPIREDDATE,P3_QUANTITIY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24895148783690243)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404409036263331.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404409036263331)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P3_ORDER_ID'
,p_translate_from_text=>'P3_ORDER_ID'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24895337471690243)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914990014930303.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914990014930303)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'danger'
,p_translate_from_text=>'danger'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24895528491690243)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919118559930344.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919118559930344)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'warning'
,p_translate_from_text=>'warning'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24895777071690243)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606188533239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606188533239867)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'warning'
,p_translate_from_text=>'warning'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24895922229690243)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203607695959717.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203607695959717)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'danger'
,p_translate_from_text=>'danger'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24896128045690243)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303364928261599.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303364928261599)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P19_TOTAL'
,p_translate_from_text=>'P19_TOTAL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24896364646690245)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632914491889636.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632914491889636)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P20_TOTAL'
,p_translate_from_text=>'P20_TOTAL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24896521390690246)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709120886291097.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709120886291097)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P21_TOTAL'
,p_translate_from_text=>'P21_TOTAL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24896791181690248)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712304502291129.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712304502291129)
,p_translate_column_id=>290
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'P28_ALLOW_RETURNED_QUANTITY'
,p_translate_from_text=>'P28_ALLOW_RETURNED_QUANTITY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24896904788690251)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403164741263319.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403164741263319)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24897130560690253)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404409036263331.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404409036263331)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24897382852690253)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914990014930303.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914990014930303)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'fa-exclamation'
,p_translate_from_text=>'fa-exclamation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24897530769690253)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919118559930344.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919118559930344)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'fa-exclamation'
,p_translate_from_text=>'fa-exclamation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24897717881690256)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606188533239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606188533239867)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'fa-exclamation'
,p_translate_from_text=>'fa-exclamation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24897935303690256)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203607695959717.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203607695959717)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'fa-exclamation'
,p_translate_from_text=>'fa-exclamation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24898150813690257)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303364928261599.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303364928261599)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24898352873690257)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632914491889636.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632914491889636)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24898574889690257)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709120886291097.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709120886291097)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24898787259690257)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712304502291129.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712304502291129)
,p_translate_column_id=>291
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24898904860690265)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403164741263319.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403164741263319)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24899182674690265)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404238836263330.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404238836263330)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24899349939690265)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403598433263323.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403598433263323)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24899556402690265)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404409036263331.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404409036263331)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24899775873690267)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404823334263335.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404823334263335)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24899923812690267)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404866572263336.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404866572263336)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24900186067690268)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601614924020002.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601614924020002)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.triggeringElement.title',
''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.triggeringElement.title',
''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24900313129690268)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25602103738020007.123456)
,p_translate_from_id=>wwv_flow_imp.id(25602103738020007)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24900539989690268)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6914990014930303.123456)
,p_translate_from_id=>wwv_flow_imp.id(6914990014930303)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'popupMessages'
,p_translate_from_text=>'popupMessages'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24900784281690268)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915268009930306.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915268009930306)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24900967603690268)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915162025930305.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915162025930305)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24901174646690268)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919118559930344.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919118559930344)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'popupMessages'
,p_translate_from_text=>'popupMessages'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24901344979690270)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919158888930345.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919158888930345)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24901574936690270)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10511994398195297.123456)
,p_translate_from_id=>wwv_flow_imp.id(10511994398195297)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24901781538690270)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606188533239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606188533239867)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'popupMessages'
,p_translate_from_text=>'popupMessages'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24901974926690270)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606661548239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606661548239867)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24902148451690270)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10607180076239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10607180076239867)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24902322124690270)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203607695959717.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203607695959717)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'popupMessages'
,p_translate_from_text=>'popupMessages'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24902571685690270)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203656283959718.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203656283959718)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24902790468690270)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204089814959722.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204089814959722)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24902905783690271)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308596763993634.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308596763993634)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24903155379690271)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308798474993636.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308798474993636)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24903378221690271)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309477820993643.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309477820993643)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24903597372690271)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19309775706993646.123456)
,p_translate_from_id=>wwv_flow_imp.id(19309775706993646)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24903718999690271)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303364928261599.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303364928261599)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24903959215690273)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20632914491889636.123456)
,p_translate_from_id=>wwv_flow_imp.id(20632914491889636)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24904198258690273)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709120886291097.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709120886291097)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24904375544690273)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31711936632244101.123456)
,p_translate_from_id=>wwv_flow_imp.id(31711936632244101)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24904571276690275)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31712291511244104.123456)
,p_translate_from_id=>wwv_flow_imp.id(31712291511244104)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24904755073690275)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28712304502291129.123456)
,p_translate_from_id=>wwv_flow_imp.id(28712304502291129)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24904915324690275)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502691086891526.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502691086891526)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'PLSQL'
,p_translate_from_text=>'PLSQL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24905166764690275)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502448253891524.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502448253891524)
,p_translate_column_id=>292
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'this.triggeringElement.title'
,p_translate_from_text=>'this.triggeringElement.title'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24905350390690295)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404238836263330.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404238836263330)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24905587425690295)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12403598433263323.123456)
,p_translate_from_id=>wwv_flow_imp.id(12403598433263323)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24905749139690295)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12404823334263335.123456)
,p_translate_from_id=>wwv_flow_imp.id(12404823334263335)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24905942220690295)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25601614924020002.123456)
,p_translate_from_id=>wwv_flow_imp.id(25601614924020002)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24906120389690295)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6915268009930306.123456)
,p_translate_from_id=>wwv_flow_imp.id(6915268009930306)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24906355883690296)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6919158888930345.123456)
,p_translate_from_id=>wwv_flow_imp.id(6919158888930345)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24906506511690296)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10606661548239867.123456)
,p_translate_from_id=>wwv_flow_imp.id(10606661548239867)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24906753829690296)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11203656283959718.123456)
,p_translate_from_id=>wwv_flow_imp.id(11203656283959718)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24906950298690298)
,p_page_id=>17
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19308596763993634.123456)
,p_translate_from_id=>wwv_flow_imp.id(19308596763993634)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24907112272690298)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31711936632244101.123456)
,p_translate_from_id=>wwv_flow_imp.id(31711936632244101)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24907384046690298)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502448253891524.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502448253891524)
,p_translate_column_id=>296
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24907501538690314)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6703896849922296.123456)
,p_translate_from_id=>wwv_flow_imp.id(6703896849922296)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'FULL'
,p_translate_from_text=>'FULL'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24907798837690314)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702378831922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702378831922292)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'MONTH-PICKER:YEAR-PICKER'
,p_translate_from_text=>'MONTH-PICKER:YEAR-PICKER'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24907982249690315)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702085419922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702085419922292)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'RELAX_HOUSE_NUMBER'
,p_translate_from_text=>'RELAX_HOUSE_NUMBER'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24908118298690317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6703612314922296.123456)
,p_translate_from_id=>wwv_flow_imp.id(6703612314922296)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24908308015690317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702634526922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702634526922292)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24908546352690317)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704185857922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704185857922297)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'fa-star'
,p_translate_from_text=>'fa-star'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24908749581690320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704441390922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704441390922297)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'1'
,p_translate_from_text=>'1'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24908972663690320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6701923784922288.123456)
,p_translate_from_id=>wwv_flow_imp.id(6701923784922288)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24909129489690320)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702967236922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702967236922292)
,p_translate_column_id=>298
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'IG'
,p_translate_from_text=>'IG'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24909359006690325)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6703896849922296.123456)
,p_translate_from_id=>wwv_flow_imp.id(6703896849922296)
,p_translate_column_id=>299
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP'
,p_translate_from_text=>'POPUP'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24909485905690325)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702378831922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702378831922292)
,p_translate_column_id=>299
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'VISIBLE'
,p_translate_from_text=>'VISIBLE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24909647522690325)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702085419922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702085419922292)
,p_translate_column_id=>299
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24909808402690326)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702634526922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702634526922292)
,p_translate_column_id=>299
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24910024039690326)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704441390922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704441390922297)
,p_translate_column_id=>299
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0646\0639\0645')
,p_translate_from_text=>'yes'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24910293839690331)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702378831922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702378831922292)
,p_translate_column_id=>300
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'15'
,p_translate_from_text=>'15'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24910418797690331)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702085419922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702085419922292)
,p_translate_column_id=>300
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'POPUP:ITEM'
,p_translate_from_text=>'POPUP:ITEM'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24910672252690331)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704441390922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704441390922297)
,p_translate_column_id=>300
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'0'
,p_translate_from_text=>'0'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24910827715690335)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702378831922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702378831922292)
,p_translate_column_id=>301
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'FOCUS'
,p_translate_from_text=>'FOCUS'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24911036782690335)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702085419922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702085419922292)
,p_translate_column_id=>301
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'default'
,p_translate_from_text=>'default'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24911222178690335)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704185857922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704185857922297)
,p_translate_column_id=>301
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'#VALUE#'
,p_translate_from_text=>'#VALUE#'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24911463319690335)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704441390922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704441390922297)
,p_translate_column_id=>301
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0644\0627')
,p_translate_from_text=>'no'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24911691909690342)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6704441390922297.123456)
,p_translate_from_id=>wwv_flow_imp.id(6704441390922297)
,p_translate_column_id=>302
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'SWITCH_CB'
,p_translate_from_text=>'SWITCH_CB'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24911895653690346)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6702085419922292.123456)
,p_translate_from_id=>wwv_flow_imp.id(6702085419922292)
,p_translate_column_id=>303
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'LIST'
,p_translate_from_text=>'LIST'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24912011611690365)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6908711381923486.123456)
,p_translate_from_id=>wwv_flow_imp.id(6908711381923486)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24912299937690365)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'date'
,p_translate_from_text=>'date'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24912460113690365)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917013588930323.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917013588930323)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24912665388690365)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12400948634263297.123456)
,p_translate_from_id=>wwv_flow_imp.id(12400948634263297)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24912836563690368)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7306020471037514.123456)
,p_translate_from_id=>wwv_flow_imp.id(7306020471037514)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24913029274690368)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202130068481911.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202130068481911)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24913225219690368)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10302635953912455.123456)
,p_translate_from_id=>wwv_flow_imp.id(10302635953912455)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24913407034690370)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10705226468257042.123456)
,p_translate_from_id=>wwv_flow_imp.id(10705226468257042)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24913682643690370)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11606329427472671.123456)
,p_translate_from_id=>wwv_flow_imp.id(11606329427472671)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24913826693690370)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504678749569026.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504678749569026)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24914025285690370)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708946916626619.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708946916626619)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24914271923690370)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105452736172536.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105452736172536)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24914481623690373)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631351713889621.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631351713889621)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24914606087690373)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605364868020040.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605364868020040)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24914868752690373)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709390409291100.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709390409291100)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24915074331690373)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715324531244134.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715324531244134)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24915247194690373)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103030968172511.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103030968172511)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24915428428690375)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30903563778085172.123456)
,p_translate_from_id=>wwv_flow_imp.id(30903563778085172)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24915695469690375)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501891578891518.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501891578891518)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24915814689690376)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24916052088690376)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904278716923381.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904278716923381)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24916217529690376)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6909825038923558.123456)
,p_translate_from_id=>wwv_flow_imp.id(6909825038923558)
,p_translate_column_id=>308
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24916498162690381)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6908711381923486.123456)
,p_translate_from_id=>wwv_flow_imp.id(6908711381923486)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24916655195690381)
,p_page_id=>2
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6917013588930323.123456)
,p_translate_from_id=>wwv_flow_imp.id(6917013588930323)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24916889806690382)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12400948634263297.123456)
,p_translate_from_id=>wwv_flow_imp.id(12400948634263297)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24917024641690382)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7306020471037514.123456)
,p_translate_from_id=>wwv_flow_imp.id(7306020471037514)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24917245892690382)
,p_page_id=>7
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(14202130068481911.123456)
,p_translate_from_id=>wwv_flow_imp.id(14202130068481911)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24917460975690384)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10302635953912455.123456)
,p_translate_from_id=>wwv_flow_imp.id(10302635953912455)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24917684470690384)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10705226468257042.123456)
,p_translate_from_id=>wwv_flow_imp.id(10705226468257042)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24917846748690384)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11606329427472671.123456)
,p_translate_from_id=>wwv_flow_imp.id(11606329427472671)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24918018909690384)
,p_page_id=>15
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(16504678749569026.123456)
,p_translate_from_id=>wwv_flow_imp.id(16504678749569026)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24918247322690387)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708946916626619.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708946916626619)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24918473963690390)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34105452736172536.123456)
,p_translate_from_id=>wwv_flow_imp.id(34105452736172536)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24918660879690390)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20631351713889621.123456)
,p_translate_from_id=>wwv_flow_imp.id(20631351713889621)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24918851277690390)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(25605364868020040.123456)
,p_translate_from_id=>wwv_flow_imp.id(25605364868020040)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24919007115690390)
,p_page_id=>23
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(28709390409291100.123456)
,p_translate_from_id=>wwv_flow_imp.id(28709390409291100)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24919254794690390)
,p_page_id=>25
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(31715324531244134.123456)
,p_translate_from_id=>wwv_flow_imp.id(31715324531244134)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24919456177690390)
,p_page_id=>27
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(34103030968172511.123456)
,p_translate_from_id=>wwv_flow_imp.id(34103030968172511)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24919608123690390)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30903563778085172.123456)
,p_translate_from_id=>wwv_flow_imp.id(30903563778085172)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24919808743690390)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501891578891518.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501891578891518)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24920047926690392)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904278716923381.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904278716923381)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'TEXT'
,p_translate_from_text=>'TEXT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24920257063690392)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6909825038923558.123456)
,p_translate_from_id=>wwv_flow_imp.id(6909825038923558)
,p_translate_column_id=>309
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'HTML'
,p_translate_from_text=>'HTML'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24920486412690396)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6908711381923486.123456)
,p_translate_from_id=>wwv_flow_imp.id(6908711381923486)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24920666721690398)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'name'
,p_translate_from_text=>'name'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24920879154690398)
,p_page_id=>6
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(7306020471037514.123456)
,p_translate_from_id=>wwv_flow_imp.id(7306020471037514)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24921013155690400)
,p_page_id=>9
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10302635953912455.123456)
,p_translate_from_id=>wwv_flow_imp.id(10302635953912455)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24921221006690400)
,p_page_id=>11
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10705226468257042.123456)
,p_translate_from_id=>wwv_flow_imp.id(10705226468257042)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24921483975690400)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11606329427472671.123456)
,p_translate_from_id=>wwv_flow_imp.id(11606329427472671)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24921654811690400)
,p_page_id=>28
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(30903563778085172.123456)
,p_translate_from_id=>wwv_flow_imp.id(30903563778085172)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24921821475690403)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904278716923381.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904278716923381)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922033192690403)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6909825038923558.123456)
,p_translate_from_id=>wwv_flow_imp.id(6909825038923558)
,p_translate_column_id=>310
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922289538690415)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>313
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922475196690428)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>316
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'list:navigation'
,p_translate_from_text=>'list:navigation'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922544467690428)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>316
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922740998690435)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8504065820065238.123456)
,p_translate_from_id=>wwv_flow_imp.id(8504065820065238)
,p_translate_column_id=>318
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24922972113690435)
,p_page_id=>13
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11603906786472660.123456)
,p_translate_from_id=>wwv_flow_imp.id(11603906786472660)
,p_translate_column_id=>318
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24923157465690435)
,p_page_id=>16
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19307025558993618.123456)
,p_translate_from_id=>wwv_flow_imp.id(19307025558993618)
,p_translate_column_id=>318
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24923363489690435)
,p_page_id=>18
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24709449822626624.123456)
,p_translate_from_id=>wwv_flow_imp.id(24709449822626624)
,p_translate_column_id=>318
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24923524914690526)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>339
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'10000'
,p_translate_from_text=>'10000'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24923633687690531)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>340
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24923889628690532)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>340
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24924047258690542)
,p_page_id=>34
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13502780942891527.123456)
,p_translate_from_id=>wwv_flow_imp.id(13502780942891527)
,p_translate_column_id=>342
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'10'
,p_translate_from_text=>'10'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24924220027690546)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22300473024741143.123456)
,p_translate_from_id=>wwv_flow_imp.id(22300473024741143)
,p_translate_column_id=>343
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%C%'''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%C%'''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24924494329690546)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22900277267522539.123456)
,p_translate_from_id=>wwv_flow_imp.id(22900277267522539)
,p_translate_column_id=>343
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where',
'upper(USERNAME) = :APP_USER',
'and  ',
'(ROLE like ''%C%'' or ROLE like ''%DE%'')'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where',
'upper(USERNAME) = :APP_USER',
'and  ',
'(ROLE like ''%C%'' or ROLE like ''%DE%'')'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24924688304690546)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22300644307745342.123456)
,p_translate_from_id=>wwv_flow_imp.id(22300644307745342)
,p_translate_column_id=>343
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%DE%'''))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%DE%'''))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24924860286690546)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(22101237470508314.123456)
,p_translate_from_id=>wwv_flow_imp.id(22101237470508314)
,p_translate_column_id=>343
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users" where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%A%'' ;'))
,p_translate_from_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users" where ',
'upper(USERNAME) = :APP_USER ',
'and ',
'ROLE like ''%A%'' ;'))
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925086483690634)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(9401887560542694.123456)
,p_translate_from_id=>wwv_flow_imp.id(9401887560542694)
,p_translate_column_id=>363
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'AUTHETICATE'
,p_translate_from_text=>'AUTHETICATE'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925156814690639)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(9401887560542694.123456)
,p_translate_from_id=>wwv_flow_imp.id(9401887560542694)
,p_translate_column_id=>364
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'USER_ACTIVITY_LOGOUT'
,p_translate_from_text=>'USER_ACTIVITY_LOGOUT'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925369434690645)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(9401887560542694.123456)
,p_translate_from_id=>wwv_flow_imp.id(9401887560542694)
,p_translate_column_id=>365
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'N'
,p_translate_from_text=>'N'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925581329690695)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20608956163481456.123456)
,p_translate_from_id=>wwv_flow_imp.id(20608956163481456)
,p_translate_column_id=>376
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'&NOTIFYCOUNTER.'
,p_translate_from_text=>'&NOTIFYCOUNTER.'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925718680690700)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20608956163481456.123456)
,p_translate_from_id=>wwv_flow_imp.id(20608956163481456)
,p_translate_column_id=>377
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'u-color-B'
,p_translate_from_text=>'u-color-B'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24925936154690700)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6911314144923571.123456)
,p_translate_from_id=>wwv_flow_imp.id(6911314144923571)
,p_translate_column_id=>377
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'icon-only'
,p_translate_from_text=>'icon-only'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24926107636690701)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6911781072923575.123456)
,p_translate_from_id=>wwv_flow_imp.id(6911781072923575)
,p_translate_column_id=>377
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'icon-only'
,p_translate_from_text=>'icon-only'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24926364856690701)
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6912739104923580.123456)
,p_translate_from_id=>wwv_flow_imp.id(6912739104923580)
,p_translate_column_id=>377
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'has-username'
,p_translate_from_text=>'has-username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24926580675690779)
,p_page_id=>3
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(12401152428263299.123456)
,p_translate_from_id=>wwv_flow_imp.id(12401152428263299)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24926669280690782)
,p_page_id=>4
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(24708047150626610.123456)
,p_translate_from_id=>wwv_flow_imp.id(24708047150626610)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24926880518690782)
,p_page_id=>5
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6918295606930336.123456)
,p_translate_from_id=>wwv_flow_imp.id(6918295606930336)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24927033124690782)
,p_page_id=>8
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10500558760022664.123456)
,p_translate_from_id=>wwv_flow_imp.id(10500558760022664)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24927254097690782)
,p_page_id=>10
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(10603076765239853.123456)
,p_translate_from_id=>wwv_flow_imp.id(10603076765239853)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24927479552690782)
,p_page_id=>12
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(11204244382959724.123456)
,p_translate_from_id=>wwv_flow_imp.id(11204244382959724)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0628\062D\062B')
,p_translate_from_text=>'search'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24927677086690782)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6904759996923411.123456)
,p_translate_from_id=>wwv_flow_imp.id(6904759996923411)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0633\0645 \0627\0644\0645\0633\062A\062E\062F\0645')
,p_translate_from_text=>'Username'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24927831802690782)
,p_page_id=>9999
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6905147704923424.123456)
,p_translate_from_id=>wwv_flow_imp.id(6905147704923424)
,p_translate_column_id=>396
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0631\0642\0645 \0627\0644\0633\0631\064A ')
,p_translate_from_text=>'Password'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928077609690826)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>406
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928147651690837)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>408
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928379283690853)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>410
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'10'
,p_translate_from_text=>'10'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928584656690859)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8501166958065209.123456)
,p_translate_from_id=>wwv_flow_imp.id(8501166958065209)
,p_translate_column_id=>411
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'Y'
,p_translate_from_text=>'Y'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928715138691075)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8502557150065223.123456)
,p_translate_from_id=>wwv_flow_imp.id(8502557150065223)
,p_translate_column_id=>462
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'Users'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24928836817691075)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501238765891512.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501238765891512)
,p_translate_column_id=>462
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0633\0646\0648\0627\062A & \0634\0647\0648\0631')
,p_translate_from_text=>'Months & Year'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24929012433691101)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8502670585065224.123456)
,p_translate_from_id=>wwv_flow_imp.id(8502670585065224)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0646\0634\0637\0647')
,p_translate_from_text=>'activities'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24929245209691103)
,p_page_id=>1
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(8500781676065205.123456)
,p_translate_from_id=>wwv_flow_imp.id(8500781676065205)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062E\0632\0648\0646 \0645\0646\062E\0641\0636')
,p_translate_from_text=>'low stock'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24929491689691106)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(6502856753416001.123456)
,p_translate_from_id=>wwv_flow_imp.id(6502856753416001)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\064A\0648\0645')
,p_translate_from_text=>'day'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24929697836691106)
,p_page_id=>19
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(4402564733185419.123456)
,p_translate_from_id=>wwv_flow_imp.id(4402564733185419)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0634\0647\0631')
,p_translate_from_text=>'month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24929821745691106)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38307731104261642.123456)
,p_translate_from_id=>wwv_flow_imp.id(38307731104261642)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0648\0627\0631\062F\0627\062A \0628 \0627\0644\064A\0648\0645 ')
,p_translate_from_text=>'income chart  with day '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24930033211691106)
,p_page_id=>20
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40702990926108800.123456)
,p_translate_from_id=>wwv_flow_imp.id(40702990926108800)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0648\0627\0631\062F\0627\062A \0628 \0627\0644\0634\0647\0631')
,p_translate_from_text=>'income chart  with month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24930213908691106)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40704112964108811.123456)
,p_translate_from_id=>wwv_flow_imp.id(40704112964108811)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24930470696691106)
,p_page_id=>21
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(40704828823108818.123456)
,p_translate_from_id=>wwv_flow_imp.id(40704828823108818)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24930622501691106)
,p_page_id=>29
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(38303783368261603.123456)
,p_translate_from_id=>wwv_flow_imp.id(38303783368261603)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\062E\0637\0637 \0627\0644\0648\0627\0631\062F \0627\0644\0633\0646\0648\064A')
,p_translate_from_text=>'Annual Income chart'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24930812059691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20101330825048609.123456)
,p_translate_from_id=>wwv_flow_imp.id(20101330825048609)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0645\0635\0631\0648\0641\0627\062A \0641\064A \0627\0644\0634\0647\0631')
,p_translate_from_text=>'Expenses In Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24931079457691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19000379920605303.123456)
,p_translate_from_id=>wwv_flow_imp.id(19000379920605303)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0646\0634\0637\0647 \0627\0644\0645\0633\062A\062E\062F\0645\064A\0646')
,p_translate_from_text=>'user Activity'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24931214699691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19002687361605326.123456)
,p_translate_from_id=>wwv_flow_imp.id(19002687361605326)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A')
,p_translate_from_text=>'Income'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24931468371691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19001870780605318.123456)
,p_translate_from_id=>wwv_flow_imp.id(19001870780605318)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0648\0631\062F\064A\0646 \0627\0644\0627\062F\0648\064A\0647')
,p_translate_from_text=>'Provider Medcine'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24931663729691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(19003542220605335.123456)
,p_translate_from_id=>wwv_flow_imp.id(19003542220605335)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0648\0627\0631\062F\0627\062A \0641\064A \0627\0644\0634\0647\0631')
,p_translate_from_text=>'Income In Month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24931829993691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503895461891538.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503895461891538)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0627\0644\0627\0639\0644\064A \0645\0628\064A\0639\0627')
,p_translate_from_text=>'best seller'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24932063377691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13503199053891531.123456)
,p_translate_from_id=>wwv_flow_imp.id(13503199053891531)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0642\0627\0631\0646\0647 \0627\0644\0633\0646\0648\0627\062A')
,p_translate_from_text=>'compare years'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24932288989691109)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(13501373895891513.123456)
,p_translate_from_id=>wwv_flow_imp.id(13501373895891513)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0645\0642\0627\0631\0646\0647 \0627\0644\0627\0634\0647\0631 ')
,p_translate_from_text=>'compare months '
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24932404711691112)
,p_page_id=>30
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20100535279048601.123456)
,p_translate_from_id=>wwv_flow_imp.id(20100535279048601)
,p_translate_column_id=>466
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>'expenses in month'
,p_translate_from_text=>'expenses in month'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(24932666561691160)
,p_translated_flow_id=>123456
,p_translate_to_id=>100.123456
,p_translate_from_id=>100
,p_translate_column_id=>476
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\0635\064A\062F\0644\064A\0647 ')
,p_translate_from_text=>'Pharmacy'
);
wwv_flow_imp_shared.create_translation(
 p_id=>wwv_flow_imp.id(26500105490348459)
,p_page_id=>10010
,p_translated_flow_id=>123456
,p_translate_to_id=>wwv_flow_imp.id(20102444344048620.123456)
,p_translate_from_id=>wwv_flow_imp.id(20102444344048620)
,p_translate_column_id=>13
,p_translate_to_lang_code=>'ar-eg'
,p_translation_specific_to_item=>'NO'
,p_template_translatable=>'N'
,p_translate_to_text=>unistr('\062C\062F\064A\062F')
,p_translate_from_text=>'New'
);
wwv_flow_imp.component_end;
end;
/
