prompt --application/shared_components/security/authorizations/casher_data_entry
begin
--   Manifest
--     SECURITY SCHEME: Casher & Data Entry
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>2700425181679773
,p_default_application_id=>100
,p_default_id_offset=>3200132127756896
,p_default_owner=>'PHARMACY'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(22900277267522539)
,p_name=>'Casher & Data Entry'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from "ph_users"',
'where',
'upper(USERNAME) = :APP_USER',
'and  ',
'(ROLE like ''%C%'' or ROLE like ''%DE%'')'))
,p_error_message=>'You are not allowed to be here Please Call the administrator!!'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
